--
-- PostgreSQL database dump
--

-- Dumped from database version 12.22
-- Dumped by pg_dump version 12.22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aldryn_categories_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_categories_category (
    id integer NOT NULL,
    lft integer NOT NULL,
    rgt integer NOT NULL,
    tree_id integer NOT NULL,
    depth integer NOT NULL,
    CONSTRAINT aldryn_categories_category_depth_check CHECK ((depth >= 0)),
    CONSTRAINT aldryn_categories_category_lft_check CHECK ((lft >= 0)),
    CONSTRAINT aldryn_categories_category_rgt_check CHECK ((rgt >= 0)),
    CONSTRAINT aldryn_categories_category_tree_id_check CHECK ((tree_id >= 0))
);


--
-- Name: aldryn_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_categories_category_id_seq OWNED BY public.aldryn_categories_category.id;


--
-- Name: aldryn_categories_category_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_categories_category_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    master_id integer
);


--
-- Name: aldryn_categories_category_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_categories_category_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_categories_category_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_categories_category_translation_id_seq OWNED BY public.aldryn_categories_category_translation.id;


--
-- Name: aldryn_newsblog_article; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_article (
    id integer NOT NULL,
    publishing_date timestamp with time zone NOT NULL,
    is_published boolean NOT NULL,
    is_featured boolean NOT NULL,
    app_config_id integer NOT NULL,
    author_id integer,
    content_id integer,
    featured_image_id integer,
    owner_id integer NOT NULL
);


--
-- Name: aldryn_newsblog_article_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_article_categories (
    id integer NOT NULL,
    article_id integer NOT NULL,
    category_id integer NOT NULL
);


--
-- Name: aldryn_newsblog_article_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_newsblog_article_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_newsblog_article_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_newsblog_article_categories_id_seq OWNED BY public.aldryn_newsblog_article_categories.id;


--
-- Name: aldryn_newsblog_article_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_newsblog_article_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_newsblog_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_newsblog_article_id_seq OWNED BY public.aldryn_newsblog_article.id;


--
-- Name: aldryn_newsblog_article_related; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_article_related (
    id integer NOT NULL,
    from_article_id integer NOT NULL,
    to_article_id integer NOT NULL,
    sort_value integer NOT NULL
);


--
-- Name: aldryn_newsblog_article_related_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_newsblog_article_related_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_newsblog_article_related_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_newsblog_article_related_id_seq OWNED BY public.aldryn_newsblog_article_related.id;


--
-- Name: aldryn_newsblog_article_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_article_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    title character varying(234) NOT NULL,
    slug character varying(255) NOT NULL,
    lead_in text NOT NULL,
    meta_title character varying(255) NOT NULL,
    meta_description text NOT NULL,
    meta_keywords text NOT NULL,
    search_data text NOT NULL,
    master_id integer
);


--
-- Name: aldryn_newsblog_article_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_newsblog_article_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_newsblog_article_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_newsblog_article_translation_id_seq OWNED BY public.aldryn_newsblog_article_translation.id;


--
-- Name: aldryn_newsblog_newsblogarchiveplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogarchiveplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogarticlesearchplugin (
    cmsplugin_ptr_id integer NOT NULL,
    max_articles integer NOT NULL,
    app_config_id integer NOT NULL,
    CONSTRAINT aldryn_newsblog_newsblogarticlesearchplugin_max_articles_check CHECK ((max_articles >= 0))
);


--
-- Name: aldryn_newsblog_newsblogauthorsplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogauthorsplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


--
-- Name: aldryn_newsblog_newsblogcategoriesplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogcategoriesplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


--
-- Name: aldryn_newsblog_newsblogconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogconfig (
    id integer NOT NULL,
    type character varying(100) NOT NULL,
    namespace character varying(100) NOT NULL,
    app_data text NOT NULL,
    permalink_type character varying(8) NOT NULL,
    non_permalink_handling smallint NOT NULL,
    paginate_by integer NOT NULL,
    create_authors boolean NOT NULL,
    search_indexed boolean NOT NULL,
    placeholder_base_sidebar_id integer,
    placeholder_base_top_id integer,
    placeholder_detail_bottom_id integer,
    placeholder_detail_footer_id integer,
    placeholder_detail_top_id integer,
    placeholder_list_footer_id integer,
    placeholder_list_top_id integer,
    template_prefix character varying(20),
    pagination_pages_start integer NOT NULL,
    pagination_pages_visible integer NOT NULL,
    CONSTRAINT aldryn_newsblog_newsblogconfig_paginate_by_check CHECK ((paginate_by >= 0)),
    CONSTRAINT aldryn_newsblog_newsblogconfig_pagination_pages_start_check CHECK ((pagination_pages_start >= 0)),
    CONSTRAINT aldryn_newsblog_newsblogconfig_pagination_pages_visible_check CHECK ((pagination_pages_visible >= 0))
);


--
-- Name: aldryn_newsblog_newsblogconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_newsblog_newsblogconfig_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_newsblog_newsblogconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_newsblog_newsblogconfig_id_seq OWNED BY public.aldryn_newsblog_newsblogconfig.id;


--
-- Name: aldryn_newsblog_newsblogconfig_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogconfig_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    app_title character varying(234) NOT NULL,
    master_id integer
);


--
-- Name: aldryn_newsblog_newsblogconfig_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_newsblog_newsblogconfig_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_newsblog_newsblogconfig_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_newsblog_newsblogconfig_translation_id_seq OWNED BY public.aldryn_newsblog_newsblogconfig_translation.id;


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogfeaturedarticlesplugin (
    cmsplugin_ptr_id integer NOT NULL,
    article_count integer NOT NULL,
    app_config_id integer NOT NULL,
    CONSTRAINT aldryn_newsblog_newsblogfeaturedarticlesplu_article_count_check CHECK ((article_count >= 0))
);


--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsbloglatestarticlesplugin (
    cmsplugin_ptr_id integer NOT NULL,
    latest_articles integer NOT NULL,
    app_config_id integer NOT NULL
);


--
-- Name: aldryn_newsblog_newsblogrelatedplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogrelatedplugin (
    cmsplugin_ptr_id integer NOT NULL
);


--
-- Name: aldryn_newsblog_newsblogtagsplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_newsblog_newsblogtagsplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer NOT NULL
);


--
-- Name: aldryn_people_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_people_group (
    id integer NOT NULL,
    address text NOT NULL,
    postal_code character varying(20) NOT NULL,
    city character varying(255) NOT NULL,
    phone character varying(100),
    fax character varying(100),
    email character varying(254) NOT NULL,
    website character varying(200)
);


--
-- Name: aldryn_people_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_people_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_people_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_people_group_id_seq OWNED BY public.aldryn_people_group.id;


--
-- Name: aldryn_people_group_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_people_group_translation (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    language_code character varying(15) NOT NULL,
    master_id integer,
    slug character varying(255) NOT NULL
);


--
-- Name: aldryn_people_group_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_people_group_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_people_group_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_people_group_translation_id_seq OWNED BY public.aldryn_people_group_translation.id;


--
-- Name: aldryn_people_peopleplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_people_peopleplugin (
    cmsplugin_ptr_id integer NOT NULL,
    style character varying(50) NOT NULL,
    group_by_group boolean NOT NULL,
    show_links boolean NOT NULL,
    show_vcard boolean NOT NULL,
    show_ungrouped boolean NOT NULL
);


--
-- Name: aldryn_people_peopleplugin_people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_people_peopleplugin_people (
    id integer NOT NULL,
    peopleplugin_id integer NOT NULL,
    person_id integer NOT NULL,
    sort_value integer NOT NULL
);


--
-- Name: aldryn_people_peopleplugin_people_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_people_peopleplugin_people_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_people_peopleplugin_people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_people_peopleplugin_people_id_seq OWNED BY public.aldryn_people_peopleplugin_people.id;


--
-- Name: aldryn_people_person; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_people_person (
    id integer NOT NULL,
    phone character varying(100),
    mobile character varying(100),
    fax character varying(100),
    email character varying(254) NOT NULL,
    website character varying(200),
    vcard_enabled boolean NOT NULL,
    user_id integer,
    visual_id integer
);


--
-- Name: aldryn_people_person_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_people_person_groups (
    id integer NOT NULL,
    person_id integer NOT NULL,
    group_id integer NOT NULL,
    sort_value integer NOT NULL
);


--
-- Name: aldryn_people_person_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_people_person_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_people_person_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_people_person_groups_id_seq OWNED BY public.aldryn_people_person_groups.id;


--
-- Name: aldryn_people_person_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_people_person_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_people_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_people_person_id_seq OWNED BY public.aldryn_people_person.id;


--
-- Name: aldryn_people_person_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aldryn_people_person_translation (
    id integer NOT NULL,
    function character varying(255) NOT NULL,
    description text NOT NULL,
    language_code character varying(15) NOT NULL,
    master_id integer,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL
);


--
-- Name: aldryn_people_person_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aldryn_people_person_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aldryn_people_person_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aldryn_people_person_translation_id_seq OWNED BY public.aldryn_people_person_translation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: cms_aliaspluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_aliaspluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    plugin_id integer,
    alias_placeholder_id integer
);


--
-- Name: cms_cmsplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_cmsplugin (
    id integer NOT NULL,
    "position" smallint,
    language character varying(15) NOT NULL,
    plugin_type character varying(50) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    parent_id integer,
    placeholder_id integer,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    path character varying(255) NOT NULL,
    CONSTRAINT cms_cmsplugin_depth_check CHECK ((depth >= 0)),
    CONSTRAINT cms_cmsplugin_numchild_check CHECK ((numchild >= 0)),
    CONSTRAINT cms_cmsplugin_position_check CHECK (("position" >= 0))
);


--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_cmsplugin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_cmsplugin_id_seq OWNED BY public.cms_cmsplugin.id;


--
-- Name: cms_globalpagepermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_globalpagepermission (
    id integer NOT NULL,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    can_recover_page boolean NOT NULL,
    group_id integer,
    user_id integer
);


--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_globalpagepermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_globalpagepermission_id_seq OWNED BY public.cms_globalpagepermission.id;


--
-- Name: cms_globalpagepermission_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_globalpagepermission_sites (
    id integer NOT NULL,
    globalpagepermission_id integer NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_globalpagepermission_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_globalpagepermission_sites_id_seq OWNED BY public.cms_globalpagepermission_sites.id;


--
-- Name: cms_page; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_page (
    id integer NOT NULL,
    created_by character varying(255) NOT NULL,
    changed_by character varying(255) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    publication_date timestamp with time zone,
    publication_end_date timestamp with time zone,
    in_navigation boolean NOT NULL,
    soft_root boolean NOT NULL,
    reverse_id character varying(40),
    navigation_extenders character varying(80),
    template character varying(100) NOT NULL,
    login_required boolean NOT NULL,
    limit_visibility_in_menu smallint,
    is_home boolean NOT NULL,
    application_urls character varying(200),
    application_namespace character varying(200),
    publisher_is_draft boolean NOT NULL,
    languages character varying(255),
    revision_id integer NOT NULL,
    xframe_options integer NOT NULL,
    parent_id integer,
    publisher_public_id integer,
    site_id integer NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    path character varying(255) NOT NULL,
    CONSTRAINT cms_page_depth_check CHECK ((depth >= 0)),
    CONSTRAINT cms_page_numchild_check CHECK ((numchild >= 0)),
    CONSTRAINT cms_page_revision_id_check CHECK ((revision_id >= 0))
);


--
-- Name: cms_page_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_page_id_seq OWNED BY public.cms_page.id;


--
-- Name: cms_page_placeholders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_page_placeholders (
    id integer NOT NULL,
    page_id integer NOT NULL,
    placeholder_id integer NOT NULL
);


--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_page_placeholders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_page_placeholders_id_seq OWNED BY public.cms_page_placeholders.id;


--
-- Name: cms_pagepermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pagepermission (
    id integer NOT NULL,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    grant_on integer NOT NULL,
    group_id integer,
    page_id integer,
    user_id integer
);


--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_pagepermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_pagepermission_id_seq OWNED BY public.cms_pagepermission.id;


--
-- Name: cms_pageuser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pageuser (
    customuser_ptr_id integer NOT NULL,
    created_by_id integer NOT NULL
);


--
-- Name: cms_pageusergroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pageusergroup (
    group_ptr_id integer NOT NULL,
    created_by_id integer NOT NULL
);


--
-- Name: cms_placeholder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_placeholder (
    id integer NOT NULL,
    slot character varying(255) NOT NULL,
    default_width smallint,
    CONSTRAINT cms_placeholder_default_width_check CHECK ((default_width >= 0))
);


--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_placeholder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_placeholder_id_seq OWNED BY public.cms_placeholder.id;


--
-- Name: cms_placeholderreference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_placeholderreference (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(255) NOT NULL,
    placeholder_ref_id integer
);


--
-- Name: cms_staticplaceholder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_staticplaceholder (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    dirty boolean NOT NULL,
    creation_method character varying(20) NOT NULL,
    draft_id integer,
    public_id integer,
    site_id integer
);


--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_staticplaceholder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_staticplaceholder_id_seq OWNED BY public.cms_staticplaceholder.id;


--
-- Name: cms_title; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_title (
    id integer NOT NULL,
    language character varying(15) NOT NULL,
    title character varying(255) NOT NULL,
    page_title character varying(255),
    menu_title character varying(255),
    meta_description text,
    slug character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    has_url_overwrite boolean NOT NULL,
    redirect character varying(2048),
    creation_date timestamp with time zone NOT NULL,
    published boolean NOT NULL,
    publisher_is_draft boolean NOT NULL,
    publisher_state smallint NOT NULL,
    page_id integer NOT NULL,
    publisher_public_id integer
);


--
-- Name: cms_title_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_title_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_title_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_title_id_seq OWNED BY public.cms_title.id;


--
-- Name: cms_urlconfrevision; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_urlconfrevision (
    id integer NOT NULL,
    revision character varying(255) NOT NULL
);


--
-- Name: cms_urlconfrevision_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_urlconfrevision_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_urlconfrevision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_urlconfrevision_id_seq OWNED BY public.cms_urlconfrevision.id;


--
-- Name: cms_usersettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_usersettings (
    id integer NOT NULL,
    language character varying(10) NOT NULL,
    clipboard_id integer,
    user_id integer NOT NULL
);


--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cms_usersettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cms_usersettings_id_seq OWNED BY public.cms_usersettings.id;


--
-- Name: cmsplugin_filer_file_filerfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cmsplugin_filer_file_filerfile (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(255),
    target_blank boolean NOT NULL,
    style character varying(255) NOT NULL,
    file_id integer
);


--
-- Name: cmsplugin_filer_folder_filerfolder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cmsplugin_filer_folder_filerfolder (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(255),
    style character varying(50) NOT NULL,
    folder_id integer
);


--
-- Name: cmsplugin_filer_image_filerimage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cmsplugin_filer_image_filerimage (
    cmsplugin_ptr_id integer NOT NULL,
    style character varying(50) NOT NULL,
    caption_text character varying(255),
    image_url character varying(200),
    alt_text character varying(255),
    use_original_image boolean NOT NULL,
    use_autoscale boolean NOT NULL,
    width integer,
    height integer,
    crop boolean NOT NULL,
    upscale boolean NOT NULL,
    alignment character varying(10),
    free_link character varying(255),
    original_link boolean NOT NULL,
    description text,
    target_blank boolean NOT NULL,
    file_link_id integer,
    image_id integer,
    page_link_id integer,
    thumbnail_option_id integer,
    CONSTRAINT cmsplugin_filer_image_filerimage_height_check CHECK ((height >= 0)),
    CONSTRAINT cmsplugin_filer_image_filerimage_width_check CHECK ((width >= 0))
);


--
-- Name: cmsplugin_filer_image_thumbnailoption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cmsplugin_filer_image_thumbnailoption (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    crop boolean NOT NULL,
    upscale boolean NOT NULL
);


--
-- Name: cmsplugin_filer_image_thumbnailoption_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cmsplugin_filer_image_thumbnailoption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cmsplugin_filer_image_thumbnailoption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cmsplugin_filer_image_thumbnailoption_id_seq OWNED BY public.cmsplugin_filer_image_thumbnailoption.id;


--
-- Name: cmsplugin_filer_link_filerlinkplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cmsplugin_filer_link_filerlinkplugin (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(255),
    mailto character varying(75),
    link_style character varying(255) NOT NULL,
    new_window boolean NOT NULL,
    file_id integer,
    page_link_id integer
);


--
-- Name: cmsplugin_filer_video_filervideo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cmsplugin_filer_video_filervideo (
    cmsplugin_ptr_id integer NOT NULL,
    movie_url character varying(255),
    width smallint NOT NULL,
    height smallint NOT NULL,
    auto_play boolean NOT NULL,
    auto_hide boolean NOT NULL,
    fullscreen boolean NOT NULL,
    loop boolean NOT NULL,
    bgcolor character varying(6) NOT NULL,
    textcolor character varying(6) NOT NULL,
    seekbarcolor character varying(6) NOT NULL,
    seekbarbgcolor character varying(6) NOT NULL,
    loadingbarcolor character varying(6) NOT NULL,
    buttonoutcolor character varying(6) NOT NULL,
    buttonovercolor character varying(6) NOT NULL,
    buttonhighlightcolor character varying(6) NOT NULL,
    image_id integer,
    movie_id integer,
    CONSTRAINT cmsplugin_filer_video_filervideo_height_check CHECK ((height >= 0)),
    CONSTRAINT cmsplugin_filer_video_filervideo_width_check CHECK ((width >= 0))
);


--
-- Name: datacenterlight_cmsfaviconextension; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_cmsfaviconextension (
    id integer NOT NULL,
    extended_object_id integer NOT NULL,
    favicon_id integer NOT NULL,
    public_extension_id integer
);


--
-- Name: datacenterlight_cmsfaviconextension_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.datacenterlight_cmsfaviconextension_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datacenterlight_cmsfaviconextension_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.datacenterlight_cmsfaviconextension_id_seq OWNED BY public.datacenterlight_cmsfaviconextension.id;


--
-- Name: datacenterlight_cmsintegration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_cmsintegration (
    id integer NOT NULL,
    navbar_placeholder_id integer,
    footer_placeholder_id integer,
    name character varying(100) NOT NULL,
    domain_id integer,
    calculator_placeholder_id integer
);


--
-- Name: datacenterlight_cmsintegration_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.datacenterlight_cmsintegration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datacenterlight_cmsintegration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.datacenterlight_cmsintegration_id_seq OWNED BY public.datacenterlight_cmsintegration.id;


--
-- Name: datacenterlight_contactus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_contactus (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    email character varying(250) NOT NULL,
    message text NOT NULL,
    field timestamp with time zone NOT NULL
);


--
-- Name: datacenterlight_contactus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.datacenterlight_contactus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datacenterlight_contactus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.datacenterlight_contactus_id_seq OWNED BY public.datacenterlight_contactus.id;


--
-- Name: datacenterlight_dclbanneritempluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclbanneritempluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    content text NOT NULL,
    banner_text text,
    text_direction character varying(10) NOT NULL,
    banner_image_id integer
);


--
-- Name: datacenterlight_dclbannerlistpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclbannerlistpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    heading character varying(100),
    html_id character varying(50)
);


--
-- Name: datacenterlight_dclcalculatorpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclcalculatorpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    pricing_id integer NOT NULL,
    vm_type character varying(50) NOT NULL,
    vm_templates_to_show character varying(256)[] NOT NULL,
    default_selected_template character varying(128),
    enable_512mb_ram boolean NOT NULL
);


--
-- Name: datacenterlight_dclcontactpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclcontactpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    heading character varying(100) NOT NULL,
    organization_name character varying(100) NOT NULL,
    email character varying(200) NOT NULL,
    address character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    form_header character varying(100) NOT NULL
);


--
-- Name: datacenterlight_dclfooterpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclfooterpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    copyright_label character varying(100) NOT NULL
);


--
-- Name: datacenterlight_dcllinkpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dcllinkpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    target character varying(100) NOT NULL,
    text character varying(50) NOT NULL,
    title character varying(100),
    separator boolean NOT NULL
);


--
-- Name: datacenterlight_dclnavbardropdownpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclnavbardropdownpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    text character varying(50) NOT NULL,
    target character varying(100)
);


--
-- Name: datacenterlight_dclnavbarpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclnavbarpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    logo_url character varying(300),
    logo_dark_id integer,
    logo_light_id integer,
    language_dropdown boolean NOT NULL,
    show_login_option boolean NOT NULL,
    show_non_transparent_navbar_always boolean NOT NULL
);


--
-- Name: datacenterlight_dclsectioniconpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclsectioniconpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    fontawesome_icon_name character varying(30) NOT NULL
);


--
-- Name: datacenterlight_dclsectionimagepluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclsectionimagepluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    caption character varying(100),
    image_id integer NOT NULL
);


--
-- Name: datacenterlight_dclsectionpluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclsectionpluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    heading character varying(100),
    content text NOT NULL,
    text_direction character varying(10) NOT NULL,
    html_id character varying(50),
    center_on_mobile boolean NOT NULL,
    background_gradient boolean NOT NULL,
    plain_heading boolean NOT NULL
);


--
-- Name: datacenterlight_dclsectionpromopluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_dclsectionpromopluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    heading character varying(100),
    subheading character varying(200),
    content text NOT NULL,
    html_id character varying(50),
    plain_heading boolean NOT NULL,
    text_center boolean NOT NULL,
    background_image_id integer
);


--
-- Name: datacenterlight_stripeplan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_stripeplan (
    id integer NOT NULL,
    stripe_plan_id character varying(256),
    stripe_plan_name character varying(512),
    amount integer NOT NULL,
    "interval" character varying(128),
    CONSTRAINT datacenterlight_stripeplan_amount_check CHECK ((amount >= 0))
);


--
-- Name: datacenterlight_stripeplan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.datacenterlight_stripeplan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datacenterlight_stripeplan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.datacenterlight_stripeplan_id_seq OWNED BY public.datacenterlight_stripeplan.id;


--
-- Name: datacenterlight_vmpricing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_vmpricing (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    vat_inclusive boolean NOT NULL,
    vat_percentage numeric(7,5) NOT NULL,
    cores_unit_price numeric(7,5) NOT NULL,
    ram_unit_price numeric(7,5) NOT NULL,
    ssd_unit_price numeric(7,5) NOT NULL,
    hdd_unit_price numeric(7,6) NOT NULL,
    discount_amount numeric(6,2) NOT NULL,
    discount_name character varying(255),
    stripe_coupon_id character varying(255)
);


--
-- Name: datacenterlight_vmpricing_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.datacenterlight_vmpricing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datacenterlight_vmpricing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.datacenterlight_vmpricing_id_seq OWNED BY public.datacenterlight_vmpricing.id;


--
-- Name: datacenterlight_vmtemplate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.datacenterlight_vmtemplate (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    opennebula_vm_template_id integer NOT NULL,
    vm_type character varying(50) NOT NULL
);


--
-- Name: datacenterlight_vmtemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.datacenterlight_vmtemplate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datacenterlight_vmtemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.datacenterlight_vmtemplate_id_seq OWNED BY public.datacenterlight_vmtemplate.id;


--
-- Name: digitalglarus_booking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_booking (
    id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    price double precision NOT NULL,
    free_days integer NOT NULL,
    final_price double precision NOT NULL
);


--
-- Name: digitalglarus_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_booking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_booking_id_seq OWNED BY public.digitalglarus_booking.id;


--
-- Name: digitalglarus_bookingcancellation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_bookingcancellation (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    required_refund boolean NOT NULL,
    refund boolean NOT NULL,
    order_id integer NOT NULL
);


--
-- Name: digitalglarus_bookingcancellation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_bookingcancellation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_bookingcancellation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_bookingcancellation_id_seq OWNED BY public.digitalglarus_bookingcancellation.id;


--
-- Name: digitalglarus_bookingorder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_bookingorder (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    approved boolean NOT NULL,
    last4 character varying(4) NOT NULL,
    cc_brand character varying(128) NOT NULL,
    stripe_charge_id character varying(100),
    billing_address_id integer NOT NULL,
    booking_id integer NOT NULL,
    customer_id integer NOT NULL,
    amount double precision NOT NULL,
    original_price double precision NOT NULL,
    special_month_price double precision NOT NULL,
    status integer NOT NULL,
    CONSTRAINT digitalglarus_bookingorder_status_check CHECK ((status >= 0))
);


--
-- Name: digitalglarus_bookingorder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_bookingorder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_bookingorder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_bookingorder_id_seq OWNED BY public.digitalglarus_bookingorder.id;


--
-- Name: digitalglarus_bookingprice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_bookingprice (
    id integer NOT NULL,
    price_per_day double precision NOT NULL,
    special_month_price double precision NOT NULL
);


--
-- Name: digitalglarus_bookingprices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_bookingprices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_bookingprices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_bookingprices_id_seq OWNED BY public.digitalglarus_bookingprice.id;


--
-- Name: digitalglarus_dggallery; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_dggallery (
    id integer NOT NULL,
    name character varying(30) NOT NULL,
    parent_id integer
);


--
-- Name: digitalglarus_dggallery_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_dggallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_dggallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_dggallery_id_seq OWNED BY public.digitalglarus_dggallery.id;


--
-- Name: digitalglarus_dggalleryplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_dggalleryplugin (
    cmsplugin_ptr_id integer NOT NULL,
    "dgGallery_id" integer NOT NULL
);


--
-- Name: digitalglarus_dgpicture; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_dgpicture (
    id integer NOT NULL,
    description character varying(60) NOT NULL,
    gallery_id integer NOT NULL,
    image_id integer NOT NULL
);


--
-- Name: digitalglarus_dgpicture_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_dgpicture_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_dgpicture_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_dgpicture_id_seq OWNED BY public.digitalglarus_dgpicture.id;


--
-- Name: digitalglarus_dgsupportersplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_dgsupportersplugin (
    cmsplugin_ptr_id integer NOT NULL
);


--
-- Name: digitalglarus_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_membership (
    id integer NOT NULL,
    type_id integer NOT NULL,
    active boolean NOT NULL,
    end_date date NOT NULL,
    start_date date NOT NULL
);


--
-- Name: digitalglarus_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_membership_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_membership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_membership_id_seq OWNED BY public.digitalglarus_membership.id;


--
-- Name: digitalglarus_membershiporder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_membershiporder (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    approved boolean NOT NULL,
    last4 character varying(4) NOT NULL,
    cc_brand character varying(128) NOT NULL,
    stripe_charge_id character varying(100),
    membership_id integer NOT NULL,
    billing_address_id integer NOT NULL,
    customer_id integer NOT NULL,
    amount double precision NOT NULL,
    end_date date NOT NULL,
    start_date date NOT NULL,
    stripe_subscription_id character varying(100)
);


--
-- Name: digitalglarus_membershiporder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_membershiporder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_membershiporder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_membershiporder_id_seq OWNED BY public.digitalglarus_membershiporder.id;


--
-- Name: digitalglarus_membershiptype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_membershiptype (
    id integer NOT NULL,
    name character varying(20) NOT NULL,
    price double precision NOT NULL
);


--
-- Name: digitalglarus_membershiptype_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_membershiptype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_membershiptype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_membershiptype_id_seq OWNED BY public.digitalglarus_membershiptype.id;


--
-- Name: digitalglarus_supporter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.digitalglarus_supporter (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text
);


--
-- Name: digitalglarus_supporter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.digitalglarus_supporter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: digitalglarus_supporter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.digitalglarus_supporter_id_seq OWNED BY public.digitalglarus_supporter.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_celery_results_taskresult; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_celery_results_taskresult (
    id integer NOT NULL,
    task_id character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    content_type character varying(128) NOT NULL,
    content_encoding character varying(64) NOT NULL,
    result text,
    date_done timestamp with time zone NOT NULL,
    traceback text,
    hidden boolean NOT NULL,
    meta text
);


--
-- Name: django_celery_results_taskresult_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_celery_results_taskresult_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_celery_results_taskresult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_celery_results_taskresult_id_seq OWNED BY public.django_celery_results_taskresult.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: django_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: djangocms_blog_authorentriesplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_authorentriesplugin (
    cmsplugin_ptr_id integer NOT NULL,
    latest_posts integer NOT NULL,
    app_config_id integer,
    current_site boolean NOT NULL,
    template_folder character varying(200) NOT NULL
);


--
-- Name: djangocms_blog_authorentriesplugin_authors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_authorentriesplugin_authors (
    id integer NOT NULL,
    authorentriesplugin_id integer NOT NULL,
    customuser_id integer NOT NULL
);


--
-- Name: djangocms_blog_authorentriesplugin_authors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_authorentriesplugin_authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_authorentriesplugin_authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_authorentriesplugin_authors_id_seq OWNED BY public.djangocms_blog_authorentriesplugin_authors.id;


--
-- Name: djangocms_blog_blogcategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_blogcategory (
    id integer NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_modified timestamp with time zone NOT NULL,
    parent_id integer,
    app_config_id integer
);


--
-- Name: djangocms_blog_blogcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_blogcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_blogcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_blogcategory_id_seq OWNED BY public.djangocms_blog_blogcategory.id;


--
-- Name: djangocms_blog_blogcategory_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_blogcategory_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    name character varying(767) NOT NULL,
    slug character varying(767) NOT NULL,
    master_id integer,
    meta_description text NOT NULL
);


--
-- Name: djangocms_blog_blogcategory_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_blogcategory_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_blogcategory_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_blogcategory_translation_id_seq OWNED BY public.djangocms_blog_blogcategory_translation.id;


--
-- Name: djangocms_blog_blogconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_blogconfig (
    id integer NOT NULL,
    type character varying(100) NOT NULL,
    namespace character varying(100) NOT NULL,
    app_data text NOT NULL
);


--
-- Name: djangocms_blog_blogconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_blogconfig_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_blogconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_blogconfig_id_seq OWNED BY public.djangocms_blog_blogconfig.id;


--
-- Name: djangocms_blog_blogconfig_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_blogconfig_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    app_title character varying(234) NOT NULL,
    master_id integer,
    object_name character varying(234) NOT NULL
);


--
-- Name: djangocms_blog_blogconfig_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_blogconfig_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_blogconfig_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_blogconfig_translation_id_seq OWNED BY public.djangocms_blog_blogconfig_translation.id;


--
-- Name: djangocms_blog_genericblogplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_genericblogplugin (
    cmsplugin_ptr_id integer NOT NULL,
    app_config_id integer,
    current_site boolean NOT NULL,
    template_folder character varying(200) NOT NULL
);


--
-- Name: djangocms_blog_latestpostsplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_latestpostsplugin (
    cmsplugin_ptr_id integer NOT NULL,
    latest_posts integer NOT NULL,
    app_config_id integer,
    current_site boolean NOT NULL,
    template_folder character varying(200) NOT NULL
);


--
-- Name: djangocms_blog_latestpostsplugin_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_latestpostsplugin_categories (
    id integer NOT NULL,
    latestpostsplugin_id integer NOT NULL,
    blogcategory_id integer NOT NULL
);


--
-- Name: djangocms_blog_latestpostsplugin_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_latestpostsplugin_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_latestpostsplugin_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_latestpostsplugin_categories_id_seq OWNED BY public.djangocms_blog_latestpostsplugin_categories.id;


--
-- Name: djangocms_blog_post; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_post (
    id integer NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_modified timestamp with time zone NOT NULL,
    date_published timestamp with time zone,
    date_published_end timestamp with time zone,
    publish boolean NOT NULL,
    enable_comments boolean NOT NULL,
    author_id integer,
    content_id integer,
    main_image_id integer,
    main_image_full_id integer,
    main_image_thumbnail_id integer,
    app_config_id integer,
    liveblog_id integer,
    enable_liveblog boolean NOT NULL,
    date_featured timestamp with time zone
);


--
-- Name: djangocms_blog_post_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_post_categories (
    id integer NOT NULL,
    post_id integer NOT NULL,
    blogcategory_id integer NOT NULL
);


--
-- Name: djangocms_blog_post_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_post_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_post_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_post_categories_id_seq OWNED BY public.djangocms_blog_post_categories.id;


--
-- Name: djangocms_blog_post_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_post_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_post_id_seq OWNED BY public.djangocms_blog_post.id;


--
-- Name: djangocms_blog_post_related; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_post_related (
    id integer NOT NULL,
    from_post_id integer NOT NULL,
    to_post_id integer NOT NULL,
    sort_value integer NOT NULL
);


--
-- Name: djangocms_blog_post_related_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_post_related_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_post_related_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_post_related_id_seq OWNED BY public.djangocms_blog_post_related.id;


--
-- Name: djangocms_blog_post_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_post_sites (
    id integer NOT NULL,
    post_id integer NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: djangocms_blog_post_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_post_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_post_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_post_sites_id_seq OWNED BY public.djangocms_blog_post_sites.id;


--
-- Name: djangocms_blog_post_translation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_blog_post_translation (
    id integer NOT NULL,
    language_code character varying(15) NOT NULL,
    title character varying(767) NOT NULL,
    slug character varying(767) NOT NULL,
    abstract text NOT NULL,
    meta_description text NOT NULL,
    meta_keywords text NOT NULL,
    meta_title character varying(2000) NOT NULL,
    post_text text NOT NULL,
    master_id integer
);


--
-- Name: djangocms_blog_post_translation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_blog_post_translation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_blog_post_translation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_blog_post_translation_id_seq OWNED BY public.djangocms_blog_post_translation.id;


--
-- Name: djangocms_file_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_file_file (
    cmsplugin_ptr_id integer NOT NULL,
    file character varying(100) NOT NULL,
    title character varying(255),
    target character varying(100) NOT NULL,
    tooltip character varying(255) NOT NULL
);


--
-- Name: djangocms_page_meta_pagemeta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_page_meta_pagemeta (
    id integer NOT NULL,
    og_type character varying(255) NOT NULL,
    og_author_url character varying(255) NOT NULL,
    og_author_fbid character varying(16) NOT NULL,
    og_publisher character varying(255) NOT NULL,
    og_app_id character varying(255) NOT NULL,
    twitter_author character varying(255) NOT NULL,
    twitter_site character varying(255) NOT NULL,
    twitter_type character varying(255) NOT NULL,
    gplus_author character varying(255) NOT NULL,
    gplus_type character varying(255) NOT NULL,
    extended_object_id integer NOT NULL,
    image_id integer,
    og_author_id integer,
    public_extension_id integer
);


--
-- Name: djangocms_page_meta_pagemeta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_page_meta_pagemeta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_page_meta_pagemeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_page_meta_pagemeta_id_seq OWNED BY public.djangocms_page_meta_pagemeta.id;


--
-- Name: djangocms_page_meta_titlemeta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_page_meta_titlemeta (
    id integer NOT NULL,
    keywords character varying(400) NOT NULL,
    description character varying(400) NOT NULL,
    og_description character varying(400) NOT NULL,
    twitter_description character varying(140) NOT NULL,
    gplus_description character varying(400) NOT NULL,
    extended_object_id integer NOT NULL,
    image_id integer,
    public_extension_id integer
);


--
-- Name: djangocms_page_meta_titlemeta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.djangocms_page_meta_titlemeta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: djangocms_page_meta_titlemeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.djangocms_page_meta_titlemeta_id_seq OWNED BY public.djangocms_page_meta_titlemeta.id;


--
-- Name: djangocms_picture_picture; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_picture_picture (
    cmsplugin_ptr_id integer NOT NULL,
    image character varying(100) NOT NULL,
    url character varying(255),
    alt character varying(255),
    longdesc character varying(255),
    "float" character varying(10),
    page_link_id integer,
    height integer,
    width integer
);


--
-- Name: djangocms_text_ckeditor_text; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_text_ckeditor_text (
    cmsplugin_ptr_id integer NOT NULL,
    body text NOT NULL
);


--
-- Name: djangocms_video_video; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_video_video (
    cmsplugin_ptr_id integer NOT NULL,
    movie character varying(100),
    movie_url character varying(255),
    image character varying(100),
    width smallint NOT NULL,
    height smallint NOT NULL,
    auto_play boolean NOT NULL,
    auto_hide boolean NOT NULL,
    fullscreen boolean NOT NULL,
    loop boolean NOT NULL,
    bgcolor character varying(6) NOT NULL,
    textcolor character varying(6) NOT NULL,
    seekbarcolor character varying(6) NOT NULL,
    seekbarbgcolor character varying(6) NOT NULL,
    loadingbarcolor character varying(6) NOT NULL,
    buttonoutcolor character varying(6) NOT NULL,
    buttonovercolor character varying(6) NOT NULL,
    buttonhighlightcolor character varying(6) NOT NULL,
    CONSTRAINT djangocms_video_video_height_check CHECK ((height >= 0)),
    CONSTRAINT djangocms_video_video_width_check CHECK ((width >= 0))
);


--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.easy_thumbnails_source (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL
);


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.easy_thumbnails_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.easy_thumbnails_source_id_seq OWNED BY public.easy_thumbnails_source.id;


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.easy_thumbnails_thumbnail (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL
);


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.easy_thumbnails_thumbnail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.easy_thumbnails_thumbnail_id_seq OWNED BY public.easy_thumbnails_thumbnail.id;


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq OWNED BY public.easy_thumbnails_thumbnaildimensions.id;


--
-- Name: filer_clipboard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_clipboard (
    id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filer_clipboard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filer_clipboard_id_seq OWNED BY public.filer_clipboard.id;


--
-- Name: filer_clipboarditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_clipboarditem (
    id integer NOT NULL,
    clipboard_id integer NOT NULL,
    file_id integer NOT NULL
);


--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filer_clipboarditem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filer_clipboarditem_id_seq OWNED BY public.filer_clipboarditem.id;


--
-- Name: filer_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_file (
    id integer NOT NULL,
    file character varying(255),
    _file_size integer,
    sha1 character varying(40) NOT NULL,
    has_all_mandatory_data boolean NOT NULL,
    original_filename character varying(255),
    name character varying(255) NOT NULL,
    description text,
    uploaded_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_public boolean NOT NULL,
    folder_id integer,
    owner_id integer,
    polymorphic_ctype_id integer
);


--
-- Name: filer_file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filer_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filer_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filer_file_id_seq OWNED BY public.filer_file.id;


--
-- Name: filer_folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_folder (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    uploaded_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    owner_id integer,
    parent_id integer,
    CONSTRAINT filer_folder_level_check CHECK ((level >= 0)),
    CONSTRAINT filer_folder_lft_check CHECK ((lft >= 0)),
    CONSTRAINT filer_folder_rght_check CHECK ((rght >= 0)),
    CONSTRAINT filer_folder_tree_id_check CHECK ((tree_id >= 0))
);


--
-- Name: filer_folder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filer_folder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filer_folder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filer_folder_id_seq OWNED BY public.filer_folder.id;


--
-- Name: filer_folderpermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_folderpermission (
    id integer NOT NULL,
    type smallint NOT NULL,
    everybody boolean NOT NULL,
    can_edit smallint,
    can_read smallint,
    can_add_children smallint,
    folder_id integer,
    group_id integer,
    user_id integer
);


--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filer_folderpermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filer_folderpermission_id_seq OWNED BY public.filer_folderpermission.id;


--
-- Name: filer_image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_image (
    file_ptr_id integer NOT NULL,
    _height integer,
    _width integer,
    date_taken timestamp with time zone,
    default_alt_text character varying(255),
    default_caption character varying(255),
    author character varying(255),
    must_always_publish_author_credit boolean NOT NULL,
    must_always_publish_copyright boolean NOT NULL,
    subject_location character varying(64) NOT NULL
);


--
-- Name: filer_thumbnailoption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_thumbnailoption (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    crop boolean NOT NULL,
    upscale boolean NOT NULL
);


--
-- Name: filer_thumbnailoption_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filer_thumbnailoption_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filer_thumbnailoption_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filer_thumbnailoption_id_seq OWNED BY public.filer_thumbnailoption.id;


--
-- Name: guardian_groupobjectpermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guardian_groupobjectpermission (
    id integer NOT NULL,
    object_pk character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: guardian_groupobjectpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.guardian_groupobjectpermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: guardian_groupobjectpermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.guardian_groupobjectpermission_id_seq OWNED BY public.guardian_groupobjectpermission.id;


--
-- Name: guardian_userobjectpermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guardian_userobjectpermission (
    id integer NOT NULL,
    object_pk character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    permission_id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: guardian_userobjectpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.guardian_userobjectpermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: guardian_userobjectpermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.guardian_userobjectpermission_id_seq OWNED BY public.guardian_userobjectpermission.id;


--
-- Name: hosting_genericproduct; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_genericproduct (
    id integer NOT NULL,
    product_name character varying(128) NOT NULL,
    product_slug character varying(50) NOT NULL,
    product_description character varying(500) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    product_price numeric(10,2) NOT NULL,
    product_vat numeric(10,4) NOT NULL,
    product_is_subscription boolean NOT NULL,
    product_subscription_interval character varying(10) NOT NULL,
    exclude_vat_calculations boolean NOT NULL
);


--
-- Name: hosting_genericproduct_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_genericproduct_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_genericproduct_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_genericproduct_id_seq OWNED BY public.hosting_genericproduct.id;


--
-- Name: hosting_hostingbill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_hostingbill (
    id integer NOT NULL,
    billing_address_id integer NOT NULL,
    customer_id integer NOT NULL,
    total_price double precision NOT NULL
);


--
-- Name: hosting_hostingbill_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_hostingbill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_hostingbill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_hostingbill_id_seq OWNED BY public.hosting_hostingbill.id;


--
-- Name: hosting_hostingbilllineitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_hostingbilllineitem (
    id integer NOT NULL,
    amount integer NOT NULL,
    description character varying(255) NOT NULL,
    discountable boolean NOT NULL,
    metadata character varying(128) NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    proration boolean NOT NULL,
    quantity integer NOT NULL,
    unit_amount integer NOT NULL,
    monthly_hosting_bill_id integer NOT NULL,
    stripe_plan_id integer,
    CONSTRAINT hosting_hostingbilllineitem_quantity_check CHECK ((quantity >= 0)),
    CONSTRAINT hosting_hostingbilllineitem_unit_amount_check CHECK ((unit_amount >= 0))
);


--
-- Name: hosting_hostingbilllineitem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_hostingbilllineitem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_hostingbilllineitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_hostingbilllineitem_id_seq OWNED BY public.hosting_hostingbilllineitem.id;


--
-- Name: hosting_hostingorder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_hostingorder (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    billing_address_id integer NOT NULL,
    customer_id integer NOT NULL,
    approved boolean NOT NULL,
    stripe_charge_id character varying(100),
    cc_brand character varying(128) NOT NULL,
    last4 character varying(4) NOT NULL,
    vm_id integer NOT NULL,
    price double precision NOT NULL,
    subscription_id character varying(100),
    vm_pricing_id integer NOT NULL,
    order_detail_id integer,
    generic_payment_description character varying(500),
    generic_product_id integer
);


--
-- Name: hosting_hostingorder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_hostingorder_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_hostingorder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_hostingorder_id_seq OWNED BY public.hosting_hostingorder.id;


--
-- Name: hosting_hostingplan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_hostingplan (
    id integer NOT NULL,
    disk_size double precision NOT NULL,
    cpu_cores double precision NOT NULL,
    memory double precision NOT NULL
);


--
-- Name: hosting_hostingplan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_hostingplan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_hostingplan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_hostingplan_id_seq OWNED BY public.hosting_hostingplan.id;


--
-- Name: hosting_incompletepaymentintents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_incompletepaymentintents (
    id integer NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    payment_intent_id character varying(100) NOT NULL,
    request text NOT NULL,
    stripe_api_cus_id character varying(30) NOT NULL,
    card_details_response text NOT NULL,
    stripe_subscription_id character varying(100),
    stripe_charge_id character varying(100),
    gp_details text NOT NULL,
    billing_address_data text NOT NULL
);


--
-- Name: hosting_incompletepaymentintents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_incompletepaymentintents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_incompletepaymentintents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_incompletepaymentintents_id_seq OWNED BY public.hosting_incompletepaymentintents.id;


--
-- Name: hosting_incompletesubscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_incompletesubscriptions (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    subscription_id character varying(100) NOT NULL,
    subscription_status character varying(30) NOT NULL,
    name character varying(50) NOT NULL,
    email character varying(254) NOT NULL,
    request text NOT NULL,
    stripe_api_cus_id character varying(30) NOT NULL,
    card_details_response text NOT NULL,
    stripe_subscription_obj text NOT NULL,
    stripe_onetime_charge text NOT NULL,
    gp_details text NOT NULL,
    specs text NOT NULL,
    vm_template_id integer NOT NULL,
    template text NOT NULL,
    billing_address_data text NOT NULL,
    CONSTRAINT hosting_incompletesubscriptions_vm_template_id_check CHECK ((vm_template_id >= 0))
);


--
-- Name: hosting_incompletesubscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_incompletesubscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_incompletesubscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_incompletesubscriptions_id_seq OWNED BY public.hosting_incompletesubscriptions.id;


--
-- Name: hosting_monthlyhostingbill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_monthlyhostingbill (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    receipt_number character varying(100) NOT NULL,
    invoice_number character varying(100) NOT NULL,
    paid_at timestamp with time zone NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    billing_reason character varying(25) NOT NULL,
    discount integer NOT NULL,
    total integer NOT NULL,
    lines_data_count integer NOT NULL,
    invoice_id character varying(100) NOT NULL,
    lines_meta_data_csv text NOT NULL,
    customer_id integer NOT NULL,
    order_id integer NOT NULL,
    subscription_ids_csv text NOT NULL,
    CONSTRAINT hosting_monthlyhostingbill_discount_check CHECK ((discount >= 0))
);


--
-- Name: hosting_monthlyhostingbill_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_monthlyhostingbill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_monthlyhostingbill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_monthlyhostingbill_id_seq OWNED BY public.hosting_monthlyhostingbill.id;


--
-- Name: hosting_orderdetail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_orderdetail (
    id integer NOT NULL,
    cores integer NOT NULL,
    memory integer NOT NULL,
    hdd_size integer NOT NULL,
    ssd_size integer NOT NULL,
    vm_template_id integer
);


--
-- Name: hosting_orderdetail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_orderdetail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_orderdetail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_orderdetail_id_seq OWNED BY public.hosting_orderdetail.id;


--
-- Name: hosting_stripetaxrate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_stripetaxrate (
    id integer NOT NULL,
    tax_rate_id character varying(100) NOT NULL,
    jurisdiction character varying(10) NOT NULL,
    inclusive boolean NOT NULL,
    display_name character varying(100) NOT NULL,
    percentage double precision NOT NULL,
    description character varying(100) NOT NULL
);


--
-- Name: hosting_stripetaxrate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_stripetaxrate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_stripetaxrate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_stripetaxrate_id_seq OWNED BY public.hosting_stripetaxrate.id;


--
-- Name: hosting_usercarddetail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_usercarddetail (
    id integer NOT NULL,
    last4 character varying(4) NOT NULL,
    brand character varying(128) NOT NULL,
    card_id character varying(100) NOT NULL,
    fingerprint character varying(100) NOT NULL,
    exp_month integer NOT NULL,
    exp_year integer NOT NULL,
    preferred boolean NOT NULL,
    stripe_customer_id integer NOT NULL
);


--
-- Name: hosting_usercarddetail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_usercarddetail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_usercarddetail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_usercarddetail_id_seq OWNED BY public.hosting_usercarddetail.id;


--
-- Name: hosting_userhostingkey; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_userhostingkey (
    id integer NOT NULL,
    public_key text NOT NULL,
    user_id integer,
    created_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    private_key character varying(100) NOT NULL
);


--
-- Name: hosting_userhostingkey_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_userhostingkey_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_userhostingkey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_userhostingkey_id_seq OWNED BY public.hosting_userhostingkey.id;


--
-- Name: hosting_vatrates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_vatrates (
    id integer NOT NULL,
    start_date date,
    stop_date date,
    territory_codes text NOT NULL,
    currency_code character varying(10) NOT NULL,
    rate double precision NOT NULL,
    rate_type text NOT NULL,
    description text NOT NULL
);


--
-- Name: hosting_vatrates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_vatrates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_vatrates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_vatrates_id_seq OWNED BY public.hosting_vatrates.id;


--
-- Name: hosting_vmdetail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hosting_vmdetail (
    id integer NOT NULL,
    vm_id integer NOT NULL,
    disk_size double precision NOT NULL,
    cores double precision NOT NULL,
    memory double precision NOT NULL,
    configuration character varying(128) NOT NULL,
    ipv4 text NOT NULL,
    ipv6 text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    terminated_at timestamp with time zone,
    user_id integer NOT NULL
);


--
-- Name: hosting_vmdetail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hosting_vmdetail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hosting_vmdetail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hosting_vmdetail_id_seq OWNED BY public.hosting_vmdetail.id;


--
-- Name: membership_calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_calendar (
    id integer NOT NULL,
    datebooked date NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: membership_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_calendar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_calendar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_calendar_id_seq OWNED BY public.membership_calendar.id;


--
-- Name: membership_creditcards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_creditcards (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    card_number character varying(50) NOT NULL,
    expiry_date character varying(50) NOT NULL,
    ccv character varying(4) NOT NULL,
    payment_type character varying(5) NOT NULL,
    user_id_id integer NOT NULL
);


--
-- Name: membership_creditcards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_creditcards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_creditcards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_creditcards_id_seq OWNED BY public.membership_creditcards.id;


--
-- Name: membership_customuser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_customuser (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    name character varying(50) NOT NULL,
    email character varying(254) NOT NULL,
    validated integer NOT NULL,
    validation_slug character varying(50) NOT NULL,
    site_id integer NOT NULL,
    is_admin boolean NOT NULL,
    is_superuser boolean NOT NULL,
    import_stripe_bill_remark text NOT NULL,
    in_ldap boolean NOT NULL,
    username character varying(60)
);


--
-- Name: membership_customuser_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_customuser_groups (
    id integer NOT NULL,
    customuser_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: membership_customuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_customuser_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_customuser_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_customuser_groups_id_seq OWNED BY public.membership_customuser_groups.id;


--
-- Name: membership_customuser_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_customuser_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_customuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_customuser_id_seq OWNED BY public.membership_customuser.id;


--
-- Name: membership_customuser_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_customuser_user_permissions (
    id integer NOT NULL,
    customuser_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: membership_customuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_customuser_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_customuser_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_customuser_user_permissions_id_seq OWNED BY public.membership_customuser_user_permissions.id;


--
-- Name: membership_deleteduser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_deleteduser (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(254) NOT NULL,
    email character varying(254) NOT NULL,
    deleted_at timestamp with time zone NOT NULL,
    CONSTRAINT membership_deleteduser_user_id_check CHECK ((user_id >= 0))
);


--
-- Name: membership_deleteduser_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_deleteduser_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_deleteduser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_deleteduser_id_seq OWNED BY public.membership_deleteduser.id;


--
-- Name: membership_stripecustomer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_stripecustomer (
    id integer NOT NULL,
    stripe_id character varying(100) NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: membership_stripecustomer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_stripecustomer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_stripecustomer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_stripecustomer_id_seq OWNED BY public.membership_stripecustomer.id;


--
-- Name: menus_cachekey; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menus_cachekey (
    id integer NOT NULL,
    language character varying(255) NOT NULL,
    site integer NOT NULL,
    key character varying(255) NOT NULL,
    CONSTRAINT menus_cachekey_site_check CHECK ((site >= 0))
);


--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menus_cachekey_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menus_cachekey_id_seq OWNED BY public.menus_cachekey.id;


--
-- Name: multisite_alias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.multisite_alias (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    is_canonical boolean,
    redirect_to_canonical boolean NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: multisite_alias_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.multisite_alias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: multisite_alias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.multisite_alias_id_seq OWNED BY public.multisite_alias.id;


--
-- Name: nosystemd_donation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nosystemd_donation (
    id integer NOT NULL,
    donation double precision NOT NULL,
    created_at timestamp with time zone NOT NULL,
    last4 character varying(4) NOT NULL,
    cc_brand character varying(10) NOT NULL,
    stripe_charge_id character varying(100),
    billing_address_id integer NOT NULL,
    donator_id integer NOT NULL
);


--
-- Name: nosystemd_donation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nosystemd_donation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nosystemd_donation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nosystemd_donation_id_seq OWNED BY public.nosystemd_donation.id;


--
-- Name: nosystemd_donatorstatus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nosystemd_donatorstatus (
    id integer NOT NULL,
    status character varying(10) NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: nosystemd_donatorstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nosystemd_donatorstatus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nosystemd_donatorstatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nosystemd_donatorstatus_id_seq OWNED BY public.nosystemd_donatorstatus.id;


--
-- Name: reversion_revision; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reversion_revision (
    id integer NOT NULL,
    manager_slug character varying(191) NOT NULL,
    date_created timestamp with time zone NOT NULL,
    comment text NOT NULL,
    user_id integer
);


--
-- Name: reversion_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reversion_revision_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reversion_revision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reversion_revision_id_seq OWNED BY public.reversion_revision.id;


--
-- Name: reversion_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reversion_version (
    id integer NOT NULL,
    object_id text NOT NULL,
    object_id_int integer,
    format character varying(255) NOT NULL,
    serialized_data text NOT NULL,
    object_repr text NOT NULL,
    content_type_id integer NOT NULL,
    revision_id integer NOT NULL
);


--
-- Name: reversion_version_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reversion_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reversion_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reversion_version_id_seq OWNED BY public.reversion_version.id;


--
-- Name: stored_messages_inbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stored_messages_inbox (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: stored_messages_inbox_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stored_messages_inbox_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stored_messages_inbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stored_messages_inbox_id_seq OWNED BY public.stored_messages_inbox.id;


--
-- Name: stored_messages_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stored_messages_message (
    id integer NOT NULL,
    message text NOT NULL,
    level integer NOT NULL,
    tags text NOT NULL,
    date timestamp with time zone NOT NULL,
    url character varying(200)
);


--
-- Name: stored_messages_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stored_messages_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stored_messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stored_messages_message_id_seq OWNED BY public.stored_messages_message.id;


--
-- Name: stored_messages_messagearchive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stored_messages_messagearchive (
    id integer NOT NULL,
    message_id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: stored_messages_messagearchive_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stored_messages_messagearchive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stored_messages_messagearchive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stored_messages_messagearchive_id_seq OWNED BY public.stored_messages_messagearchive.id;


--
-- Name: taggit_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggit_tag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taggit_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taggit_tag_id_seq OWNED BY public.taggit_tag.id;


--
-- Name: taggit_taggeditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggit_taggeditem (
    id integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taggit_taggeditem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taggit_taggeditem_id_seq OWNED BY public.taggit_taggeditem.id;


--
-- Name: ungleich_page_about; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_about (
    service_ptr_id integer NOT NULL
);


--
-- Name: ungleich_page_aboutitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_aboutitem (
    ungelichpicture_ptr_id integer NOT NULL,
    inverted boolean NOT NULL,
    link_url character varying(300) NOT NULL
);


--
-- Name: ungleich_page_sectionwithimage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_sectionwithimage (
    ungelichpicture_ptr_id integer NOT NULL,
    price_tag_url character varying(300) NOT NULL,
    price_tag_image_id integer,
    menu_text character varying(100) NOT NULL
);


--
-- Name: ungleich_page_service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_service (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(200) NOT NULL,
    sub_title text NOT NULL,
    menu_text character varying(100) NOT NULL
);


--
-- Name: ungleich_page_serviceitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_serviceitem (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    image_id integer
);


--
-- Name: ungleich_page_ungelichcontactussection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungelichcontactussection (
    cmsplugin_ptr_id integer NOT NULL,
    email character varying(200) NOT NULL,
    menu_text character varying(100) NOT NULL,
    address character varying(100) NOT NULL,
    contact_form_header_text character varying(100) NOT NULL,
    contact_text character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    organization_name character varying(100) NOT NULL
);


--
-- Name: ungleich_page_ungelichpicture; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungelichpicture (
    cmsplugin_ptr_id integer NOT NULL,
    title text NOT NULL,
    image_id integer
);


--
-- Name: ungleich_page_ungelichtextsection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungelichtextsection (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    menu_text character varying(100) NOT NULL
);


--
-- Name: ungleich_page_ungleichcustomer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichcustomer (
    service_ptr_id integer NOT NULL,
    section_class character varying(100) NOT NULL,
    carousel_data_interval integer NOT NULL,
    bottom_text text NOT NULL
);


--
-- Name: ungleich_page_ungleichcustomeritem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichcustomeritem (
    cmsplugin_ptr_id integer NOT NULL,
    url character varying(300) NOT NULL,
    description text NOT NULL,
    image_id integer
);


--
-- Name: ungleich_page_ungleichfooter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichfooter (
    cmsplugin_ptr_id integer NOT NULL,
    copyright_label character varying(100) NOT NULL,
    link_text character varying(100),
    link_url character varying(200),
    twitter_url character varying(200),
    linkedin_url character varying(200),
    github_url character varying(200),
    facebook_url character varying(200),
    youtube_url character varying(200)
);


--
-- Name: ungleich_page_ungleichheaderwithbackgroundimageslider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichheaderwithbackgroundimageslider (
    cmsplugin_ptr_id integer NOT NULL,
    carousel_data_interval integer NOT NULL
);


--
-- Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem (
    cmsplugin_ptr_id integer NOT NULL,
    description text,
    image_id integer,
    btn_link character varying(100),
    btn_text character varying(50),
    heading character varying(100),
    video_id integer
);


--
-- Name: ungleich_page_ungleichhtmlonly; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichhtmlonly (
    cmsplugin_ptr_id integer NOT NULL,
    "HTML" text NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: ungleich_page_ungleichproduct; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichproduct (
    service_ptr_id integer NOT NULL,
    section_class character varying(100) NOT NULL,
    animate boolean NOT NULL
);


--
-- Name: ungleich_page_ungleichproductitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichproductitem (
    serviceitem_ptr_id integer NOT NULL,
    url character varying(300) NOT NULL
);


--
-- Name: ungleich_page_ungleichserviceitem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_page_ungleichserviceitem (
    serviceitem_ptr_id integer NOT NULL,
    data_replaced_image_id integer
);


--
-- Name: ungleich_ungleichpage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ungleich_ungleichpage (
    id integer NOT NULL,
    extended_object_id integer NOT NULL,
    public_extension_id integer,
    image_id integer
);


--
-- Name: ungleich_ungleichpage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ungleich_ungleichpage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ungleich_ungleichpage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ungleich_ungleichpage_id_seq OWNED BY public.ungleich_ungleichpage.id;


--
-- Name: utils_billingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.utils_billingaddress (
    id integer NOT NULL,
    street_address character varying(100) NOT NULL,
    city character varying(50) NOT NULL,
    postal_code character varying(50) NOT NULL,
    country character varying(2) NOT NULL,
    cardholder_name character varying(100) NOT NULL,
    stripe_tax_id character varying(100) NOT NULL,
    vat_number character varying(100) NOT NULL,
    vat_number_validated_on timestamp with time zone,
    vat_validation_status character varying(25) NOT NULL
);


--
-- Name: utils_billingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.utils_billingaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utils_billingaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.utils_billingaddress_id_seq OWNED BY public.utils_billingaddress.id;


--
-- Name: utils_contactmessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.utils_contactmessage (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    email character varying(254) NOT NULL,
    phone_number character varying(200) NOT NULL,
    message text NOT NULL,
    received_date timestamp with time zone NOT NULL
);


--
-- Name: utils_contactmessage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.utils_contactmessage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utils_contactmessage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.utils_contactmessage_id_seq OWNED BY public.utils_contactmessage.id;


--
-- Name: utils_userbillingaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.utils_userbillingaddress (
    id integer NOT NULL,
    street_address character varying(100) NOT NULL,
    city character varying(50) NOT NULL,
    postal_code character varying(50) NOT NULL,
    country character varying(2) NOT NULL,
    current boolean NOT NULL,
    user_id integer NOT NULL,
    cardholder_name character varying(100) NOT NULL,
    stripe_tax_id character varying(100) NOT NULL,
    vat_number character varying(100) NOT NULL,
    vat_number_validated_on timestamp with time zone,
    vat_validation_status character varying(25) NOT NULL
);


--
-- Name: utils_userbillingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.utils_userbillingaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utils_userbillingaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.utils_userbillingaddress_id_seq OWNED BY public.utils_userbillingaddress.id;


--
-- Name: aldryn_categories_category id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_categories_category ALTER COLUMN id SET DEFAULT nextval('public.aldryn_categories_category_id_seq'::regclass);


--
-- Name: aldryn_categories_category_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_categories_category_translation ALTER COLUMN id SET DEFAULT nextval('public.aldryn_categories_category_translation_id_seq'::regclass);


--
-- Name: aldryn_newsblog_article id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article ALTER COLUMN id SET DEFAULT nextval('public.aldryn_newsblog_article_id_seq'::regclass);


--
-- Name: aldryn_newsblog_article_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_categories ALTER COLUMN id SET DEFAULT nextval('public.aldryn_newsblog_article_categories_id_seq'::regclass);


--
-- Name: aldryn_newsblog_article_related id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_related ALTER COLUMN id SET DEFAULT nextval('public.aldryn_newsblog_article_related_id_seq'::regclass);


--
-- Name: aldryn_newsblog_article_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_translation ALTER COLUMN id SET DEFAULT nextval('public.aldryn_newsblog_article_translation_id_seq'::regclass);


--
-- Name: aldryn_newsblog_newsblogconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig ALTER COLUMN id SET DEFAULT nextval('public.aldryn_newsblog_newsblogconfig_id_seq'::regclass);


--
-- Name: aldryn_newsblog_newsblogconfig_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig_translation ALTER COLUMN id SET DEFAULT nextval('public.aldryn_newsblog_newsblogconfig_translation_id_seq'::regclass);


--
-- Name: aldryn_people_group id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_group ALTER COLUMN id SET DEFAULT nextval('public.aldryn_people_group_id_seq'::regclass);


--
-- Name: aldryn_people_group_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_group_translation ALTER COLUMN id SET DEFAULT nextval('public.aldryn_people_group_translation_id_seq'::regclass);


--
-- Name: aldryn_people_peopleplugin_people id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_peopleplugin_people ALTER COLUMN id SET DEFAULT nextval('public.aldryn_people_peopleplugin_people_id_seq'::regclass);


--
-- Name: aldryn_people_person id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person ALTER COLUMN id SET DEFAULT nextval('public.aldryn_people_person_id_seq'::regclass);


--
-- Name: aldryn_people_person_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_groups ALTER COLUMN id SET DEFAULT nextval('public.aldryn_people_person_groups_id_seq'::regclass);


--
-- Name: aldryn_people_person_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_translation ALTER COLUMN id SET DEFAULT nextval('public.aldryn_people_person_translation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: cms_cmsplugin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin ALTER COLUMN id SET DEFAULT nextval('public.cms_cmsplugin_id_seq'::regclass);


--
-- Name: cms_globalpagepermission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission ALTER COLUMN id SET DEFAULT nextval('public.cms_globalpagepermission_id_seq'::regclass);


--
-- Name: cms_globalpagepermission_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites ALTER COLUMN id SET DEFAULT nextval('public.cms_globalpagepermission_sites_id_seq'::regclass);


--
-- Name: cms_page id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page ALTER COLUMN id SET DEFAULT nextval('public.cms_page_id_seq'::regclass);


--
-- Name: cms_page_placeholders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page_placeholders ALTER COLUMN id SET DEFAULT nextval('public.cms_page_placeholders_id_seq'::regclass);


--
-- Name: cms_pagepermission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission ALTER COLUMN id SET DEFAULT nextval('public.cms_pagepermission_id_seq'::regclass);


--
-- Name: cms_placeholder id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholder ALTER COLUMN id SET DEFAULT nextval('public.cms_placeholder_id_seq'::regclass);


--
-- Name: cms_staticplaceholder id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder ALTER COLUMN id SET DEFAULT nextval('public.cms_staticplaceholder_id_seq'::regclass);


--
-- Name: cms_title id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_title ALTER COLUMN id SET DEFAULT nextval('public.cms_title_id_seq'::regclass);


--
-- Name: cms_urlconfrevision id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_urlconfrevision ALTER COLUMN id SET DEFAULT nextval('public.cms_urlconfrevision_id_seq'::regclass);


--
-- Name: cms_usersettings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings ALTER COLUMN id SET DEFAULT nextval('public.cms_usersettings_id_seq'::regclass);


--
-- Name: cmsplugin_filer_image_thumbnailoption id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_thumbnailoption ALTER COLUMN id SET DEFAULT nextval('public.cmsplugin_filer_image_thumbnailoption_id_seq'::regclass);


--
-- Name: datacenterlight_cmsfaviconextension id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsfaviconextension ALTER COLUMN id SET DEFAULT nextval('public.datacenterlight_cmsfaviconextension_id_seq'::regclass);


--
-- Name: datacenterlight_cmsintegration id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsintegration ALTER COLUMN id SET DEFAULT nextval('public.datacenterlight_cmsintegration_id_seq'::regclass);


--
-- Name: datacenterlight_contactus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_contactus ALTER COLUMN id SET DEFAULT nextval('public.datacenterlight_contactus_id_seq'::regclass);


--
-- Name: datacenterlight_stripeplan id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_stripeplan ALTER COLUMN id SET DEFAULT nextval('public.datacenterlight_stripeplan_id_seq'::regclass);


--
-- Name: datacenterlight_vmpricing id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_vmpricing ALTER COLUMN id SET DEFAULT nextval('public.datacenterlight_vmpricing_id_seq'::regclass);


--
-- Name: datacenterlight_vmtemplate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_vmtemplate ALTER COLUMN id SET DEFAULT nextval('public.datacenterlight_vmtemplate_id_seq'::regclass);


--
-- Name: digitalglarus_booking id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_booking ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_booking_id_seq'::regclass);


--
-- Name: digitalglarus_bookingcancellation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingcancellation ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_bookingcancellation_id_seq'::regclass);


--
-- Name: digitalglarus_bookingorder id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingorder ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_bookingorder_id_seq'::regclass);


--
-- Name: digitalglarus_bookingprice id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingprice ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_bookingprices_id_seq'::regclass);


--
-- Name: digitalglarus_dggallery id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dggallery ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_dggallery_id_seq'::regclass);


--
-- Name: digitalglarus_dgpicture id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dgpicture ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_dgpicture_id_seq'::regclass);


--
-- Name: digitalglarus_membership id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membership ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_membership_id_seq'::regclass);


--
-- Name: digitalglarus_membershiporder id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membershiporder ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_membershiporder_id_seq'::regclass);


--
-- Name: digitalglarus_membershiptype id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membershiptype ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_membershiptype_id_seq'::regclass);


--
-- Name: digitalglarus_supporter id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_supporter ALTER COLUMN id SET DEFAULT nextval('public.digitalglarus_supporter_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_celery_results_taskresult id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_results_taskresult ALTER COLUMN id SET DEFAULT nextval('public.django_celery_results_taskresult_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: djangocms_blog_authorentriesplugin_authors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin_authors ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_authorentriesplugin_authors_id_seq'::regclass);


--
-- Name: djangocms_blog_blogcategory id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_blogcategory_id_seq'::regclass);


--
-- Name: djangocms_blog_blogcategory_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory_translation ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_blogcategory_translation_id_seq'::regclass);


--
-- Name: djangocms_blog_blogconfig id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogconfig ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_blogconfig_id_seq'::regclass);


--
-- Name: djangocms_blog_blogconfig_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogconfig_translation ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_blogconfig_translation_id_seq'::regclass);


--
-- Name: djangocms_blog_latestpostsplugin_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin_categories ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_latestpostsplugin_categories_id_seq'::regclass);


--
-- Name: djangocms_blog_post id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_post_id_seq'::regclass);


--
-- Name: djangocms_blog_post_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_categories ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_post_categories_id_seq'::regclass);


--
-- Name: djangocms_blog_post_related id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_related ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_post_related_id_seq'::regclass);


--
-- Name: djangocms_blog_post_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_sites ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_post_sites_id_seq'::regclass);


--
-- Name: djangocms_blog_post_translation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_translation ALTER COLUMN id SET DEFAULT nextval('public.djangocms_blog_post_translation_id_seq'::regclass);


--
-- Name: djangocms_page_meta_pagemeta id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta ALTER COLUMN id SET DEFAULT nextval('public.djangocms_page_meta_pagemeta_id_seq'::regclass);


--
-- Name: djangocms_page_meta_titlemeta id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_titlemeta ALTER COLUMN id SET DEFAULT nextval('public.djangocms_page_meta_titlemeta_id_seq'::regclass);


--
-- Name: easy_thumbnails_source id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_source ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_source_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnail_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnaildimensions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnaildimensions_id_seq'::regclass);


--
-- Name: filer_clipboard id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboard ALTER COLUMN id SET DEFAULT nextval('public.filer_clipboard_id_seq'::regclass);


--
-- Name: filer_clipboarditem id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboarditem ALTER COLUMN id SET DEFAULT nextval('public.filer_clipboarditem_id_seq'::regclass);


--
-- Name: filer_file id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file ALTER COLUMN id SET DEFAULT nextval('public.filer_file_id_seq'::regclass);


--
-- Name: filer_folder id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder ALTER COLUMN id SET DEFAULT nextval('public.filer_folder_id_seq'::regclass);


--
-- Name: filer_folderpermission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission ALTER COLUMN id SET DEFAULT nextval('public.filer_folderpermission_id_seq'::regclass);


--
-- Name: filer_thumbnailoption id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_thumbnailoption ALTER COLUMN id SET DEFAULT nextval('public.filer_thumbnailoption_id_seq'::regclass);


--
-- Name: guardian_groupobjectpermission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_groupobjectpermission ALTER COLUMN id SET DEFAULT nextval('public.guardian_groupobjectpermission_id_seq'::regclass);


--
-- Name: guardian_userobjectpermission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_userobjectpermission ALTER COLUMN id SET DEFAULT nextval('public.guardian_userobjectpermission_id_seq'::regclass);


--
-- Name: hosting_genericproduct id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_genericproduct ALTER COLUMN id SET DEFAULT nextval('public.hosting_genericproduct_id_seq'::regclass);


--
-- Name: hosting_hostingbill id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbill ALTER COLUMN id SET DEFAULT nextval('public.hosting_hostingbill_id_seq'::regclass);


--
-- Name: hosting_hostingbilllineitem id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbilllineitem ALTER COLUMN id SET DEFAULT nextval('public.hosting_hostingbilllineitem_id_seq'::regclass);


--
-- Name: hosting_hostingorder id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingorder ALTER COLUMN id SET DEFAULT nextval('public.hosting_hostingorder_id_seq'::regclass);


--
-- Name: hosting_hostingplan id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingplan ALTER COLUMN id SET DEFAULT nextval('public.hosting_hostingplan_id_seq'::regclass);


--
-- Name: hosting_incompletepaymentintents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_incompletepaymentintents ALTER COLUMN id SET DEFAULT nextval('public.hosting_incompletepaymentintents_id_seq'::regclass);


--
-- Name: hosting_incompletesubscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_incompletesubscriptions ALTER COLUMN id SET DEFAULT nextval('public.hosting_incompletesubscriptions_id_seq'::regclass);


--
-- Name: hosting_monthlyhostingbill id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_monthlyhostingbill ALTER COLUMN id SET DEFAULT nextval('public.hosting_monthlyhostingbill_id_seq'::regclass);


--
-- Name: hosting_orderdetail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_orderdetail ALTER COLUMN id SET DEFAULT nextval('public.hosting_orderdetail_id_seq'::regclass);


--
-- Name: hosting_stripetaxrate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_stripetaxrate ALTER COLUMN id SET DEFAULT nextval('public.hosting_stripetaxrate_id_seq'::regclass);


--
-- Name: hosting_usercarddetail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_usercarddetail ALTER COLUMN id SET DEFAULT nextval('public.hosting_usercarddetail_id_seq'::regclass);


--
-- Name: hosting_userhostingkey id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_userhostingkey ALTER COLUMN id SET DEFAULT nextval('public.hosting_userhostingkey_id_seq'::regclass);


--
-- Name: hosting_vatrates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_vatrates ALTER COLUMN id SET DEFAULT nextval('public.hosting_vatrates_id_seq'::regclass);


--
-- Name: hosting_vmdetail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_vmdetail ALTER COLUMN id SET DEFAULT nextval('public.hosting_vmdetail_id_seq'::regclass);


--
-- Name: membership_calendar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_calendar ALTER COLUMN id SET DEFAULT nextval('public.membership_calendar_id_seq'::regclass);


--
-- Name: membership_creditcards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_creditcards ALTER COLUMN id SET DEFAULT nextval('public.membership_creditcards_id_seq'::regclass);


--
-- Name: membership_customuser id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser ALTER COLUMN id SET DEFAULT nextval('public.membership_customuser_id_seq'::regclass);


--
-- Name: membership_customuser_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_groups ALTER COLUMN id SET DEFAULT nextval('public.membership_customuser_groups_id_seq'::regclass);


--
-- Name: membership_customuser_user_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.membership_customuser_user_permissions_id_seq'::regclass);


--
-- Name: membership_deleteduser id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_deleteduser ALTER COLUMN id SET DEFAULT nextval('public.membership_deleteduser_id_seq'::regclass);


--
-- Name: membership_stripecustomer id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_stripecustomer ALTER COLUMN id SET DEFAULT nextval('public.membership_stripecustomer_id_seq'::regclass);


--
-- Name: menus_cachekey id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_cachekey ALTER COLUMN id SET DEFAULT nextval('public.menus_cachekey_id_seq'::regclass);


--
-- Name: multisite_alias id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.multisite_alias ALTER COLUMN id SET DEFAULT nextval('public.multisite_alias_id_seq'::regclass);


--
-- Name: nosystemd_donation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donation ALTER COLUMN id SET DEFAULT nextval('public.nosystemd_donation_id_seq'::regclass);


--
-- Name: nosystemd_donatorstatus id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donatorstatus ALTER COLUMN id SET DEFAULT nextval('public.nosystemd_donatorstatus_id_seq'::regclass);


--
-- Name: reversion_revision id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reversion_revision ALTER COLUMN id SET DEFAULT nextval('public.reversion_revision_id_seq'::regclass);


--
-- Name: reversion_version id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reversion_version ALTER COLUMN id SET DEFAULT nextval('public.reversion_version_id_seq'::regclass);


--
-- Name: stored_messages_inbox id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_inbox ALTER COLUMN id SET DEFAULT nextval('public.stored_messages_inbox_id_seq'::regclass);


--
-- Name: stored_messages_message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_message ALTER COLUMN id SET DEFAULT nextval('public.stored_messages_message_id_seq'::regclass);


--
-- Name: stored_messages_messagearchive id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_messagearchive ALTER COLUMN id SET DEFAULT nextval('public.stored_messages_messagearchive_id_seq'::regclass);


--
-- Name: taggit_tag id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag ALTER COLUMN id SET DEFAULT nextval('public.taggit_tag_id_seq'::regclass);


--
-- Name: taggit_taggeditem id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem ALTER COLUMN id SET DEFAULT nextval('public.taggit_taggeditem_id_seq'::regclass);


--
-- Name: ungleich_ungleichpage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_ungleichpage ALTER COLUMN id SET DEFAULT nextval('public.ungleich_ungleichpage_id_seq'::regclass);


--
-- Name: utils_billingaddress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utils_billingaddress ALTER COLUMN id SET DEFAULT nextval('public.utils_billingaddress_id_seq'::regclass);


--
-- Name: utils_contactmessage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utils_contactmessage ALTER COLUMN id SET DEFAULT nextval('public.utils_contactmessage_id_seq'::regclass);


--
-- Name: utils_userbillingaddress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utils_userbillingaddress ALTER COLUMN id SET DEFAULT nextval('public.utils_userbillingaddress_id_seq'::regclass);


--
-- Data for Name: aldryn_categories_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_categories_category (id, lft, rgt, tree_id, depth) FROM stdin;
\.


--
-- Data for Name: aldryn_categories_category_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_categories_category_translation (id, language_code, name, slug, master_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_article; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_article (id, publishing_date, is_published, is_featured, app_config_id, author_id, content_id, featured_image_id, owner_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_article_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_article_categories (id, article_id, category_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_article_related; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_article_related (id, from_article_id, to_article_id, sort_value) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_article_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_article_translation (id, language_code, title, slug, lead_in, meta_title, meta_description, meta_keywords, search_data, master_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogarchiveplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogarchiveplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogarticlesearchplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogarticlesearchplugin (cmsplugin_ptr_id, max_articles, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogauthorsplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogauthorsplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogcategoriesplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogcategoriesplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogconfig (id, type, namespace, app_data, permalink_type, non_permalink_handling, paginate_by, create_authors, search_indexed, placeholder_base_sidebar_id, placeholder_base_top_id, placeholder_detail_bottom_id, placeholder_detail_footer_id, placeholder_detail_top_id, placeholder_list_footer_id, placeholder_list_top_id, template_prefix, pagination_pages_start, pagination_pages_visible) FROM stdin;
1	aldryn_newsblog.cms_appconfig.NewsBlogConfig	aldryn_newsblog_default	{}	slug	302	5	t	t	1	2	3	4	5	6	7	\N	10	4
\.


--
-- Data for Name: aldryn_newsblog_newsblogconfig_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogconfig_translation (id, language_code, app_title, master_id) FROM stdin;
1	en-us	News & Blog	1
\.


--
-- Data for Name: aldryn_newsblog_newsblogfeaturedarticlesplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogfeaturedarticlesplugin (cmsplugin_ptr_id, article_count, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsbloglatestarticlesplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsbloglatestarticlesplugin (cmsplugin_ptr_id, latest_articles, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogrelatedplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogrelatedplugin (cmsplugin_ptr_id) FROM stdin;
\.


--
-- Data for Name: aldryn_newsblog_newsblogtagsplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_newsblog_newsblogtagsplugin (cmsplugin_ptr_id, app_config_id) FROM stdin;
\.


--
-- Data for Name: aldryn_people_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_people_group (id, address, postal_code, city, phone, fax, email, website) FROM stdin;
\.


--
-- Data for Name: aldryn_people_group_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_people_group_translation (id, name, description, language_code, master_id, slug) FROM stdin;
\.


--
-- Data for Name: aldryn_people_peopleplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_people_peopleplugin (cmsplugin_ptr_id, style, group_by_group, show_links, show_vcard, show_ungrouped) FROM stdin;
\.


--
-- Data for Name: aldryn_people_peopleplugin_people; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_people_peopleplugin_people (id, peopleplugin_id, person_id, sort_value) FROM stdin;
\.


--
-- Data for Name: aldryn_people_person; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_people_person (id, phone, mobile, fax, email, website, vcard_enabled, user_id, visual_id) FROM stdin;
\.


--
-- Data for Name: aldryn_people_person_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_people_person_groups (id, person_id, group_id, sort_value) FROM stdin;
\.


--
-- Data for Name: aldryn_people_person_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aldryn_people_person_translation (id, function, description, language_code, master_id, name, slug) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can use Structure mode	1	use_structure
2	Can change page	2	change_page
3	Can add custom user	4	add_customuser
4	Can change custom user	4	change_customuser
5	Can delete custom user	4	delete_customuser
6	Can add stripe customer	5	add_stripecustomer
7	Can change stripe customer	5	change_stripecustomer
8	Can delete stripe customer	5	delete_stripecustomer
9	Can add credit cards	6	add_creditcards
10	Can change credit cards	6	change_creditcards
11	Can delete credit cards	6	delete_creditcards
12	Can add deleted user	7	add_deleteduser
13	Can change deleted user	7	change_deleteduser
14	Can delete deleted user	7	delete_deleteduser
15	Can add calendar	8	add_calendar
16	Can change calendar	8	change_calendar
17	Can delete calendar	8	delete_calendar
18	Can add log entry	9	add_logentry
19	Can change log entry	9	change_logentry
20	Can delete log entry	9	delete_logentry
21	Can add permission	10	add_permission
22	Can change permission	10	change_permission
23	Can delete permission	10	delete_permission
24	Can add group	11	add_group
25	Can change group	11	change_group
26	Can delete group	11	delete_group
27	Can add content type	12	add_contenttype
28	Can change content type	12	change_contenttype
29	Can delete content type	12	delete_contenttype
30	Can add session	13	add_session
31	Can change session	13	change_session
32	Can delete session	13	delete_session
33	Can add site	14	add_site
34	Can change site	14	change_site
35	Can delete site	14	delete_site
36	Can add alias	15	add_alias
37	Can change alias	15	change_alias
38	Can delete alias	15	delete_alias
39	Can add source	16	add_source
40	Can change source	16	change_source
41	Can delete source	16	delete_source
42	Can add thumbnail	17	add_thumbnail
43	Can change thumbnail	17	change_thumbnail
44	Can delete thumbnail	17	delete_thumbnail
45	Can add thumbnail dimensions	18	add_thumbnaildimensions
46	Can change thumbnail dimensions	18	change_thumbnaildimensions
47	Can delete thumbnail dimensions	18	delete_thumbnaildimensions
48	Can add billing address	19	add_billingaddress
49	Can change billing address	19	change_billingaddress
50	Can delete billing address	19	delete_billingaddress
51	Can add user billing address	20	add_userbillingaddress
52	Can change user billing address	20	change_userbillingaddress
53	Can delete user billing address	20	delete_userbillingaddress
54	Can add contact message	21	add_contactmessage
55	Can change contact message	21	change_contactmessage
56	Can delete contact message	21	delete_contactmessage
57	Can add message	22	add_message
58	Can change message	22	change_message
59	Can delete message	22	delete_message
60	Can add message archive	23	add_messagearchive
61	Can change message archive	23	change_messagearchive
62	Can delete message archive	23	delete_messagearchive
63	Can add inbox	24	add_inbox
64	Can change inbox	24	change_inbox
65	Can delete inbox	24	delete_inbox
66	Can add user object permission	25	add_userobjectpermission
67	Can change user object permission	25	change_userobjectpermission
68	Can delete user object permission	25	delete_userobjectpermission
69	Can add group object permission	26	add_groupobjectpermission
70	Can change group object permission	26	change_groupobjectpermission
71	Can delete group object permission	26	delete_groupobjectpermission
72	Can add Tag	27	add_tag
73	Can change Tag	27	change_tag
74	Can delete Tag	27	delete_tag
75	Can add Tagged Item	28	add_taggeditem
76	Can change Tagged Item	28	change_taggeditem
77	Can delete Tagged Item	28	delete_taggeditem
78	Can add Folder	29	add_folder
79	Can change Folder	29	change_folder
80	Can delete Folder	29	delete_folder
81	Can use directory listing	29	can_use_directory_listing
82	Can add folder permission	30	add_folderpermission
83	Can change folder permission	30	change_folderpermission
84	Can delete folder permission	30	delete_folderpermission
85	Can add file	31	add_file
86	Can change file	31	change_file
87	Can delete file	31	delete_file
88	Can add clipboard	32	add_clipboard
89	Can change clipboard	32	change_clipboard
90	Can delete clipboard	32	delete_clipboard
91	Can add clipboard item	33	add_clipboarditem
92	Can change clipboard item	33	change_clipboarditem
93	Can delete clipboard item	33	delete_clipboarditem
94	Can add image	34	add_image
95	Can change image	34	change_image
96	Can delete image	34	delete_image
97	Can add thumbnail option	35	add_thumbnailoption
98	Can change thumbnail option	35	change_thumbnailoption
99	Can delete thumbnail option	35	delete_thumbnailoption
100	Can add blog config	37	add_blogconfig
101	Can change blog config	37	change_blogconfig
102	Can delete blog config	37	delete_blogconfig
103	Can add blog category	39	add_blogcategory
104	Can change blog category	39	change_blogcategory
105	Can delete blog category	39	delete_blogcategory
106	Can add blog article	41	add_post
107	Can change blog article	41	change_post
108	Can delete blog article	41	delete_post
109	Can add latest posts plugin	3	add_latestpostsplugin
110	Can change latest posts plugin	3	change_latestpostsplugin
111	Can delete latest posts plugin	3	delete_latestpostsplugin
112	Can add author entries plugin	42	add_authorentriesplugin
113	Can change author entries plugin	42	change_authorentriesplugin
114	Can delete author entries plugin	42	delete_authorentriesplugin
115	Can add generic blog plugin	43	add_genericblogplugin
116	Can change generic blog plugin	43	change_genericblogplugin
117	Can delete generic blog plugin	43	delete_genericblogplugin
118	Can add user setting	44	add_usersettings
119	Can change user setting	44	change_usersettings
120	Can delete user setting	44	delete_usersettings
121	Can add page	2	add_page
122	Can delete page	2	delete_page
123	Can view page	2	view_page
124	Can publish page	2	publish_page
125	Can edit static placeholders	2	edit_static_placeholder
126	Can add Page global permission	45	add_globalpagepermission
127	Can change Page global permission	45	change_globalpagepermission
128	Can delete Page global permission	45	delete_globalpagepermission
129	Can add Page permission	46	add_pagepermission
130	Can change Page permission	46	change_pagepermission
131	Can delete Page permission	46	delete_pagepermission
132	Can add User (page)	47	add_pageuser
133	Can change User (page)	47	change_pageuser
134	Can delete User (page)	47	delete_pageuser
135	Can add User group (page)	48	add_pageusergroup
136	Can change User group (page)	48	change_pageusergroup
137	Can delete User group (page)	48	delete_pageusergroup
138	Can add placeholder	1	add_placeholder
139	Can change placeholder	1	change_placeholder
140	Can delete placeholder	1	delete_placeholder
141	Can add cms plugin	49	add_cmsplugin
142	Can change cms plugin	49	change_cmsplugin
143	Can delete cms plugin	49	delete_cmsplugin
144	Can add title	50	add_title
145	Can change title	50	change_title
146	Can delete title	50	delete_title
147	Can add placeholder reference	51	add_placeholderreference
148	Can change placeholder reference	51	change_placeholderreference
149	Can delete placeholder reference	51	delete_placeholderreference
150	Can add static placeholder	52	add_staticplaceholder
151	Can change static placeholder	52	change_staticplaceholder
152	Can delete static placeholder	52	delete_staticplaceholder
153	Can add alias plugin model	53	add_aliaspluginmodel
154	Can change alias plugin model	53	change_aliaspluginmodel
155	Can delete alias plugin model	53	delete_aliaspluginmodel
156	Can add urlconf revision	54	add_urlconfrevision
157	Can change urlconf revision	54	change_urlconfrevision
158	Can delete urlconf revision	54	delete_urlconfrevision
159	Can add category	56	add_category
160	Can change category	56	change_category
161	Can delete category	56	delete_category
162	Can add config	58	add_newsblogconfig
163	Can change config	58	change_newsblogconfig
164	Can delete config	58	delete_newsblogconfig
165	Can add article	60	add_article
166	Can change article	60	change_article
167	Can delete article	60	delete_article
168	Can add news blog archive plugin	61	add_newsblogarchiveplugin
169	Can change news blog archive plugin	61	change_newsblogarchiveplugin
170	Can delete news blog archive plugin	61	delete_newsblogarchiveplugin
171	Can add news blog article search plugin	62	add_newsblogarticlesearchplugin
172	Can change news blog article search plugin	62	change_newsblogarticlesearchplugin
173	Can delete news blog article search plugin	62	delete_newsblogarticlesearchplugin
174	Can add news blog authors plugin	63	add_newsblogauthorsplugin
175	Can change news blog authors plugin	63	change_newsblogauthorsplugin
176	Can delete news blog authors plugin	63	delete_newsblogauthorsplugin
177	Can add news blog categories plugin	64	add_newsblogcategoriesplugin
178	Can change news blog categories plugin	64	change_newsblogcategoriesplugin
179	Can delete news blog categories plugin	64	delete_newsblogcategoriesplugin
180	Can add news blog featured articles plugin	65	add_newsblogfeaturedarticlesplugin
181	Can change news blog featured articles plugin	65	change_newsblogfeaturedarticlesplugin
182	Can delete news blog featured articles plugin	65	delete_newsblogfeaturedarticlesplugin
183	Can add news blog latest articles plugin	66	add_newsbloglatestarticlesplugin
184	Can change news blog latest articles plugin	66	change_newsbloglatestarticlesplugin
185	Can delete news blog latest articles plugin	66	delete_newsbloglatestarticlesplugin
186	Can add news blog related plugin	67	add_newsblogrelatedplugin
187	Can change news blog related plugin	67	change_newsblogrelatedplugin
188	Can delete news blog related plugin	67	delete_newsblogrelatedplugin
189	Can add news blog tags plugin	68	add_newsblogtagsplugin
190	Can change news blog tags plugin	68	change_newsblogtagsplugin
191	Can delete news blog tags plugin	68	delete_newsblogtagsplugin
192	Can add Group	70	add_group
193	Can change Group	70	change_group
194	Can delete Group	70	delete_group
195	Can add Person	72	add_person
196	Can change Person	72	change_person
197	Can delete Person	72	delete_person
198	Can add people plugin	73	add_peopleplugin
199	Can change people plugin	73	change_peopleplugin
200	Can delete people plugin	73	delete_peopleplugin
201	Can add cache key	74	add_cachekey
202	Can change cache key	74	change_cachekey
203	Can delete cache key	74	delete_cachekey
204	Can add filer image	75	add_filerimage
205	Can change filer image	75	change_filerimage
206	Can delete filer image	75	delete_filerimage
207	Can add thumbnail option	76	add_thumbnailoption
208	Can change thumbnail option	76	change_thumbnailoption
209	Can delete thumbnail option	76	delete_thumbnailoption
210	Can add file	77	add_file
211	Can change file	77	change_file
212	Can delete file	77	delete_file
213	Can add picture	78	add_picture
214	Can change picture	78	change_picture
215	Can delete picture	78	delete_picture
216	Can add video	79	add_video
217	Can change video	79	change_video
218	Can delete video	79	delete_video
219	Can add Page meta info (all languages)	80	add_pagemeta
220	Can change Page meta info (all languages)	80	change_pagemeta
221	Can delete Page meta info (all languages)	80	delete_pagemeta
222	Can add Page meta info (language-dependent)	81	add_titlemeta
223	Can change Page meta info (language-dependent)	81	change_titlemeta
224	Can delete Page meta info (language-dependent)	81	delete_titlemeta
225	Can add text	82	add_text
226	Can change text	82	change_text
227	Can delete text	82	delete_text
228	Can add filer file	83	add_filerfile
229	Can change filer file	83	change_filerfile
230	Can delete filer file	83	delete_filerfile
231	Can add filer folder	84	add_filerfolder
232	Can change filer folder	84	change_filerfolder
233	Can delete filer folder	84	delete_filerfolder
234	Can add filer link plugin	85	add_filerlinkplugin
235	Can change filer link plugin	85	change_filerlinkplugin
236	Can delete filer link plugin	85	delete_filerlinkplugin
237	Can add filer video	86	add_filervideo
238	Can change filer video	86	change_filervideo
239	Can delete filer video	86	delete_filervideo
240	Can add revision	87	add_revision
241	Can change revision	87	change_revision
242	Can delete revision	87	delete_revision
243	Can add version	88	add_version
244	Can change version	88	change_version
245	Can delete version	88	delete_version
246	Can add ungleich page	89	add_ungleichpage
247	Can change ungleich page	89	change_ungleichpage
248	Can delete ungleich page	89	delete_ungleichpage
249	Can add ungelich picture	90	add_ungelichpicture
250	Can change ungelich picture	90	change_ungelichpicture
251	Can delete ungelich picture	90	delete_ungelichpicture
252	Can add section with image	91	add_sectionwithimage
253	Can change section with image	91	change_sectionwithimage
254	Can delete section with image	91	delete_sectionwithimage
255	Can add ungelich contact us section	92	add_ungelichcontactussection
256	Can change ungelich contact us section	92	change_ungelichcontactussection
257	Can delete ungelich contact us section	92	delete_ungelichcontactussection
258	Can add ungelich text section	93	add_ungelichtextsection
259	Can change ungelich text section	93	change_ungelichtextsection
260	Can delete ungelich text section	93	delete_ungelichtextsection
261	Can add service	94	add_service
262	Can change service	94	change_service
263	Can delete service	94	delete_service
264	Can add service item	95	add_serviceitem
265	Can change service item	95	change_serviceitem
266	Can delete service item	95	delete_serviceitem
267	Can add about	96	add_about
268	Can change about	96	change_about
269	Can delete about	96	delete_about
270	Can add about item	97	add_aboutitem
271	Can change about item	97	change_aboutitem
272	Can delete about item	97	delete_aboutitem
273	Can add ungleich service item	98	add_ungleichserviceitem
274	Can change ungleich service item	98	change_ungleichserviceitem
275	Can delete ungleich service item	98	delete_ungleichserviceitem
276	Can add ungleich header with background image slider	99	add_ungleichheaderwithbackgroundimageslider
277	Can change ungleich header with background image slider	99	change_ungleichheaderwithbackgroundimageslider
278	Can delete ungleich header with background image slider	99	delete_ungleichheaderwithbackgroundimageslider
279	Can add ungleich header with background video slider item	100	add_ungleichheaderwithbackgroundvideoslideritem
280	Can change ungleich header with background video slider item	100	change_ungleichheaderwithbackgroundvideoslideritem
281	Can delete ungleich header with background video slider item	100	delete_ungleichheaderwithbackgroundvideoslideritem
282	Can add ungleich product item	101	add_ungleichproductitem
283	Can change ungleich product item	101	change_ungleichproductitem
284	Can delete ungleich product item	101	delete_ungleichproductitem
285	Can add ungleich product	102	add_ungleichproduct
286	Can change ungleich product	102	change_ungleichproduct
287	Can delete ungleich product	102	delete_ungleichproduct
288	Can add ungleich customer	103	add_ungleichcustomer
289	Can change ungleich customer	103	change_ungleichcustomer
290	Can delete ungleich customer	103	delete_ungleichcustomer
291	Can add ungleich customer item	104	add_ungleichcustomeritem
292	Can change ungleich customer item	104	change_ungleichcustomeritem
293	Can delete ungleich customer item	104	delete_ungleichcustomeritem
294	Can add ungleich html only	105	add_ungleichhtmlonly
295	Can change ungleich html only	105	change_ungleichhtmlonly
296	Can delete ungleich html only	105	delete_ungleichhtmlonly
297	Can add ungleich footer	106	add_ungleichfooter
298	Can change ungleich footer	106	change_ungleichfooter
299	Can delete ungleich footer	106	delete_ungleichfooter
300	Can add hosting plan	107	add_hostingplan
301	Can change hosting plan	107	change_hostingplan
302	Can delete hosting plan	107	delete_hostingplan
303	Can add order detail	108	add_orderdetail
304	Can change order detail	108	change_orderdetail
305	Can delete order detail	108	delete_orderdetail
306	Can add generic product	109	add_genericproduct
307	Can change generic product	109	change_genericproduct
308	Can delete generic product	109	delete_genericproduct
309	Can add hosting order	110	add_hostingorder
310	Can change hosting order	110	change_hostingorder
311	Can delete hosting order	110	delete_hostingorder
312	View Hosting Order	110	view_hostingorder
313	Can add user hosting key	111	add_userhostingkey
314	Can change user hosting key	111	change_userhostingkey
315	Can delete user hosting key	111	delete_userhostingkey
316	Can add hosting bill	112	add_hostingbill
317	Can change hosting bill	112	change_hostingbill
318	Can delete hosting bill	112	delete_hostingbill
319	View Hosting Bill	112	view_hostingbill
320	Can add monthly hosting bill	113	add_monthlyhostingbill
321	Can change monthly hosting bill	113	change_monthlyhostingbill
322	Can delete monthly hosting bill	113	delete_monthlyhostingbill
323	View Monthly Hosting	113	view_monthlyhostingbill
324	Can add hosting bill line item	114	add_hostingbilllineitem
325	Can change hosting bill line item	114	change_hostingbilllineitem
326	Can delete hosting bill line item	114	delete_hostingbilllineitem
327	View Monthly Hosting Bill Line Item	114	view_hostingbilllineitem
328	Can add vm detail	115	add_vmdetail
329	Can change vm detail	115	change_vmdetail
330	Can delete vm detail	115	delete_vmdetail
331	Can add user card detail	116	add_usercarddetail
332	Can change user card detail	116	change_usercarddetail
333	Can delete user card detail	116	delete_usercarddetail
334	View User Card	116	view_usercarddetail
335	Can add vat rates	117	add_vatrates
336	Can change vat rates	117	change_vatrates
337	Can delete vat rates	117	delete_vatrates
338	Can add stripe tax rate	118	add_stripetaxrate
339	Can change stripe tax rate	118	change_stripetaxrate
340	Can delete stripe tax rate	118	delete_stripetaxrate
341	Can add incomplete payment intents	119	add_incompletepaymentintents
342	Can change incomplete payment intents	119	change_incompletepaymentintents
343	Can delete incomplete payment intents	119	delete_incompletepaymentintents
344	Can add incomplete subscriptions	120	add_incompletesubscriptions
345	Can change incomplete subscriptions	120	change_incompletesubscriptions
346	Can delete incomplete subscriptions	120	delete_incompletesubscriptions
347	Can add membership type	121	add_membershiptype
348	Can change membership type	121	change_membershiptype
349	Can delete membership type	121	delete_membershiptype
350	Can add membership	122	add_membership
351	Can change membership	122	change_membership
352	Can delete membership	122	delete_membership
353	Can add membership order	123	add_membershiporder
354	Can change membership order	123	change_membershiporder
355	Can delete membership order	123	delete_membershiporder
356	Can add booking price	124	add_bookingprice
357	Can change booking price	124	change_bookingprice
358	Can delete booking price	124	delete_bookingprice
359	Can add booking	125	add_booking
360	Can change booking	125	change_booking
361	Can delete booking	125	delete_booking
362	Can add booking order	126	add_bookingorder
363	Can change booking order	126	change_bookingorder
364	Can delete booking order	126	delete_bookingorder
365	Can add booking cancellation	127	add_bookingcancellation
366	Can change booking cancellation	127	change_bookingcancellation
367	Can delete booking cancellation	127	delete_bookingcancellation
368	Can add supporter	128	add_supporter
369	Can change supporter	128	change_supporter
370	Can delete supporter	128	delete_supporter
371	Can add dg gallery	129	add_dggallery
372	Can change dg gallery	129	change_dggallery
373	Can delete dg gallery	129	delete_dggallery
374	Can add dg picture	130	add_dgpicture
375	Can change dg picture	130	change_dgpicture
376	Can delete dg picture	130	delete_dgpicture
377	Can add dg gallery plugin	131	add_dggalleryplugin
378	Can change dg gallery plugin	131	change_dggalleryplugin
379	Can delete dg gallery plugin	131	delete_dggalleryplugin
380	Can add dg supporters plugin	132	add_dgsupportersplugin
381	Can change dg supporters plugin	132	change_dgsupportersplugin
382	Can delete dg supporters plugin	132	delete_dgsupportersplugin
383	Can add donator status	133	add_donatorstatus
384	Can change donator status	133	change_donatorstatus
385	Can delete donator status	133	delete_donatorstatus
386	Can add donation	134	add_donation
387	Can change donation	134	change_donation
388	Can delete donation	134	delete_donation
389	Can add vm template	135	add_vmtemplate
390	Can change vm template	135	change_vmtemplate
391	Can delete vm template	135	delete_vmtemplate
392	Can add vm pricing	136	add_vmpricing
393	Can change vm pricing	136	change_vmpricing
394	Can delete vm pricing	136	delete_vmpricing
395	Can add stripe plan	137	add_stripeplan
396	Can change stripe plan	137	change_stripeplan
397	Can delete stripe plan	137	delete_stripeplan
398	Can add contact us	138	add_contactus
399	Can change contact us	138	change_contactus
400	Can delete contact us	138	delete_contactus
401	Can add cms integration	139	add_cmsintegration
402	Can change cms integration	139	change_cmsintegration
403	Can delete cms integration	139	delete_cmsintegration
404	Can add cms favicon extension	140	add_cmsfaviconextension
405	Can change cms favicon extension	140	change_cmsfaviconextension
406	Can delete cms favicon extension	140	delete_cmsfaviconextension
407	Can add dcl section plugin model	141	add_dclsectionpluginmodel
408	Can change dcl section plugin model	141	change_dclsectionpluginmodel
409	Can delete dcl section plugin model	141	delete_dclsectionpluginmodel
410	Can add dcl banner list plugin model	142	add_dclbannerlistpluginmodel
411	Can change dcl banner list plugin model	142	change_dclbannerlistpluginmodel
412	Can delete dcl banner list plugin model	142	delete_dclbannerlistpluginmodel
413	Can add dcl banner item plugin model	143	add_dclbanneritempluginmodel
414	Can change dcl banner item plugin model	143	change_dclbanneritempluginmodel
415	Can delete dcl banner item plugin model	143	delete_dclbanneritempluginmodel
416	Can add dcl link plugin model	144	add_dcllinkpluginmodel
417	Can change dcl link plugin model	144	change_dcllinkpluginmodel
418	Can delete dcl link plugin model	144	delete_dcllinkpluginmodel
419	Can add dcl navbar plugin model	145	add_dclnavbarpluginmodel
420	Can change dcl navbar plugin model	145	change_dclnavbarpluginmodel
421	Can delete dcl navbar plugin model	145	delete_dclnavbarpluginmodel
422	Can add dcl navbar dropdown plugin model	146	add_dclnavbardropdownpluginmodel
423	Can change dcl navbar dropdown plugin model	146	change_dclnavbardropdownpluginmodel
424	Can delete dcl navbar dropdown plugin model	146	delete_dclnavbardropdownpluginmodel
425	Can add dcl contact plugin model	147	add_dclcontactpluginmodel
426	Can change dcl contact plugin model	147	change_dclcontactpluginmodel
427	Can delete dcl contact plugin model	147	delete_dclcontactpluginmodel
428	Can add dcl footer plugin model	148	add_dclfooterpluginmodel
429	Can change dcl footer plugin model	148	change_dclfooterpluginmodel
430	Can delete dcl footer plugin model	148	delete_dclfooterpluginmodel
431	Can add dcl section icon plugin model	149	add_dclsectioniconpluginmodel
432	Can change dcl section icon plugin model	149	change_dclsectioniconpluginmodel
433	Can delete dcl section icon plugin model	149	delete_dclsectioniconpluginmodel
434	Can add dcl section image plugin model	150	add_dclsectionimagepluginmodel
435	Can change dcl section image plugin model	150	change_dclsectionimagepluginmodel
436	Can delete dcl section image plugin model	150	delete_dclsectionimagepluginmodel
437	Can add dcl section promo plugin model	151	add_dclsectionpromopluginmodel
438	Can change dcl section promo plugin model	151	change_dclsectionpromopluginmodel
439	Can delete dcl section promo plugin model	151	delete_dclsectionpromopluginmodel
440	Can add dcl calculator plugin model	152	add_dclcalculatorpluginmodel
441	Can change dcl calculator plugin model	152	change_dclcalculatorpluginmodel
442	Can delete dcl calculator plugin model	152	delete_dclcalculatorpluginmodel
443	Can add task result	153	add_taskresult
444	Can change task result	153	change_taskresult
445	Can delete task result	153	delete_taskresult
\.


--
-- Data for Name: cms_aliaspluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_aliaspluginmodel (cmsplugin_ptr_id, plugin_id, alias_placeholder_id) FROM stdin;
\.


--
-- Data for Name: cms_cmsplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_cmsplugin (id, "position", language, plugin_type, creation_date, changed_date, parent_id, placeholder_id, depth, numchild, path) FROM stdin;
607	0	en-us	TextPlugin	2026-09-30 13:33:55.55121+00	2026-09-30 13:33:55.584111+00	\N	973	1	0	0001
636	0	en-us	TextPlugin	2026-09-30 13:34:08.641005+00	2026-09-30 13:34:08.859809+00	\N	1029	1	0	000U
608	0	en-us	TextPlugin	2026-09-30 13:33:55.55121+00	2026-09-30 13:33:55.923272+00	\N	974	1	0	0002
609	0	en-us	TextPlugin	2026-09-30 13:33:56.621135+00	2026-09-30 13:33:56.663102+00	\N	975	1	0	0003
610	0	en-us	TextPlugin	2026-09-30 13:33:56.621135+00	2026-09-30 13:33:56.832947+00	\N	976	1	0	0004
611	0	en-us	TextPlugin	2026-09-30 13:33:57.386254+00	2026-09-30 13:33:57.430095+00	\N	977	1	0	0005
637	0	en-us	TextPlugin	2026-09-30 13:34:09.550169+00	2026-09-30 13:34:09.588652+00	\N	1033	1	0	000V
612	0	en-us	TextPlugin	2026-09-30 13:33:57.386254+00	2026-09-30 13:33:57.612978+00	\N	978	1	0	0006
613	0	en-us	TextPlugin	2026-09-30 13:33:58.298314+00	2026-09-30 13:33:58.330778+00	\N	979	1	0	0007
614	0	en-us	TextPlugin	2026-09-30 13:33:58.298314+00	2026-09-30 13:33:58.498917+00	\N	980	1	0	0008
615	0	en-us	TextPlugin	2026-09-30 13:33:59.017964+00	2026-09-30 13:33:59.053208+00	\N	981	1	0	0009
653	0	en-us	TextPlugin	2026-09-30 13:34:16.068362+00	2026-09-30 13:34:16.102457+00	\N	1049	1	0	001B
616	0	en-us	TextPlugin	2026-09-30 13:33:59.017964+00	2026-09-30 13:33:59.244837+00	\N	982	1	0	000A
617	0	en-us	TextPlugin	2026-09-30 13:33:59.982663+00	2026-09-30 13:34:00.020363+00	\N	983	1	0	000B
638	0	en-us	TextPlugin	2026-09-30 13:34:09.550169+00	2026-09-30 13:34:09.781501+00	\N	1034	1	0	000W
618	0	en-us	TextPlugin	2026-09-30 13:33:59.982663+00	2026-09-30 13:34:00.247267+00	\N	984	1	0	000C
619	0	en-us	TextPlugin	2026-09-30 13:34:00.927855+00	2026-09-30 13:34:00.964966+00	\N	985	1	0	000D
620	0	en-us	TextPlugin	2026-09-30 13:34:00.927855+00	2026-09-30 13:34:01.159639+00	\N	986	1	0	000E
621	0	en-us	TextPlugin	2026-09-30 13:34:01.760098+00	2026-09-30 13:34:01.798248+00	\N	987	1	0	000F
639	0	en-us	TextPlugin	2026-09-30 13:34:10.390289+00	2026-09-30 13:34:10.43392+00	\N	1035	1	0	000X
622	0	en-us	TextPlugin	2026-09-30 13:34:01.760098+00	2026-09-30 13:34:01.969464+00	\N	988	1	0	000G
623	0	en-us	TextPlugin	2026-09-30 13:34:02.566864+00	2026-09-30 13:34:02.610492+00	\N	989	1	0	000H
624	0	en-us	TextPlugin	2026-09-30 13:34:02.566864+00	2026-09-30 13:34:02.779749+00	\N	990	1	0	000I
625	0	en-us	TextPlugin	2026-09-30 13:34:03.446446+00	2026-09-30 13:34:03.487333+00	\N	991	1	0	000J
626	0	en-us	TextPlugin	2026-09-30 13:34:03.446446+00	2026-09-30 13:34:03.700614+00	\N	992	1	0	000K
627	0	en-us	TextPlugin	2026-09-30 13:34:04.555417+00	2026-09-30 13:34:04.588468+00	\N	993	1	0	000L
640	0	en-us	TextPlugin	2026-09-30 13:34:10.390289+00	2026-09-30 13:34:10.695295+00	\N	1036	1	0	000Y
628	0	en-us	TextPlugin	2026-09-30 13:34:04.555417+00	2026-09-30 13:34:04.757247+00	\N	997	1	0	000M
629	0	en-us	TextPlugin	2026-09-30 13:34:05.475807+00	2026-09-30 13:34:05.813536+00	\N	1001	1	0	000N
630	0	en-us	TextPlugin	2026-09-30 13:34:05.475807+00	2026-09-30 13:34:06.116648+00	\N	1005	1	0	000O
631	0	en-us	TextPlugin	2026-09-30 13:34:06.877736+00	2026-09-30 13:34:06.911075+00	\N	1009	1	0	000P
641	0	en-us	TextPlugin	2026-09-30 13:34:11.211013+00	2026-09-30 13:34:11.256445+00	\N	1037	1	0	000Z
632	0	en-us	TextPlugin	2026-09-30 13:34:06.877736+00	2026-09-30 13:34:07.140424+00	\N	1013	1	0	000Q
633	0	en-us	TextPlugin	2026-09-30 13:34:07.819382+00	2026-09-30 13:34:07.856106+00	\N	1017	1	0	000R
634	0	en-us	TextPlugin	2026-09-30 13:34:07.819382+00	2026-09-30 13:34:08.035913+00	\N	1021	1	0	000S
635	0	en-us	TextPlugin	2026-09-30 13:34:08.641005+00	2026-09-30 13:34:08.677342+00	\N	1025	1	0	000T
663	0	en-us	TextPlugin	2026-09-30 13:34:20.085631+00	2026-09-30 13:34:20.124568+00	\N	1059	1	0	001L
654	0	en-us	TextPlugin	2026-09-30 13:34:16.068362+00	2026-09-30 13:34:16.261494+00	\N	1050	1	0	001C
642	0	en-us	TextPlugin	2026-09-30 13:34:11.211013+00	2026-09-30 13:34:11.460952+00	\N	1038	1	0	0010
643	0	en-us	TextPlugin	2026-09-30 13:34:12.008047+00	2026-09-30 13:34:12.045508+00	\N	1039	1	0	0011
644	0	en-us	TextPlugin	2026-09-30 13:34:12.008047+00	2026-09-30 13:34:12.225071+00	\N	1040	1	0	0012
645	0	en-us	TextPlugin	2026-09-30 13:34:12.749864+00	2026-09-30 13:34:12.789628+00	\N	1041	1	0	0013
655	0	en-us	TextPlugin	2026-09-30 13:34:16.797419+00	2026-09-30 13:34:16.835439+00	\N	1051	1	0	001D
646	0	en-us	TextPlugin	2026-09-30 13:34:12.749864+00	2026-09-30 13:34:12.948008+00	\N	1042	1	0	0014
647	0	en-us	TextPlugin	2026-09-30 13:34:13.809139+00	2026-09-30 13:34:13.845609+00	\N	1043	1	0	0015
648	0	en-us	TextPlugin	2026-09-30 13:34:13.809139+00	2026-09-30 13:34:14.036827+00	\N	1044	1	0	0016
649	0	en-us	TextPlugin	2026-09-30 13:34:14.626166+00	2026-09-30 13:34:14.668506+00	\N	1045	1	0	0017
650	0	en-us	TextPlugin	2026-09-30 13:34:14.626166+00	2026-09-30 13:34:14.869399+00	\N	1046	1	0	0018
651	0	en-us	TextPlugin	2026-09-30 13:34:15.33763+00	2026-09-30 13:34:15.379178+00	\N	1047	1	0	0019
656	0	en-us	TextPlugin	2026-09-30 13:34:16.797419+00	2026-09-30 13:34:17.017228+00	\N	1052	1	0	001E
652	0	en-us	TextPlugin	2026-09-30 13:34:15.33763+00	2026-09-30 13:34:15.538675+00	\N	1048	1	0	001A
657	0	en-us	TextPlugin	2026-09-30 13:34:17.664756+00	2026-09-30 13:34:17.701322+00	\N	1053	1	0	001F
669	0	en-us	TextPlugin	2026-09-30 13:34:23.56511+00	2026-09-30 13:34:23.606044+00	\N	1081	1	0	001R
658	0	en-us	TextPlugin	2026-09-30 13:34:17.664756+00	2026-09-30 13:34:17.936937+00	\N	1054	1	0	001G
659	0	en-us	TextPlugin	2026-09-30 13:34:18.551744+00	2026-09-30 13:34:18.591031+00	\N	1055	1	0	001H
664	0	en-us	TextPlugin	2026-09-30 13:34:20.085631+00	2026-09-30 13:34:20.344239+00	\N	1060	1	0	001M
660	0	en-us	TextPlugin	2026-09-30 13:34:18.551744+00	2026-09-30 13:34:18.785546+00	\N	1056	1	0	001I
661	0	en-us	TextPlugin	2026-09-30 13:34:19.352386+00	2026-09-30 13:34:19.391618+00	\N	1057	1	0	001J
662	0	en-us	TextPlugin	2026-09-30 13:34:19.352386+00	2026-09-30 13:34:19.571408+00	\N	1058	1	0	001K
665	0	en-us	TextPlugin	2026-09-30 13:34:20.899189+00	2026-09-30 13:34:20.938412+00	\N	1061	1	0	001N
666	0	en-us	TextPlugin	2026-09-30 13:34:20.899189+00	2026-09-30 13:34:21.151972+00	\N	1062	1	0	001O
667	0	en-us	TextPlugin	2026-09-30 13:34:22.288681+00	2026-09-30 13:34:22.327015+00	\N	1063	1	0	001P
672	0	en-us	TextPlugin	2026-09-30 13:34:24.744567+00	2026-09-30 13:34:24.941142+00	\N	1108	1	0	001U
668	0	en-us	TextPlugin	2026-09-30 13:34:22.288681+00	2026-09-30 13:34:22.540555+00	\N	1072	1	0	001Q
670	0	en-us	TextPlugin	2026-09-30 13:34:23.56511+00	2026-09-30 13:34:23.785705+00	\N	1090	1	0	001S
671	0	en-us	TextPlugin	2026-09-30 13:34:24.744567+00	2026-09-30 13:34:24.783457+00	\N	1099	1	0	001T
675	0	en-us	TextPlugin	2026-09-30 13:34:27.221225+00	2026-09-30 13:34:27.26274+00	\N	1135	1	0	001X
673	0	en-us	TextPlugin	2026-09-30 13:34:25.972027+00	2026-09-30 13:34:26.006515+00	\N	1117	1	0	001V
674	0	en-us	TextPlugin	2026-09-30 13:34:25.972027+00	2026-09-30 13:34:26.187793+00	\N	1126	1	0	001W
676	0	en-us	TextPlugin	2026-09-30 13:34:27.221225+00	2026-09-30 13:34:27.54788+00	\N	1144	1	0	001Y
677	0	en-us	TextPlugin	2026-09-30 13:34:28.384036+00	2026-09-30 13:34:28.41784+00	\N	1153	1	0	001Z
678	0	en-us	TextPlugin	2026-09-30 13:34:28.384036+00	2026-09-30 13:34:28.634869+00	\N	1154	1	0	0020
679	0	en-us	TextPlugin	2026-09-30 13:34:29.203628+00	2026-09-30 13:34:29.240651+00	\N	1155	1	0	0021
680	0	en-us	TextPlugin	2026-09-30 13:34:29.203628+00	2026-09-30 13:34:29.430774+00	\N	1156	1	0	0022
681	0	en-us	TextPlugin	2026-09-30 13:34:29.93315+00	2026-09-30 13:34:29.974222+00	\N	1157	1	0	0023
682	0	en-us	TextPlugin	2026-09-30 13:34:29.93315+00	2026-09-30 13:34:30.155823+00	\N	1158	1	0	0024
683	0	en-us	TextPlugin	2026-09-30 13:34:30.61833+00	2026-09-30 13:34:30.652134+00	\N	1159	1	0	0025
684	0	en-us	TextPlugin	2026-09-30 13:34:30.61833+00	2026-09-30 13:34:30.871726+00	\N	1160	1	0	0026
685	0	en-us	TextPlugin	2026-09-30 13:34:31.421769+00	2026-09-30 13:34:31.465132+00	\N	1161	1	0	0027
686	0	en-us	TextPlugin	2026-09-30 13:34:31.421769+00	2026-09-30 13:34:31.738282+00	\N	1162	1	0	0028
687	0	en-us	TextPlugin	2026-09-30 13:34:32.418279+00	2026-09-30 13:34:32.452117+00	\N	1163	1	0	0029
730	0	en-us	TextPlugin	2026-09-30 13:34:50.3081+00	2026-09-30 13:34:50.517703+00	\N	1206	1	0	003G
688	0	en-us	TextPlugin	2026-09-30 13:34:32.418279+00	2026-09-30 13:34:32.68938+00	\N	1164	1	0	002A
689	0	en-us	TextPlugin	2026-09-30 13:34:33.380493+00	2026-09-30 13:34:33.419412+00	\N	1165	1	0	002B
714	0	en-us	TextPlugin	2026-09-30 13:34:43.228076+00	2026-09-30 13:34:43.434953+00	\N	1190	1	0	0030
690	0	en-us	TextPlugin	2026-09-30 13:34:33.380493+00	2026-09-30 13:34:33.611095+00	\N	1166	1	0	002C
691	0	en-us	TextPlugin	2026-09-30 13:34:34.080383+00	2026-09-30 13:34:34.119913+00	\N	1167	1	0	002D
692	0	en-us	TextPlugin	2026-09-30 13:34:34.080383+00	2026-09-30 13:34:34.299227+00	\N	1168	1	0	002E
693	0	en-us	TextPlugin	2026-09-30 13:34:34.790399+00	2026-09-30 13:34:34.831184+00	\N	1169	1	0	002F
715	0	en-us	TextPlugin	2026-09-30 13:34:43.929764+00	2026-09-30 13:34:43.967254+00	\N	1191	1	0	0031
694	0	en-us	TextPlugin	2026-09-30 13:34:34.790399+00	2026-09-30 13:34:35.056899+00	\N	1170	1	0	002G
695	0	en-us	TextPlugin	2026-09-30 13:34:35.598189+00	2026-09-30 13:34:35.631203+00	\N	1171	1	0	002H
696	0	en-us	TextPlugin	2026-09-30 13:34:35.598189+00	2026-09-30 13:34:35.915107+00	\N	1172	1	0	002I
697	0	en-us	TextPlugin	2026-09-30 13:34:36.842872+00	2026-09-30 13:34:36.876441+00	\N	1173	1	0	002J
698	0	en-us	TextPlugin	2026-09-30 13:34:36.842872+00	2026-09-30 13:34:37.080035+00	\N	1174	1	0	002K
699	0	en-us	TextPlugin	2026-09-30 13:34:37.916012+00	2026-09-30 13:34:37.954146+00	\N	1175	1	0	002L
716	0	en-us	TextPlugin	2026-09-30 13:34:43.929764+00	2026-09-30 13:34:44.157259+00	\N	1192	1	0	0032
700	0	en-us	TextPlugin	2026-09-30 13:34:37.916012+00	2026-09-30 13:34:38.148138+00	\N	1176	1	0	002M
701	0	en-us	TextPlugin	2026-09-30 13:34:38.687429+00	2026-09-30 13:34:38.721258+00	\N	1177	1	0	002N
702	0	en-us	TextPlugin	2026-09-30 13:34:38.687429+00	2026-09-30 13:34:38.890937+00	\N	1178	1	0	002O
703	0	en-us	TextPlugin	2026-09-30 13:34:39.417698+00	2026-09-30 13:34:39.454469+00	\N	1179	1	0	002P
717	0	en-us	TextPlugin	2026-09-30 13:34:44.831142+00	2026-09-30 13:34:44.867205+00	\N	1193	1	0	0033
704	0	en-us	TextPlugin	2026-09-30 13:34:39.417698+00	2026-09-30 13:34:39.623713+00	\N	1180	1	0	002Q
705	0	en-us	TextPlugin	2026-09-30 13:34:40.121522+00	2026-09-30 13:34:40.155178+00	\N	1181	1	0	002R
706	0	en-us	TextPlugin	2026-09-30 13:34:40.121522+00	2026-09-30 13:34:40.38204+00	\N	1182	1	0	002S
707	0	en-us	TextPlugin	2026-09-30 13:34:41.044458+00	2026-09-30 13:34:41.077183+00	\N	1183	1	0	002T
731	0	en-us	TextPlugin	2026-09-30 13:34:51.125459+00	2026-09-30 13:34:51.158642+00	\N	1207	1	0	003H
708	0	en-us	TextPlugin	2026-09-30 13:34:41.044458+00	2026-09-30 13:34:41.270769+00	\N	1184	1	0	002U
709	0	en-us	TextPlugin	2026-09-30 13:34:41.800661+00	2026-09-30 13:34:41.832802+00	\N	1185	1	0	002V
718	0	en-us	TextPlugin	2026-09-30 13:34:44.831142+00	2026-09-30 13:34:45.072277+00	\N	1194	1	0	0034
710	0	en-us	TextPlugin	2026-09-30 13:34:41.800661+00	2026-09-30 13:34:42.001248+00	\N	1186	1	0	002W
711	0	en-us	TextPlugin	2026-09-30 13:34:42.507692+00	2026-09-30 13:34:42.543676+00	\N	1187	1	0	002X
712	0	en-us	TextPlugin	2026-09-30 13:34:42.507692+00	2026-09-30 13:34:42.723853+00	\N	1188	1	0	002Y
713	0	en-us	TextPlugin	2026-09-30 13:34:43.228076+00	2026-09-30 13:34:43.267295+00	\N	1189	1	0	002Z
719	0	en-us	TextPlugin	2026-09-30 13:34:45.765942+00	2026-09-30 13:34:45.811972+00	\N	1195	1	0	0035
720	0	en-us	TextPlugin	2026-09-30 13:34:45.765942+00	2026-09-30 13:34:45.984454+00	\N	1196	1	0	0036
721	0	en-us	TextPlugin	2026-09-30 13:34:46.556265+00	2026-09-30 13:34:46.601076+00	\N	1197	1	0	0037
722	0	en-us	TextPlugin	2026-09-30 13:34:46.556265+00	2026-09-30 13:34:46.796331+00	\N	1198	1	0	0038
723	0	en-us	TextPlugin	2026-09-30 13:34:47.470359+00	2026-09-30 13:34:47.5478+00	\N	1199	1	0	0039
732	0	en-us	TextPlugin	2026-09-30 13:34:51.125459+00	2026-09-30 13:34:51.329558+00	\N	1208	1	0	003I
724	0	en-us	TextPlugin	2026-09-30 13:34:47.470359+00	2026-09-30 13:34:47.808063+00	\N	1200	1	0	003A
725	0	en-us	TextPlugin	2026-09-30 13:34:48.330156+00	2026-09-30 13:34:48.369269+00	\N	1201	1	0	003B
726	0	en-us	TextPlugin	2026-09-30 13:34:48.330156+00	2026-09-30 13:34:48.574961+00	\N	1202	1	0	003C
727	0	en-us	TextPlugin	2026-09-30 13:34:49.334313+00	2026-09-30 13:34:49.368822+00	\N	1203	1	0	003D
733	0	en-us	TextPlugin	2026-09-30 13:34:52.097896+00	2026-09-30 13:34:52.136444+00	\N	1209	1	0	003J
728	0	en-us	TextPlugin	2026-09-30 13:34:49.334313+00	2026-09-30 13:34:49.618501+00	\N	1204	1	0	003E
729	0	en-us	TextPlugin	2026-09-30 13:34:50.3081+00	2026-09-30 13:34:50.346815+00	\N	1205	1	0	003F
740	0	en-us	TextPlugin	2026-09-30 13:34:54.682281+00	2026-09-30 13:34:54.920135+00	\N	1216	1	0	003Q
734	0	en-us	TextPlugin	2026-09-30 13:34:52.097896+00	2026-09-30 13:34:52.304876+00	\N	1210	1	0	003K
735	0	en-us	TextPlugin	2026-09-30 13:34:52.935481+00	2026-09-30 13:34:52.969939+00	\N	1211	1	0	003L
741	0	en-us	TextPlugin	2026-09-30 13:34:55.472048+00	2026-09-30 13:34:55.515406+00	\N	1217	1	0	003R
736	0	en-us	TextPlugin	2026-09-30 13:34:52.935481+00	2026-09-30 13:34:53.162349+00	\N	1212	1	0	003M
737	0	en-us	TextPlugin	2026-09-30 13:34:53.854873+00	2026-09-30 13:34:53.893036+00	\N	1213	1	0	003N
738	0	en-us	TextPlugin	2026-09-30 13:34:53.854873+00	2026-09-30 13:34:54.110408+00	\N	1214	1	0	003O
739	0	en-us	TextPlugin	2026-09-30 13:34:54.682281+00	2026-09-30 13:34:54.715281+00	\N	1215	1	0	003P
746	0	en-us	TextPlugin	2026-09-30 13:34:57.092549+00	2026-09-30 13:34:57.333534+00	\N	1222	1	0	003W
742	0	en-us	TextPlugin	2026-09-30 13:34:55.472048+00	2026-09-30 13:34:55.74032+00	\N	1218	1	0	003S
743	0	en-us	TextPlugin	2026-09-30 13:34:56.335879+00	2026-09-30 13:34:56.371243+00	\N	1219	1	0	003T
744	0	en-us	TextPlugin	2026-09-30 13:34:56.335879+00	2026-09-30 13:34:56.530279+00	\N	1220	1	0	003U
745	0	en-us	TextPlugin	2026-09-30 13:34:57.092549+00	2026-09-30 13:34:57.127735+00	\N	1221	1	0	003V
\.


--
-- Data for Name: cms_globalpagepermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_globalpagepermission (id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, can_recover_page, group_id, user_id) FROM stdin;
\.


--
-- Data for Name: cms_globalpagepermission_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_globalpagepermission_sites (id, globalpagepermission_id, site_id) FROM stdin;
\.


--
-- Data for Name: cms_page; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_page (id, created_by, changed_by, creation_date, changed_date, publication_date, publication_end_date, in_navigation, soft_root, reverse_id, navigation_extenders, template, login_required, limit_visibility_in_menu, is_home, application_urls, application_namespace, publisher_is_draft, languages, revision_id, xframe_options, parent_id, publisher_public_id, site_id, depth, numchild, path) FROM stdin;
3	script	script	2026-09-30 11:30:25.076702+00	2026-09-30 11:30:27.135042+00	2026-09-30 11:30:25.246413+00	\N	t	f	\N	\N	base_glarus.html	f	\N	f	BlogApp	Blog	t	en-us,de	0	0	1	4	1	2	0	00010001
673	script	script	2026-09-30 13:33:56.989281+00	2026-09-30 13:33:57.704812+00	2026-09-30 13:33:57.132369+00	\N	t	f	dummy-services	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	669	674	14	2	0	00030002
684	script	script	2026-09-30 13:34:01.533475+00	2026-09-30 13:34:02.002105+00	2026-09-30 13:34:01.503658+00	\N	t	f	dummy-services	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	680	683	6	2	0	00060002
683	script	script	2026-09-30 13:34:01.334331+00	2026-09-30 13:34:02.030047+00	2026-09-30 13:34:01.503658+00	\N	t	f	dummy-services	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	679	684	6	2	0	00050002
676	script	script	2026-09-30 13:33:58.000212+00	2026-09-30 13:33:58.52092+00	2026-09-30 13:33:57.970075+00	\N	t	f	dummy-pricing	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	670	675	14	2	0	00040003
675	script	script	2026-09-30 13:33:57.806878+00	2026-09-30 13:33:58.552541+00	2026-09-30 13:33:57.970075+00	\N	t	f	dummy-pricing	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	669	676	14	2	0	00030003
669	script	script	2026-09-30 13:33:54.902813+00	2026-09-30 13:33:56.123278+00	2026-09-30 13:33:55.109007+00	\N	t	f	dummy-home	\N	page.html	f	\N	t	\N	\N	t	en-us	0	0	\N	670	14	1	4	0003
670	script	script	2026-09-30 13:33:55.118327+00	2026-09-30 13:33:56.034044+00	2026-09-30 13:33:55.109007+00	\N	t	f	dummy-home	\N	page.html	f	\N	t	\N	\N	f	en-us	0	0	\N	669	14	1	4	0004
672	script	script	2026-09-30 13:33:56.352894+00	2026-09-30 13:33:56.866222+00	2026-09-30 13:33:56.34354+00	\N	t	f	dummy-about	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	670	671	14	2	0	00040001
671	script	script	2026-09-30 13:33:56.20582+00	2026-09-30 13:33:56.914156+00	2026-09-30 13:33:56.34354+00	\N	t	f	dummy-about	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	669	672	14	2	0	00030001
2	script	script	2026-09-30 11:30:24.155839+00	2026-09-30 11:30:26.854573+00	2026-09-30 11:30:24.147092+00	\N	t	f	\N	\N	base_glarus.html	f	\N	t	\N	\N	f	en-us,de	0	0	\N	1	1	1	1	0002
688	script	script	2026-09-30 13:34:03.156224+00	2026-09-30 13:34:03.723243+00	2026-09-30 13:34:03.136127+00	\N	t	f	dummy-contact	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	680	687	6	2	0	00060004
1	script	script	2026-09-30 11:30:23.936706+00	2026-09-30 11:30:26.913856+00	2026-09-30 11:30:24.147092+00	\N	t	f	\N	\N	base_glarus.html	f	\N	t	\N	\N	t	en-us,de	0	0	\N	2	1	1	1	0001
687	script	script	2026-09-30 13:34:02.917922+00	2026-09-30 13:34:03.765864+00	2026-09-30 13:34:03.136127+00	\N	t	f	dummy-contact	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	679	688	6	2	0	00050004
4	script	script	2026-09-30 11:30:25.271906+00	2026-09-30 11:30:27.1151+00	2026-09-30 11:30:25.246413+00	\N	t	f	\N	\N	base_glarus.html	f	\N	f	BlogApp	Blog	f	en-us,de	0	0	2	3	1	2	0	00020001
674	script	script	2026-09-30 13:33:57.15242+00	2026-09-30 13:33:57.658013+00	2026-09-30 13:33:57.132369+00	\N	t	f	dummy-services	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	670	673	14	2	0	00040002
678	script	script	2026-09-30 13:33:58.765771+00	2026-09-30 13:33:59.266255+00	2026-09-30 13:33:58.746899+00	\N	t	f	dummy-contact	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	670	677	14	2	0	00040004
677	script	script	2026-09-30 13:33:58.615197+00	2026-09-30 13:33:59.3088+00	2026-09-30 13:33:58.746899+00	\N	t	f	dummy-contact	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	669	678	14	2	0	00030004
686	script	script	2026-09-30 13:34:02.278672+00	2026-09-30 13:34:02.800521+00	2026-09-30 13:34:02.247899+00	\N	t	f	dummy-pricing	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	680	685	6	2	0	00060003
682	script	script	2026-09-30 13:34:00.6+00	2026-09-30 13:34:01.204431+00	2026-09-30 13:34:00.590947+00	\N	t	f	dummy-about	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	680	681	6	2	0	00060001
681	script	script	2026-09-30 13:34:00.462925+00	2026-09-30 13:34:01.254849+00	2026-09-30 13:34:00.590947+00	\N	t	f	dummy-about	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	679	682	6	2	0	00050001
685	script	script	2026-09-30 13:34:02.096977+00	2026-09-30 13:34:02.845078+00	2026-09-30 13:34:02.247899+00	\N	t	f	dummy-pricing	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	679	686	6	2	0	00050003
679	script	script	2026-09-30 13:33:59.379783+00	2026-09-30 13:34:00.414235+00	2026-09-30 13:33:59.578221+00	\N	t	f	dummy-home	\N	page.html	f	\N	t	\N	\N	t	en-us	0	0	\N	680	6	1	4	0005
680	script	script	2026-09-30 13:33:59.58665+00	2026-09-30 13:34:00.336803+00	2026-09-30 13:33:59.578221+00	\N	t	f	dummy-home	\N	page.html	f	\N	t	\N	\N	f	en-us	0	0	\N	679	6	1	4	0006
689	script	script	2026-09-30 13:34:03.829707+00	2026-09-30 13:34:04.853105+00	2026-09-30 13:34:04.08112+00	\N	t	f	dummy-home	\N	datacenterlight/cms/base.html	f	\N	t	\N	\N	t	en-us	0	0	\N	690	3	1	4	0007
698	script	script	2026-09-30 13:34:08.334253+00	2026-09-30 13:34:08.92121+00	2026-09-30 13:34:08.317155+00	\N	t	f	dummy-contact	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	f	en-us	0	0	690	697	3	2	0	00080004
697	script	script	2026-09-30 13:34:08.146032+00	2026-09-30 13:34:08.940352+00	2026-09-30 13:34:08.317155+00	\N	t	f	dummy-contact	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	t	en-us	0	0	689	698	3	2	0	00070004
692	script	script	2026-09-30 13:34:05.121786+00	2026-09-30 13:34:06.175402+00	2026-09-30 13:34:05.100012+00	\N	t	f	dummy-about	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	f	en-us	0	0	690	691	3	2	0	00080001
691	script	script	2026-09-30 13:34:04.915019+00	2026-09-30 13:34:06.211408+00	2026-09-30 13:34:05.100012+00	\N	t	f	dummy-about	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	t	en-us	0	0	689	692	3	2	0	00070001
690	script	script	2026-09-30 13:34:04.087859+00	2026-09-30 13:34:04.800804+00	2026-09-30 13:34:04.08112+00	\N	t	f	dummy-home	\N	datacenterlight/cms/base.html	f	\N	t	\N	\N	f	en-us	0	0	\N	689	3	1	4	0008
694	script	script	2026-09-30 13:34:06.568174+00	2026-09-30 13:34:07.173731+00	2026-09-30 13:34:06.538162+00	\N	t	f	dummy-services	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	f	en-us	0	0	690	693	3	2	0	00080002
693	script	script	2026-09-30 13:34:06.290211+00	2026-09-30 13:34:07.20551+00	2026-09-30 13:34:06.538162+00	\N	t	f	dummy-services	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	t	en-us	0	0	689	694	3	2	0	00070002
696	script	script	2026-09-30 13:34:07.523687+00	2026-09-30 13:34:08.068698+00	2026-09-30 13:34:07.487329+00	\N	t	f	dummy-pricing	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	f	en-us	0	0	690	695	3	2	0	00080003
695	script	script	2026-09-30 13:34:07.286885+00	2026-09-30 13:34:08.092399+00	2026-09-30 13:34:07.487329+00	\N	t	f	dummy-pricing	\N	datacenterlight/cms/base.html	f	\N	f	\N	\N	t	en-us	0	0	689	696	3	2	0	00070003
703	script	script	2026-09-30 13:34:10.802599+00	2026-09-30 13:34:11.540241+00	2026-09-30 13:34:10.945722+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	699	704	17	2	0	00090002
705	script	script	2026-09-30 13:34:11.61111+00	2026-09-30 13:34:12.271091+00	2026-09-30 13:34:11.750651+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	699	706	17	2	0	00090003
702	script	script	2026-09-30 13:34:10.112939+00	2026-09-30 13:34:10.723747+00	2026-09-30 13:34:10.104496+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	700	701	17	2	0	000A0001
701	script	script	2026-09-30 13:34:09.996662+00	2026-09-30 13:34:10.756263+00	2026-09-30 13:34:10.104496+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	699	702	17	2	0	00090001
704	script	script	2026-09-30 13:34:10.969168+00	2026-09-30 13:34:11.493944+00	2026-09-30 13:34:10.945722+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	700	703	17	2	0	000A0002
707	script	script	2026-09-30 13:34:12.320414+00	2026-09-30 13:34:12.999971+00	2026-09-30 13:34:12.465117+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	699	708	17	2	0	00090004
706	script	script	2026-09-30 13:34:11.767675+00	2026-09-30 13:34:12.246779+00	2026-09-30 13:34:11.750651+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	700	705	17	2	0	000A0003
699	script	script	2026-09-30 13:34:09.000914+00	2026-09-30 13:34:09.937988+00	2026-09-30 13:34:09.18045+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	700	17	1	4	0009
700	script	script	2026-09-30 13:34:09.18865+00	2026-09-30 13:34:09.877611+00	2026-09-30 13:34:09.18045+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	699	17	1	4	000A
708	script	script	2026-09-30 13:34:12.501169+00	2026-09-30 13:34:12.968767+00	2026-09-30 13:34:12.465117+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	700	707	17	2	0	000A0004
709	script	script	2026-09-30 13:34:13.069462+00	2026-09-30 13:34:14.165434+00	2026-09-30 13:34:13.247613+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	710	16	1	4	000B
710	script	script	2026-09-30 13:34:13.257416+00	2026-09-30 13:34:14.103893+00	2026-09-30 13:34:13.247613+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	709	16	1	4	000C
721	script	script	2026-09-30 13:34:18.170955+00	2026-09-30 13:34:18.879893+00	2026-09-30 13:34:18.2953+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	719	722	9	2	0	000D0001
718	script	script	2026-09-30 13:34:16.560956+00	2026-09-30 13:34:17.051345+00	2026-09-30 13:34:16.529568+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	710	717	16	2	0	000C0004
717	script	script	2026-09-30 13:34:16.39221+00	2026-09-30 13:34:17.101817+00	2026-09-30 13:34:16.529568+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	709	718	16	2	0	000B0004
734	script	script	2026-09-30 13:34:24.264792+00	2026-09-30 13:34:24.983713+00	2026-09-30 13:34:24.235867+00	\N	t	f	dummy-services	\N	home_digitalglarus.html	f	\N	f	\N	\N	f	en-us	0	0	730	733	15	2	0	000G0002
712	script	script	2026-09-30 13:34:14.350552+00	2026-09-30 13:34:14.891871+00	2026-09-30 13:34:14.339185+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	710	711	16	2	0	000C0001
711	script	script	2026-09-30 13:34:14.233305+00	2026-09-30 13:34:14.926822+00	2026-09-30 13:34:14.339185+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	709	712	16	2	0	000B0001
733	script	script	2026-09-30 13:34:23.92802+00	2026-09-30 13:34:25.01848+00	2026-09-30 13:34:24.235867+00	\N	t	f	dummy-services	\N	home_digitalglarus.html	f	\N	f	\N	\N	t	en-us	0	0	729	734	15	2	0	000F0002
728	script	script	2026-09-30 13:34:20.63851+00	2026-09-30 13:34:21.173242+00	2026-09-30 13:34:20.620393+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	720	727	9	2	0	000E0004
727	script	script	2026-09-30 13:34:20.487871+00	2026-09-30 13:34:21.202726+00	2026-09-30 13:34:20.620393+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	719	728	9	2	0	000D0004
714	script	script	2026-09-30 13:34:15.125504+00	2026-09-30 13:34:15.570954+00	2026-09-30 13:34:15.105139+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	710	713	16	2	0	000C0002
713	script	script	2026-09-30 13:34:14.982662+00	2026-09-30 13:34:15.594472+00	2026-09-30 13:34:15.105139+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	709	714	16	2	0	000B0002
724	script	script	2026-09-30 13:34:19.115844+00	2026-09-30 13:34:19.592402+00	2026-09-30 13:34:19.084829+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	720	723	9	2	0	000E0002
723	script	script	2026-09-30 13:34:18.959882+00	2026-09-30 13:34:19.614945+00	2026-09-30 13:34:19.084829+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	719	724	9	2	0	000D0002
716	script	script	2026-09-30 13:34:15.849167+00	2026-09-30 13:34:16.291653+00	2026-09-30 13:34:15.815878+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	710	715	16	2	0	000C0003
715	script	script	2026-09-30 13:34:15.659601+00	2026-09-30 13:34:16.331561+00	2026-09-30 13:34:15.815878+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	709	716	16	2	0	000B0003
722	script	script	2026-09-30 13:34:18.302987+00	2026-09-30 13:34:18.83081+00	2026-09-30 13:34:18.2953+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	720	721	9	2	0	000E0001
730	script	script	2026-09-30 13:34:21.695134+00	2026-09-30 13:34:22.611254+00	2026-09-30 13:34:21.684737+00	\N	t	f	dummy-home	\N	home_digitalglarus.html	f	\N	t	\N	\N	f	en-us	0	0	\N	729	15	1	4	000G
726	script	script	2026-09-30 13:34:19.825082+00	2026-09-30 13:34:20.372294+00	2026-09-30 13:34:19.799747+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	720	725	9	2	0	000E0003
725	script	script	2026-09-30 13:34:19.670685+00	2026-09-30 13:34:20.410269+00	2026-09-30 13:34:19.799747+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	719	726	9	2	0	000D0003
719	script	script	2026-09-30 13:34:17.15589+00	2026-09-30 13:34:18.09891+00	2026-09-30 13:34:17.326815+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	720	9	1	4	000D
720	script	script	2026-09-30 13:34:17.336619+00	2026-09-30 13:34:18.020159+00	2026-09-30 13:34:17.326815+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	719	9	1	4	000E
732	script	script	2026-09-30 13:34:23.084798+00	2026-09-30 13:34:23.826116+00	2026-09-30 13:34:23.061193+00	\N	t	f	dummy-about	\N	home_digitalglarus.html	f	\N	f	\N	\N	f	en-us	0	0	730	731	15	2	0	000G0001
731	script	script	2026-09-30 13:34:22.739894+00	2026-09-30 13:34:23.859146+00	2026-09-30 13:34:23.061193+00	\N	t	f	dummy-about	\N	home_digitalglarus.html	f	\N	f	\N	\N	t	en-us	0	0	729	732	15	2	0	000F0001
748	script	script	2026-09-30 13:34:31.199486+00	2026-09-30 13:34:31.797252+00	2026-09-30 13:34:31.168935+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	740	747	7	2	0	000I0004
741	script	script	2026-09-30 13:34:28.856603+00	2026-09-30 13:34:29.491513+00	2026-09-30 13:34:28.9682+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	739	742	7	2	0	000H0001
738	script	script	2026-09-30 13:34:26.695511+00	2026-09-30 13:34:27.628944+00	2026-09-30 13:34:26.675257+00	\N	t	f	dummy-contact	\N	home_digitalglarus.html	f	\N	f	\N	\N	f	en-us	0	0	730	737	15	2	0	000G0004
737	script	script	2026-09-30 13:34:26.330166+00	2026-09-30 13:34:27.66625+00	2026-09-30 13:34:26.675257+00	\N	t	f	dummy-contact	\N	home_digitalglarus.html	f	\N	f	\N	\N	t	en-us	0	0	729	738	15	2	0	000F0004
736	script	script	2026-09-30 13:34:25.455573+00	2026-09-30 13:34:26.223072+00	2026-09-30 13:34:25.416949+00	\N	t	f	dummy-pricing	\N	home_digitalglarus.html	f	\N	f	\N	\N	f	en-us	0	0	730	735	15	2	0	000G0003
735	script	script	2026-09-30 13:34:25.076749+00	2026-09-30 13:34:26.258718+00	2026-09-30 13:34:25.416949+00	\N	t	f	dummy-pricing	\N	home_digitalglarus.html	f	\N	f	\N	\N	t	en-us	0	0	729	736	15	2	0	000F0003
729	script	script	2026-09-30 13:34:21.268692+00	2026-09-30 13:34:22.685107+00	2026-09-30 13:34:21.684737+00	\N	t	f	dummy-home	\N	home_digitalglarus.html	f	\N	t	\N	\N	t	en-us	0	0	\N	730	15	1	4	000F
744	script	script	2026-09-30 13:34:29.721412+00	2026-09-30 13:34:30.185809+00	2026-09-30 13:34:29.692325+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	740	743	7	2	0	000I0002
743	script	script	2026-09-30 13:34:29.560356+00	2026-09-30 13:34:30.20919+00	2026-09-30 13:34:29.692325+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	739	744	7	2	0	000H0002
746	script	script	2026-09-30 13:34:30.4092+00	2026-09-30 13:34:30.925364+00	2026-09-30 13:34:30.378187+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	740	745	7	2	0	000I0003
742	script	script	2026-09-30 13:34:28.981937+00	2026-09-30 13:34:29.454862+00	2026-09-30 13:34:28.9682+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	740	741	7	2	0	000I0001
745	script	script	2026-09-30 13:34:30.267089+00	2026-09-30 13:34:30.965989+00	2026-09-30 13:34:30.378187+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	739	746	7	2	0	000H0003
747	script	script	2026-09-30 13:34:31.052253+00	2026-09-30 13:34:31.822082+00	2026-09-30 13:34:31.168935+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	739	748	7	2	0	000H0004
740	script	script	2026-09-30 13:34:27.99852+00	2026-09-30 13:34:28.722605+00	2026-09-30 13:34:27.988553+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	739	7	1	4	000I
739	script	script	2026-09-30 13:34:27.758217+00	2026-09-30 13:34:28.795091+00	2026-09-30 13:34:27.988553+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	740	7	1	4	000H
751	script	script	2026-09-30 13:34:32.989078+00	2026-09-30 13:34:33.660704+00	2026-09-30 13:34:33.112938+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	749	752	8	2	0	000J0001
753	script	script	2026-09-30 13:34:33.714298+00	2026-09-30 13:34:34.353775+00	2026-09-30 13:34:33.837927+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	749	754	8	2	0	000J0002
752	script	script	2026-09-30 13:34:33.123519+00	2026-09-30 13:34:33.632019+00	2026-09-30 13:34:33.112938+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	750	751	8	2	0	000K0001
749	script	script	2026-09-30 13:34:31.873863+00	2026-09-30 13:34:32.915241+00	2026-09-30 13:34:32.055352+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	750	8	1	4	000J
754	script	script	2026-09-30 13:34:33.868062+00	2026-09-30 13:34:34.32055+00	2026-09-30 13:34:33.837927+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	750	753	8	2	0	000K0002
750	script	script	2026-09-30 13:34:32.066806+00	2026-09-30 13:34:32.831464+00	2026-09-30 13:34:32.055352+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	749	8	1	4	000K
788	script	script	2026-09-30 13:34:48.1028+00	2026-09-30 13:34:48.619392+00	2026-09-30 13:34:48.083312+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	780	787	4	2	0	000Q0004
768	script	script	2026-09-30 13:34:39.911475+00	2026-09-30 13:34:40.414184+00	2026-09-30 13:34:39.880781+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	760	767	10	2	0	000M0004
762	script	script	2026-09-30 13:34:37.653555+00	2026-09-30 13:34:38.181713+00	2026-09-30 13:34:37.636731+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	760	761	10	2	0	000M0001
761	script	script	2026-09-30 13:34:37.291117+00	2026-09-30 13:34:38.214361+00	2026-09-30 13:34:37.636731+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	759	762	10	2	0	000L0001
786	script	script	2026-09-30 13:34:47.102365+00	2026-09-30 13:34:47.840078+00	2026-09-30 13:34:47.077142+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	780	785	4	2	0	000Q0003
756	script	script	2026-09-30 13:34:34.577996+00	2026-09-30 13:34:35.089282+00	2026-09-30 13:34:34.550174+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	750	755	8	2	0	000K0003
755	script	script	2026-09-30 13:34:34.41587+00	2026-09-30 13:34:35.118019+00	2026-09-30 13:34:34.550174+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	749	756	8	2	0	000J0003
785	script	script	2026-09-30 13:34:46.942111+00	2026-09-30 13:34:47.89292+00	2026-09-30 13:34:47.077142+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	779	786	4	2	0	000P0003
779	script	script	2026-09-30 13:34:44.275781+00	2026-09-30 13:34:45.203593+00	2026-09-30 13:34:44.45937+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	780	4	1	4	000P
767	script	script	2026-09-30 13:34:39.727004+00	2026-09-30 13:34:40.451666+00	2026-09-30 13:34:39.880781+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	759	768	10	2	0	000L0004
780	script	script	2026-09-30 13:34:44.471093+00	2026-09-30 13:34:45.138457+00	2026-09-30 13:34:44.45937+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	779	4	1	4	000Q
758	script	script	2026-09-30 13:34:35.343346+00	2026-09-30 13:34:35.944323+00	2026-09-30 13:34:35.31579+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	750	757	8	2	0	000K0004
757	script	script	2026-09-30 13:34:35.188322+00	2026-09-30 13:34:35.970971+00	2026-09-30 13:34:35.31579+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	749	758	8	2	0	000J0004
787	script	script	2026-09-30 13:34:47.956076+00	2026-09-30 13:34:48.650137+00	2026-09-30 13:34:48.083312+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	779	788	4	2	0	000P0004
771	script	script	2026-09-30 13:34:41.465428+00	2026-09-30 13:34:42.052212+00	2026-09-30 13:34:41.57168+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	769	772	11	2	0	000N0001
764	script	script	2026-09-30 13:34:38.454474+00	2026-09-30 13:34:38.922774+00	2026-09-30 13:34:38.419603+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	760	763	10	2	0	000M0002
763	script	script	2026-09-30 13:34:38.277837+00	2026-09-30 13:34:38.956959+00	2026-09-30 13:34:38.419603+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	759	764	10	2	0	000L0002
792	script	script	2026-09-30 13:34:50.019324+00	2026-09-30 13:34:50.537922+00	2026-09-30 13:34:50.007636+00	\N	t	f	dummy-about	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	790	791	2	2	0	000S0001
769	script	script	2026-09-30 13:34:40.526548+00	2026-09-30 13:34:41.415174+00	2026-09-30 13:34:40.690845+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	770	11	1	4	000N
782	script	script	2026-09-30 13:34:45.448054+00	2026-09-30 13:34:46.014762+00	2026-09-30 13:34:45.430842+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	780	781	4	2	0	000Q0001
791	script	script	2026-09-30 13:34:49.877457+00	2026-09-30 13:34:50.576244+00	2026-09-30 13:34:50.007636+00	\N	t	f	dummy-about	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	789	792	2	2	0	000R0001
770	script	script	2026-09-30 13:34:40.701213+00	2026-09-30 13:34:41.349532+00	2026-09-30 13:34:40.690845+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	769	11	1	4	000O
766	script	script	2026-09-30 13:34:39.179001+00	2026-09-30 13:34:39.644523+00	2026-09-30 13:34:39.158156+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	760	765	10	2	0	000M0003
765	script	script	2026-09-30 13:34:39.022052+00	2026-09-30 13:34:39.6672+00	2026-09-30 13:34:39.158156+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	759	766	10	2	0	000L0003
759	script	script	2026-09-30 13:34:36.055368+00	2026-09-30 13:34:37.232864+00	2026-09-30 13:34:36.349287+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	760	10	1	4	000L
760	script	script	2026-09-30 13:34:36.366961+00	2026-09-30 13:34:37.151955+00	2026-09-30 13:34:36.349287+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	759	10	1	4	000M
781	script	script	2026-09-30 13:34:45.28502+00	2026-09-30 13:34:46.041939+00	2026-09-30 13:34:45.430842+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	779	782	4	2	0	000P0001
774	script	script	2026-09-30 13:34:42.292644+00	2026-09-30 13:34:42.745598+00	2026-09-30 13:34:42.261611+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	770	773	11	2	0	000O0002
773	script	script	2026-09-30 13:34:42.118209+00	2026-09-30 13:34:42.773664+00	2026-09-30 13:34:42.261611+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	769	774	11	2	0	000N0002
793	script	script	2026-09-30 13:34:50.652906+00	2026-09-30 13:34:51.478209+00	2026-09-30 13:34:50.832748+00	\N	t	f	dummy-services	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	789	794	2	2	0	000R0002
772	script	script	2026-09-30 13:34:41.584161+00	2026-09-30 13:34:42.023356+00	2026-09-30 13:34:41.57168+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	770	771	11	2	0	000O0001
778	script	script	2026-09-30 13:34:43.705598+00	2026-09-30 13:34:44.181348+00	2026-09-30 13:34:43.681364+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	770	777	11	2	0	000O0004
777	script	script	2026-09-30 13:34:43.556982+00	2026-09-30 13:34:44.214938+00	2026-09-30 13:34:43.681364+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	769	778	11	2	0	000N0004
794	script	script	2026-09-30 13:34:50.862182+00	2026-09-30 13:34:51.407909+00	2026-09-30 13:34:50.832748+00	\N	t	f	dummy-services	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	790	793	2	2	0	000S0002
776	script	script	2026-09-30 13:34:43.001387+00	2026-09-30 13:34:43.458841+00	2026-09-30 13:34:42.980939+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	770	775	11	2	0	000O0003
775	script	script	2026-09-30 13:34:42.846654+00	2026-09-30 13:34:43.490002+00	2026-09-30 13:34:42.980939+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	769	776	11	2	0	000N0003
797	script	script	2026-09-30 13:34:52.430154+00	2026-09-30 13:34:53.233762+00	2026-09-30 13:34:52.641801+00	\N	t	f	dummy-contact	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	789	798	2	2	0	000R0004
795	script	script	2026-09-30 13:34:51.576259+00	2026-09-30 13:34:52.372266+00	2026-09-30 13:34:51.744999+00	\N	t	f	dummy-pricing	\N	page.html	f	\N	f	\N	\N	t	en-us	0	0	789	796	2	2	0	000R0003
796	script	script	2026-09-30 13:34:51.772209+00	2026-09-30 13:34:52.328332+00	2026-09-30 13:34:51.744999+00	\N	t	f	dummy-pricing	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	790	795	2	2	0	000S0003
789	script	script	2026-09-30 13:34:48.706011+00	2026-09-30 13:34:49.808383+00	2026-09-30 13:34:48.904475+00	\N	t	f	dummy-home	\N	page.html	f	\N	t	\N	\N	t	en-us	0	0	\N	790	2	1	4	000R
790	script	script	2026-09-30 13:34:48.913773+00	2026-09-30 13:34:49.709942+00	2026-09-30 13:34:48.904475+00	\N	t	f	dummy-home	\N	page.html	f	\N	t	\N	\N	f	en-us	0	0	\N	789	2	1	4	000S
798	script	script	2026-09-30 13:34:52.672266+00	2026-09-30 13:34:53.185237+00	2026-09-30 13:34:52.641801+00	\N	t	f	dummy-contact	\N	page.html	f	\N	f	\N	\N	f	en-us	0	0	790	797	2	2	0	000S0004
784	script	script	2026-09-30 13:34:46.280074+00	2026-09-30 13:34:46.839651+00	2026-09-30 13:34:46.25399+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	780	783	4	2	0	000Q0002
783	script	script	2026-09-30 13:34:46.117187+00	2026-09-30 13:34:46.874993+00	2026-09-30 13:34:46.25399+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	779	784	4	2	0	000P0002
801	script	script	2026-09-30 13:34:54.320685+00	2026-09-30 13:34:55.019108+00	2026-09-30 13:34:54.429728+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	799	802	12	2	0	000T0001
800	script	script	2026-09-30 13:34:53.491665+00	2026-09-30 13:34:54.199424+00	2026-09-30 13:34:53.483011+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	f	en-us	0	0	\N	799	12	1	4	000U
802	script	script	2026-09-30 13:34:54.438641+00	2026-09-30 13:34:54.966061+00	2026-09-30 13:34:54.429728+00	\N	t	f	dummy-about	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	800	801	12	2	0	000U0001
804	script	script	2026-09-30 13:34:55.250155+00	2026-09-30 13:34:55.787715+00	2026-09-30 13:34:55.22715+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	800	803	12	2	0	000U0002
803	script	script	2026-09-30 13:34:55.08548+00	2026-09-30 13:34:55.841892+00	2026-09-30 13:34:55.22715+00	\N	t	f	dummy-services	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	799	804	12	2	0	000T0002
806	script	script	2026-09-30 13:34:56.094779+00	2026-09-30 13:34:56.54995+00	2026-09-30 13:34:56.060167+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	800	805	12	2	0	000U0003
805	script	script	2026-09-30 13:34:55.900118+00	2026-09-30 13:34:56.577358+00	2026-09-30 13:34:56.060167+00	\N	t	f	dummy-pricing	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	799	806	12	2	0	000T0003
799	script	script	2026-09-30 13:34:53.309871+00	2026-09-30 13:34:54.274073+00	2026-09-30 13:34:53.483011+00	\N	t	f	dummy-home	\N	one_column.html	f	\N	t	\N	\N	t	en-us	0	0	\N	800	12	1	4	000T
808	script	script	2026-09-30 13:34:56.818278+00	2026-09-30 13:34:57.36364+00	2026-09-30 13:34:56.790707+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	f	en-us	0	0	800	807	12	2	0	000U0004
807	script	script	2026-09-30 13:34:56.653115+00	2026-09-30 13:34:57.391899+00	2026-09-30 13:34:56.790707+00	\N	t	f	dummy-contact	\N	one_column.html	f	\N	f	\N	\N	t	en-us	0	0	799	808	12	2	0	000T0004
\.


--
-- Data for Name: cms_page_placeholders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_page_placeholders (id, page_id, placeholder_id) FROM stdin;
966	669	973
967	670	974
968	671	975
969	672	976
970	673	977
971	674	978
972	675	979
973	676	980
974	677	981
975	678	982
976	679	983
977	680	984
978	681	985
979	682	986
980	683	987
981	684	988
982	685	989
983	686	990
984	687	991
985	688	992
986	689	993
987	689	994
988	689	995
989	689	996
990	690	997
991	690	998
992	690	999
993	690	1000
994	691	1001
995	691	1002
996	691	1003
997	691	1004
998	692	1005
999	692	1006
1000	692	1007
1001	692	1008
1002	693	1009
1003	693	1010
1004	693	1011
1005	693	1012
1006	694	1013
1007	694	1014
1008	694	1015
1009	694	1016
1010	695	1017
1011	695	1018
1012	695	1019
1013	695	1020
1014	696	1021
1015	696	1022
1016	696	1023
1017	696	1024
1018	697	1025
1019	697	1026
1020	697	1027
1021	697	1028
1022	698	1029
1023	698	1030
1024	698	1031
1025	698	1032
1026	699	1033
1027	700	1034
1028	701	1035
1029	702	1036
1030	703	1037
1031	704	1038
1032	705	1039
1033	706	1040
1034	707	1041
1035	708	1042
1036	709	1043
1037	710	1044
1038	711	1045
1039	712	1046
1040	713	1047
1041	714	1048
1042	715	1049
1043	716	1050
1044	717	1051
1045	718	1052
1046	719	1053
1047	720	1054
1048	721	1055
1049	722	1056
1050	723	1057
1051	724	1058
1052	725	1059
1053	726	1060
1054	727	1061
1055	728	1062
1056	729	1063
1057	729	1064
1058	729	1065
1059	729	1066
1060	729	1067
1061	729	1068
1062	729	1069
1063	729	1070
1064	729	1071
1065	730	1072
1066	730	1073
1067	730	1074
1068	730	1075
1069	730	1076
1070	730	1077
1071	730	1078
1072	730	1079
1073	730	1080
1074	731	1081
1075	731	1082
1076	731	1083
1077	731	1084
1078	731	1085
1079	731	1086
1080	731	1087
1081	731	1088
1082	731	1089
1083	732	1090
1084	732	1091
1085	732	1092
1086	732	1093
1087	732	1094
1088	732	1095
1089	732	1096
1090	732	1097
1091	732	1098
1092	733	1099
1093	733	1100
1094	733	1101
1095	733	1102
1096	733	1103
1097	733	1104
1098	733	1105
1099	733	1106
1100	733	1107
1101	734	1108
1102	734	1109
1103	734	1110
1104	734	1111
1105	734	1112
1106	734	1113
1107	734	1114
1108	734	1115
1109	734	1116
1110	735	1117
1111	735	1118
1112	735	1119
1113	735	1120
1114	735	1121
1115	735	1122
1116	735	1123
1117	735	1124
1118	735	1125
1119	736	1126
1120	736	1127
1121	736	1128
1122	736	1129
1123	736	1130
1124	736	1131
1125	736	1132
1126	736	1133
1127	736	1134
1128	737	1135
1129	737	1136
1130	737	1137
1131	737	1138
1132	737	1139
1133	737	1140
1134	737	1141
1135	737	1142
1136	737	1143
1137	738	1144
1138	738	1145
1139	738	1146
1140	738	1147
1141	738	1148
1142	738	1149
1143	738	1150
1144	738	1151
1145	738	1152
1146	739	1153
1147	740	1154
1148	741	1155
1149	742	1156
1150	743	1157
1151	744	1158
1152	745	1159
1153	746	1160
1154	747	1161
1155	748	1162
1156	749	1163
1157	750	1164
1158	751	1165
1159	752	1166
1160	753	1167
1161	754	1168
1162	755	1169
1163	756	1170
1164	757	1171
1165	758	1172
1166	759	1173
1167	760	1174
1168	761	1175
1169	762	1176
1170	763	1177
1171	764	1178
1172	765	1179
1173	766	1180
1174	767	1181
1175	768	1182
1176	769	1183
1177	770	1184
1178	771	1185
1179	772	1186
1180	773	1187
1181	774	1188
1182	775	1189
1183	776	1190
1184	777	1191
1185	778	1192
1186	779	1193
1187	780	1194
1188	781	1195
1189	782	1196
1190	783	1197
1191	784	1198
1192	785	1199
1193	786	1200
1194	787	1201
1195	788	1202
1196	789	1203
1197	790	1204
1198	791	1205
1199	792	1206
1200	793	1207
1201	794	1208
1202	795	1209
1203	796	1210
1204	797	1211
1205	798	1212
1206	799	1213
1207	800	1214
1208	801	1215
1209	802	1216
1210	803	1217
1211	804	1218
1212	805	1219
1213	806	1220
1214	807	1221
1215	808	1222
\.


--
-- Data for Name: cms_pagepermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pagepermission (id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, grant_on, group_id, page_id, user_id) FROM stdin;
\.


--
-- Data for Name: cms_pageuser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pageuser (customuser_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_pageusergroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pageusergroup (group_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_placeholder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_placeholder (id, slot, default_width) FROM stdin;
973	page_content	\N
974	page_content	\N
975	page_content	\N
976	page_content	\N
977	page_content	\N
978	page_content	\N
979	page_content	\N
1	newsblog_base_sidebar	\N
2	newsblog_base_top	\N
3	newsblog_detail_bottom	\N
4	newsblog_detail_footer	\N
5	newsblog_detail_top	\N
6	newsblog_list_footer	\N
7	newsblog_list_top	\N
980	page_content	\N
981	page_content	\N
982	page_content	\N
983	page_content	\N
984	page_content	\N
985	page_content	\N
986	page_content	\N
987	page_content	\N
988	page_content	\N
989	page_content	\N
990	page_content	\N
991	page_content	\N
992	page_content	\N
993	datacenterlight_navbar	\N
994	Datacenterlight Header	\N
995	Datacenterlight Content	\N
996	datacenterlight_footer	\N
997	datacenterlight_navbar	\N
998	Datacenterlight Header	\N
999	Datacenterlight Content	\N
1000	datacenterlight_footer	\N
1001	datacenterlight_navbar	\N
1002	Datacenterlight Header	\N
1003	Datacenterlight Content	\N
1004	datacenterlight_footer	\N
1005	datacenterlight_navbar	\N
1006	Datacenterlight Header	\N
1007	Datacenterlight Content	\N
1008	datacenterlight_footer	\N
1009	datacenterlight_navbar	\N
1010	Datacenterlight Header	\N
1011	Datacenterlight Content	\N
1012	datacenterlight_footer	\N
1013	datacenterlight_navbar	\N
1014	Datacenterlight Header	\N
1015	Datacenterlight Content	\N
1016	datacenterlight_footer	\N
1017	datacenterlight_navbar	\N
1018	Datacenterlight Header	\N
1019	Datacenterlight Content	\N
1020	datacenterlight_footer	\N
1021	datacenterlight_navbar	\N
1022	Datacenterlight Header	\N
1023	Datacenterlight Content	\N
1024	datacenterlight_footer	\N
1025	datacenterlight_navbar	\N
1026	Datacenterlight Header	\N
1027	Datacenterlight Content	\N
1028	datacenterlight_footer	\N
1029	datacenterlight_navbar	\N
1030	Datacenterlight Header	\N
1031	Datacenterlight Content	\N
1032	datacenterlight_footer	\N
1033	digitalglarus_why_us	\N
1034	digitalglarus_why_us	\N
1035	digitalglarus_why_us	\N
1036	digitalglarus_why_us	\N
1037	digitalglarus_why_us	\N
1038	digitalglarus_why_us	\N
1039	digitalglarus_why_us	\N
1040	digitalglarus_why_us	\N
1041	digitalglarus_why_us	\N
1042	digitalglarus_why_us	\N
1043	digitalglarus_why_us	\N
1044	digitalglarus_why_us	\N
1045	digitalglarus_why_us	\N
1046	digitalglarus_why_us	\N
1047	digitalglarus_why_us	\N
1048	digitalglarus_why_us	\N
1049	digitalglarus_why_us	\N
1050	digitalglarus_why_us	\N
1051	digitalglarus_why_us	\N
1052	digitalglarus_why_us	\N
1053	digitalglarus_why_us	\N
1054	digitalglarus_why_us	\N
1055	digitalglarus_why_us	\N
1056	digitalglarus_why_us	\N
1057	digitalglarus_why_us	\N
1058	digitalglarus_why_us	\N
1059	digitalglarus_why_us	\N
1060	digitalglarus_why_us	\N
1061	digitalglarus_why_us	\N
1062	digitalglarus_why_us	\N
1063	digitalglarus_gallery	\N
1064	digital_glarus_build_a_tech_valley	\N
1065	digital_glarus_build_a_tech_valley_content	\N
1066	digital_glarus_a_new_area	\N
1067	digital_glarus_a_new_area_content	\N
1068	digital_glarus_why_be_interested	\N
1069	digital_glarus_why_be_interested_content	\N
1070	digital_glarus_where_we_are	\N
1071	digital_glarus_where_we_are_content	\N
1072	digitalglarus_gallery	\N
1073	digital_glarus_build_a_tech_valley	\N
1074	digital_glarus_build_a_tech_valley_content	\N
1075	digital_glarus_a_new_area	\N
1076	digital_glarus_a_new_area_content	\N
1077	digital_glarus_why_be_interested	\N
1078	digital_glarus_why_be_interested_content	\N
1079	digital_glarus_where_we_are	\N
1080	digital_glarus_where_we_are_content	\N
1081	digitalglarus_gallery	\N
1082	digital_glarus_build_a_tech_valley	\N
1083	digital_glarus_build_a_tech_valley_content	\N
1084	digital_glarus_a_new_area	\N
1085	digital_glarus_a_new_area_content	\N
1086	digital_glarus_why_be_interested	\N
1087	digital_glarus_why_be_interested_content	\N
1088	digital_glarus_where_we_are	\N
1089	digital_glarus_where_we_are_content	\N
1090	digitalglarus_gallery	\N
1091	digital_glarus_build_a_tech_valley	\N
1092	digital_glarus_build_a_tech_valley_content	\N
1093	digital_glarus_a_new_area	\N
1094	digital_glarus_a_new_area_content	\N
1095	digital_glarus_why_be_interested	\N
1096	digital_glarus_why_be_interested_content	\N
1097	digital_glarus_where_we_are	\N
1098	digital_glarus_where_we_are_content	\N
1099	digitalglarus_gallery	\N
1100	digital_glarus_build_a_tech_valley	\N
1101	digital_glarus_build_a_tech_valley_content	\N
1102	digital_glarus_a_new_area	\N
1103	digital_glarus_a_new_area_content	\N
1104	digital_glarus_why_be_interested	\N
1105	digital_glarus_why_be_interested_content	\N
1106	digital_glarus_where_we_are	\N
1107	digital_glarus_where_we_are_content	\N
1108	digitalglarus_gallery	\N
1109	digital_glarus_build_a_tech_valley	\N
1110	digital_glarus_build_a_tech_valley_content	\N
1111	digital_glarus_a_new_area	\N
1112	digital_glarus_a_new_area_content	\N
1113	digital_glarus_why_be_interested	\N
1114	digital_glarus_why_be_interested_content	\N
1115	digital_glarus_where_we_are	\N
1116	digital_glarus_where_we_are_content	\N
1117	digitalglarus_gallery	\N
1118	digital_glarus_build_a_tech_valley	\N
1119	digital_glarus_build_a_tech_valley_content	\N
1120	digital_glarus_a_new_area	\N
1121	digital_glarus_a_new_area_content	\N
1122	digital_glarus_why_be_interested	\N
1123	digital_glarus_why_be_interested_content	\N
1124	digital_glarus_where_we_are	\N
1125	digital_glarus_where_we_are_content	\N
1126	digitalglarus_gallery	\N
1127	digital_glarus_build_a_tech_valley	\N
1128	digital_glarus_build_a_tech_valley_content	\N
1129	digital_glarus_a_new_area	\N
1130	digital_glarus_a_new_area_content	\N
1131	digital_glarus_why_be_interested	\N
1132	digital_glarus_why_be_interested_content	\N
1133	digital_glarus_where_we_are	\N
1134	digital_glarus_where_we_are_content	\N
1135	digitalglarus_gallery	\N
1136	digital_glarus_build_a_tech_valley	\N
1137	digital_glarus_build_a_tech_valley_content	\N
1138	digital_glarus_a_new_area	\N
1139	digital_glarus_a_new_area_content	\N
1140	digital_glarus_why_be_interested	\N
1141	digital_glarus_why_be_interested_content	\N
1142	digital_glarus_where_we_are	\N
1143	digital_glarus_where_we_are_content	\N
1144	digitalglarus_gallery	\N
1145	digital_glarus_build_a_tech_valley	\N
1146	digital_glarus_build_a_tech_valley_content	\N
1147	digital_glarus_a_new_area	\N
1148	digital_glarus_a_new_area_content	\N
1149	digital_glarus_why_be_interested	\N
1150	digital_glarus_why_be_interested_content	\N
1151	digital_glarus_where_we_are	\N
1152	digital_glarus_where_we_are_content	\N
1153	digitalglarus_why_us	\N
1154	digitalglarus_why_us	\N
1155	digitalglarus_why_us	\N
1156	digitalglarus_why_us	\N
1157	digitalglarus_why_us	\N
1158	digitalglarus_why_us	\N
1159	digitalglarus_why_us	\N
1160	digitalglarus_why_us	\N
1161	digitalglarus_why_us	\N
1162	digitalglarus_why_us	\N
1163	digitalglarus_why_us	\N
1164	digitalglarus_why_us	\N
1165	digitalglarus_why_us	\N
1166	digitalglarus_why_us	\N
1167	digitalglarus_why_us	\N
1168	digitalglarus_why_us	\N
1169	digitalglarus_why_us	\N
1170	digitalglarus_why_us	\N
1171	digitalglarus_why_us	\N
1172	digitalglarus_why_us	\N
1173	digitalglarus_why_us	\N
1174	digitalglarus_why_us	\N
1175	digitalglarus_why_us	\N
1176	digitalglarus_why_us	\N
1177	digitalglarus_why_us	\N
1178	digitalglarus_why_us	\N
1179	digitalglarus_why_us	\N
1180	digitalglarus_why_us	\N
1181	digitalglarus_why_us	\N
1182	digitalglarus_why_us	\N
1183	digitalglarus_why_us	\N
1184	digitalglarus_why_us	\N
1185	digitalglarus_why_us	\N
1186	digitalglarus_why_us	\N
1187	digitalglarus_why_us	\N
1188	digitalglarus_why_us	\N
1189	digitalglarus_why_us	\N
1190	digitalglarus_why_us	\N
1191	digitalglarus_why_us	\N
1192	digitalglarus_why_us	\N
1193	digitalglarus_why_us	\N
1194	digitalglarus_why_us	\N
1195	digitalglarus_why_us	\N
1196	digitalglarus_why_us	\N
1197	digitalglarus_why_us	\N
1198	digitalglarus_why_us	\N
1199	digitalglarus_why_us	\N
1200	digitalglarus_why_us	\N
1201	digitalglarus_why_us	\N
1202	digitalglarus_why_us	\N
1203	page_content	\N
1204	page_content	\N
1205	page_content	\N
1206	page_content	\N
1207	page_content	\N
1208	page_content	\N
1209	page_content	\N
1210	page_content	\N
1211	page_content	\N
1212	page_content	\N
1213	digitalglarus_why_us	\N
1214	digitalglarus_why_us	\N
1215	digitalglarus_why_us	\N
1216	digitalglarus_why_us	\N
1217	digitalglarus_why_us	\N
1218	digitalglarus_why_us	\N
1219	digitalglarus_why_us	\N
1220	digitalglarus_why_us	\N
1221	digitalglarus_why_us	\N
1222	digitalglarus_why_us	\N
1223	clipboard	\N
1224	post_content	\N
1225	live_blog	\N
1226	post_content	\N
1227	live_blog	\N
1228	post_content	\N
1229	live_blog	\N
1230	post_content	\N
1231	live_blog	\N
1232	post_content	\N
1233	live_blog	\N
1234	post_content	\N
1235	live_blog	\N
1236	post_content	\N
1237	live_blog	\N
1238	post_content	\N
1239	live_blog	\N
\.


--
-- Data for Name: cms_placeholderreference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_placeholderreference (cmsplugin_ptr_id, name, placeholder_ref_id) FROM stdin;
\.


--
-- Data for Name: cms_staticplaceholder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_staticplaceholder (id, name, code, dirty, creation_method, draft_id, public_id, site_id) FROM stdin;
\.


--
-- Data for Name: cms_title; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_title (id, language, title, page_title, menu_title, meta_description, slug, path, has_url_overwrite, redirect, creation_date, published, publisher_is_draft, publisher_state, page_id, publisher_public_id) FROM stdin;
2	en-us	Home	\N	\N	\N	home		f	\N	2026-09-30 11:30:24.047645+00	t	f	0	2	1
1	en-us	Home	\N	\N	\N	home		f	\N	2026-09-30 11:30:24.047645+00	t	t	0	1	2
4	en-us	Blog	\N	\N	\N	blog	blog	f	\N	2026-09-30 11:30:25.19124+00	t	f	0	4	3
3	en-us	Blog	\N	\N	\N	blog	blog	f	\N	2026-09-30 11:30:25.19124+00	t	t	0	3	4
6	de	Home	\N	\N	\N	home		f	\N	2026-09-30 11:30:26.501355+00	t	f	0	2	5
5	de	Home	\N	\N	\N	home		f	\N	2026-09-30 11:30:26.501355+00	t	t	0	1	6
8	de	Blog	\N	\N	\N	blog	blog	f	\N	2026-09-30 11:30:26.96555+00	t	f	0	4	7
7	de	Blog	\N	\N	\N	blog	blog	f	\N	2026-09-30 11:30:26.96555+00	t	t	0	3	8
673	en-us	ungleich blog	\N	\N	Notes from running data centers, networks and free software.	home		f	\N	2026-09-30 13:33:55.015278+00	t	f	0	670	672
672	en-us	ungleich blog	\N	\N	Notes from running data centers, networks and free software.	home		f	\N	2026-09-30 13:33:55.015278+00	t	t	0	669	673
675	en-us	About	\N	\N	ungleich blog is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:33:56.285006+00	t	f	0	672	674
674	en-us	About	\N	\N	ungleich blog is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:33:56.285006+00	t	t	0	671	675
681	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:33:58.687242+00	t	f	0	678	680
677	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:33:57.074036+00	t	f	0	674	676
676	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:33:57.074036+00	t	t	0	673	677
680	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:33:58.687242+00	t	t	0	677	681
679	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:33:57.910489+00	t	f	0	676	678
678	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:33:57.910489+00	t	t	0	675	679
683	en-us	ungleich comic	\N	\N	Life in the data center, one panel at a time.	home		f	\N	2026-09-30 13:33:59.484686+00	t	f	0	680	682
682	en-us	ungleich comic	\N	\N	Life in the data center, one panel at a time.	home		f	\N	2026-09-30 13:33:59.484686+00	t	t	0	679	683
687	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:01.433336+00	t	f	0	684	686
686	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:01.433336+00	t	t	0	683	687
685	en-us	About	\N	\N	ungleich comic is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:00.531716+00	t	f	0	682	684
684	en-us	About	\N	\N	ungleich comic is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:00.531716+00	t	t	0	681	685
691	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:03.01177+00	t	f	0	688	690
690	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:03.01177+00	t	t	0	687	691
689	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:02.189387+00	t	f	0	686	688
688	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:02.189387+00	t	t	0	685	689
693	en-us	Data Center Light	\N	\N	Virtual machines from a Swiss, ecological data center.	home		f	\N	2026-09-30 13:34:03.989656+00	t	f	0	690	692
692	en-us	Data Center Light	\N	\N	Virtual machines from a Swiss, ecological data center.	home		f	\N	2026-09-30 13:34:03.989656+00	t	t	0	689	693
695	en-us	About	\N	\N	Data Center Light is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:05.045604+00	t	f	0	692	694
694	en-us	About	\N	\N	Data Center Light is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:05.045604+00	t	t	0	691	695
697	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:06.481984+00	t	f	0	694	696
696	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:06.481984+00	t	t	0	693	697
699	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:07.424801+00	t	f	0	696	698
698	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:07.424801+00	t	t	0	695	699
701	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:08.277567+00	t	f	0	698	700
700	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:08.277567+00	t	t	0	697	701
702	en-us	Devuan Hosting	\N	\N	Hosting on Devuan, the systemd-free Linux.	home		f	\N	2026-09-30 13:34:09.09537+00	t	t	0	699	703
703	en-us	Devuan Hosting	\N	\N	Hosting on Devuan, the systemd-free Linux.	home		f	\N	2026-09-30 13:34:09.09537+00	t	f	0	700	702
705	en-us	About	\N	\N	Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:10.066636+00	t	f	0	702	704
704	en-us	About	\N	\N	Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:10.066636+00	t	t	0	701	705
707	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:10.879166+00	t	f	0	704	706
706	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:10.879166+00	t	t	0	703	707
709	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:11.690508+00	t	f	0	706	708
708	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:11.690508+00	t	t	0	705	709
719	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:15.760063+00	t	f	0	716	718
711	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:12.401728+00	t	f	0	708	710
710	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:12.401728+00	t	t	0	707	711
718	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:15.760063+00	t	t	0	715	719
713	en-us	Devuan Hosting	\N	\N	Hosting on Devuan, the systemd-free Linux.	home		f	\N	2026-09-30 13:34:13.173646+00	t	f	0	710	712
712	en-us	Devuan Hosting	\N	\N	Hosting on Devuan, the systemd-free Linux.	home		f	\N	2026-09-30 13:34:13.173646+00	t	t	0	709	713
715	en-us	About	\N	\N	Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:14.301211+00	t	f	0	712	714
714	en-us	About	\N	\N	Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:14.301211+00	t	t	0	711	715
717	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:15.058084+00	t	f	0	714	716
716	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:15.058084+00	t	t	0	713	717
721	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:16.469699+00	t	f	0	718	720
720	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:16.469699+00	t	t	0	717	721
727	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:19.047515+00	t	f	0	724	726
723	en-us	digitalezukunft.ch	\N	\N	Welcome to digitalezukunft.ch.	home		f	\N	2026-09-30 13:34:17.255985+00	t	f	0	720	722
722	en-us	digitalezukunft.ch	\N	\N	Welcome to digitalezukunft.ch.	home		f	\N	2026-09-30 13:34:17.255985+00	t	t	0	719	723
726	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:19.047515+00	t	t	0	723	727
725	en-us	About	\N	\N	digitalezukunft.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:18.236903+00	t	f	0	722	724
724	en-us	About	\N	\N	digitalezukunft.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:18.236903+00	t	t	0	721	725
729	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:19.737037+00	t	f	0	726	728
728	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:19.737037+00	t	t	0	725	729
731	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:20.571865+00	t	f	0	728	730
730	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:20.571865+00	t	t	0	727	731
733	en-us	Digital Glarus	\N	\N	The Swiss IT valley in Schwanden, Glarus.	home		f	\N	2026-09-30 13:34:21.601689+00	t	f	0	730	732
732	en-us	Digital Glarus	\N	\N	The Swiss IT valley in Schwanden, Glarus.	home		f	\N	2026-09-30 13:34:21.601689+00	t	t	0	729	733
741	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:26.599322+00	t	f	0	738	740
735	en-us	About	\N	\N	Digital Glarus is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:22.998494+00	t	f	0	732	734
734	en-us	About	\N	\N	Digital Glarus is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:22.998494+00	t	t	0	731	735
739	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:25.34247+00	t	f	0	736	738
737	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:24.184849+00	t	f	0	734	736
736	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:24.184849+00	t	t	0	733	737
740	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:26.599322+00	t	t	0	737	741
738	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:25.34247+00	t	t	0	735	739
743	en-us	Django Hosting	\N	\N	Managed hosting for Django applications.	home		f	\N	2026-09-30 13:34:27.876742+00	t	f	0	740	742
742	en-us	Django Hosting	\N	\N	Managed hosting for Django applications.	home		f	\N	2026-09-30 13:34:27.876742+00	t	t	0	739	743
744	en-us	About	\N	\N	Django Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:28.919096+00	t	t	0	741	745
745	en-us	About	\N	\N	Django Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:28.919096+00	t	f	0	742	744
747	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:29.64214+00	t	f	0	744	746
746	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:29.64214+00	t	t	0	743	747
749	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:30.341882+00	t	f	0	746	748
748	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:30.341882+00	t	t	0	745	749
751	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:31.129877+00	t	f	0	748	750
788	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:47.013417+00	t	t	0	785	789
761	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:35.254765+00	t	f	0	758	760
760	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:35.254765+00	t	t	0	757	761
750	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:31.129877+00	t	t	0	747	751
789	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:47.013417+00	t	f	0	786	788
791	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:48.046473+00	t	f	0	788	790
753	en-us	hack4glarus.ch	\N	\N	Welcome to hack4glarus.ch.	home		f	\N	2026-09-30 13:34:31.966695+00	t	f	0	750	752
752	en-us	hack4glarus.ch	\N	\N	Welcome to hack4glarus.ch.	home		f	\N	2026-09-30 13:34:31.966695+00	t	t	0	749	753
790	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:48.046473+00	t	t	0	787	791
755	en-us	About	\N	\N	hack4glarus.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:33.054022+00	t	f	0	752	754
754	en-us	About	\N	\N	hack4glarus.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:33.054022+00	t	t	0	751	755
793	en-us	ungleich	\N	\N	Swiss IT infrastructure, hosting and open source.	home		f	\N	2026-09-30 13:34:48.811285+00	t	f	0	790	792
792	en-us	ungleich	\N	\N	Swiss IT infrastructure, hosting and open source.	home		f	\N	2026-09-30 13:34:48.811285+00	t	t	0	789	793
769	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:39.100458+00	t	f	0	766	768
757	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:33.787387+00	t	f	0	754	756
756	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:33.787387+00	t	t	0	753	757
763	en-us	ipv6onlyhosting.com	\N	\N	Welcome to ipv6onlyhosting.com.	home		f	\N	2026-09-30 13:34:36.215147+00	t	f	0	760	762
762	en-us	ipv6onlyhosting.com	\N	\N	Welcome to ipv6onlyhosting.com.	home		f	\N	2026-09-30 13:34:36.215147+00	t	t	0	759	763
759	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:34.499519+00	t	f	0	756	758
758	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:34.499519+00	t	t	0	755	759
768	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:39.100458+00	t	t	0	765	769
765	en-us	About	\N	\N	ipv6onlyhosting.com is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:37.571458+00	t	f	0	762	764
764	en-us	About	\N	\N	ipv6onlyhosting.com is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:37.571458+00	t	t	0	761	765
767	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:38.355649+00	t	f	0	764	766
766	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:38.355649+00	t	t	0	763	767
780	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:43.635063+00	t	t	0	777	781
775	en-us	About	\N	\N	Node.js Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:41.533325+00	t	f	0	772	774
774	en-us	About	\N	\N	Node.js Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:41.533325+00	t	t	0	771	775
771	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:39.822362+00	t	f	0	768	770
770	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:39.822362+00	t	t	0	767	771
773	en-us	Node.js Hosting	\N	\N	Managed hosting for Node.js applications.	home		f	\N	2026-09-30 13:34:40.61992+00	t	f	0	770	772
772	en-us	Node.js Hosting	\N	\N	Managed hosting for Node.js applications.	home		f	\N	2026-09-30 13:34:40.61992+00	t	t	0	769	773
779	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:42.923812+00	t	f	0	776	778
777	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:42.201471+00	t	f	0	774	776
776	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:42.201471+00	t	t	0	773	777
778	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:42.923812+00	t	t	0	775	779
781	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:43.635063+00	t	f	0	778	780
784	en-us	About	\N	\N	Rails Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:45.357723+00	t	t	0	781	785
783	en-us	Rails Hosting	\N	\N	Managed hosting for Ruby on Rails applications.	home		f	\N	2026-09-30 13:34:44.373531+00	t	f	0	780	782
782	en-us	Rails Hosting	\N	\N	Managed hosting for Ruby on Rails applications.	home		f	\N	2026-09-30 13:34:44.373531+00	t	t	0	779	783
786	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:46.191512+00	t	t	0	783	787
785	en-us	About	\N	\N	Rails Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:45.357723+00	t	f	0	782	784
787	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:46.191512+00	t	f	0	784	786
810	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:56.728428+00	t	t	0	807	811
795	en-us	About	\N	\N	ungleich is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:49.959283+00	t	f	0	792	794
794	en-us	About	\N	\N	ungleich is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:49.959283+00	t	t	0	791	795
805	en-us	About	\N	\N	xn--nglarus-n2a.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:54.383048+00	t	f	0	802	804
797	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:50.761056+00	t	f	0	794	796
796	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:50.761056+00	t	t	0	793	797
804	en-us	About	\N	\N	xn--nglarus-n2a.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.	about	about	f	\N	2026-09-30 13:34:54.383048+00	t	t	0	801	805
799	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:51.671484+00	t	f	0	796	798
798	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:51.671484+00	t	t	0	795	799
801	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:52.570555+00	t	f	0	798	800
800	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:52.570555+00	t	t	0	797	801
803	en-us	xn--nglarus-n2a.ch	\N	\N	Welcome to xn--nglarus-n2a.ch.	home		f	\N	2026-09-30 13:34:53.411411+00	t	f	0	800	802
802	en-us	xn--nglarus-n2a.ch	\N	\N	Welcome to xn--nglarus-n2a.ch.	home		f	\N	2026-09-30 13:34:53.411411+00	t	t	0	799	803
807	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:55.171468+00	t	f	0	804	806
806	en-us	Services	\N	\N	Virtual machines, managed hosting and consulting, all running in our own data centers.	services	services	f	\N	2026-09-30 13:34:55.171468+00	t	t	0	803	807
809	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:55.984379+00	t	f	0	806	808
808	en-us	Pricing	\N	\N	Simple monthly plans, billed per resource with no minimum term.	pricing	pricing	f	\N	2026-09-30 13:34:55.984379+00	t	t	0	805	809
811	en-us	Contact	\N	\N	Write to support@ungleich.ch and we will answer within one working day.	contact	contact	f	\N	2026-09-30 13:34:56.728428+00	t	f	0	808	810
\.


--
-- Data for Name: cms_urlconfrevision; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_urlconfrevision (id, revision) FROM stdin;
1	8e73d6af-8000-4d43-9415-1eb5afcd9534
\.


--
-- Data for Name: cms_usersettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_usersettings (id, language, clipboard_id, user_id) FROM stdin;
1	en-us	1223	74
\.


--
-- Data for Name: cmsplugin_filer_file_filerfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cmsplugin_filer_file_filerfile (cmsplugin_ptr_id, title, target_blank, style, file_id) FROM stdin;
\.


--
-- Data for Name: cmsplugin_filer_folder_filerfolder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cmsplugin_filer_folder_filerfolder (cmsplugin_ptr_id, title, style, folder_id) FROM stdin;
\.


--
-- Data for Name: cmsplugin_filer_image_filerimage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cmsplugin_filer_image_filerimage (cmsplugin_ptr_id, style, caption_text, image_url, alt_text, use_original_image, use_autoscale, width, height, crop, upscale, alignment, free_link, original_link, description, target_blank, file_link_id, image_id, page_link_id, thumbnail_option_id) FROM stdin;
\.


--
-- Data for Name: cmsplugin_filer_image_thumbnailoption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cmsplugin_filer_image_thumbnailoption (id, name, width, height, crop, upscale) FROM stdin;
\.


--
-- Data for Name: cmsplugin_filer_link_filerlinkplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cmsplugin_filer_link_filerlinkplugin (cmsplugin_ptr_id, name, url, mailto, link_style, new_window, file_id, page_link_id) FROM stdin;
\.


--
-- Data for Name: cmsplugin_filer_video_filervideo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cmsplugin_filer_video_filervideo (cmsplugin_ptr_id, movie_url, width, height, auto_play, auto_hide, fullscreen, loop, bgcolor, textcolor, seekbarcolor, seekbarbgcolor, loadingbarcolor, buttonoutcolor, buttonovercolor, buttonhighlightcolor, image_id, movie_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_cmsfaviconextension; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_cmsfaviconextension (id, extended_object_id, favicon_id, public_extension_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_cmsintegration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_cmsintegration (id, navbar_placeholder_id, footer_placeholder_id, name, domain_id, calculator_placeholder_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_contactus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_contactus (id, name, email, message, field) FROM stdin;
1	Prospect 1	prospect-1@example.com	Please send me an offer, request 1.	2026-10-05 19:48:14.823439+00
2	Prospect 2	prospect-2@example.com	Please send me an offer, request 2.	2026-10-05 19:48:14.83498+00
3	Prospect 3	prospect-3@example.com	Please send me an offer, request 3.	2026-10-05 19:48:14.846045+00
4	Prospect 4	prospect-4@example.com	Please send me an offer, request 4.	2026-10-05 19:48:14.856474+00
5	Prospect 5	prospect-5@example.com	Please send me an offer, request 5.	2026-10-05 19:48:14.868169+00
\.


--
-- Data for Name: datacenterlight_dclbanneritempluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclbanneritempluginmodel (cmsplugin_ptr_id, content, banner_text, text_direction, banner_image_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclbannerlistpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclbannerlistpluginmodel (cmsplugin_ptr_id, heading, html_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclcalculatorpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclcalculatorpluginmodel (cmsplugin_ptr_id, pricing_id, vm_type, vm_templates_to_show, default_selected_template, enable_512mb_ram) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclcontactpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclcontactpluginmodel (cmsplugin_ptr_id, heading, organization_name, email, address, country, form_header) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclfooterpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclfooterpluginmodel (cmsplugin_ptr_id, copyright_label) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dcllinkpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dcllinkpluginmodel (cmsplugin_ptr_id, target, text, title, separator) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclnavbardropdownpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclnavbardropdownpluginmodel (cmsplugin_ptr_id, text, target) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclnavbarpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclnavbarpluginmodel (cmsplugin_ptr_id, logo_url, logo_dark_id, logo_light_id, language_dropdown, show_login_option, show_non_transparent_navbar_always) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclsectioniconpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclsectioniconpluginmodel (cmsplugin_ptr_id, fontawesome_icon_name) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclsectionimagepluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclsectionimagepluginmodel (cmsplugin_ptr_id, caption, image_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclsectionpluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclsectionpluginmodel (cmsplugin_ptr_id, heading, content, text_direction, html_id, center_on_mobile, background_gradient, plain_heading) FROM stdin;
\.


--
-- Data for Name: datacenterlight_dclsectionpromopluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_dclsectionpromopluginmodel (cmsplugin_ptr_id, heading, subheading, content, html_id, plain_heading, text_center, background_image_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_stripeplan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_stripeplan (id, stripe_plan_id, stripe_plan_name, amount, "interval") FROM stdin;
\.


--
-- Data for Name: datacenterlight_vmpricing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_vmpricing (id, name, vat_inclusive, vat_percentage, cores_unit_price, ram_unit_price, ssd_unit_price, hdd_unit_price, discount_amount, discount_name, stripe_coupon_id) FROM stdin;
\.


--
-- Data for Name: datacenterlight_vmtemplate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.datacenterlight_vmtemplate (id, name, opennebula_vm_template_id, vm_type) FROM stdin;
\.


--
-- Data for Name: digitalglarus_booking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_booking (id, start_date, end_date, price, free_days, final_price) FROM stdin;
\.


--
-- Data for Name: digitalglarus_bookingcancellation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_bookingcancellation (id, created_at, required_refund, refund, order_id) FROM stdin;
\.


--
-- Data for Name: digitalglarus_bookingorder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_bookingorder (id, created_at, approved, last4, cc_brand, stripe_charge_id, billing_address_id, booking_id, customer_id, amount, original_price, special_month_price, status) FROM stdin;
\.


--
-- Data for Name: digitalglarus_bookingprice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_bookingprice (id, price_per_day, special_month_price) FROM stdin;
\.


--
-- Data for Name: digitalglarus_dggallery; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_dggallery (id, name, parent_id) FROM stdin;
\.


--
-- Data for Name: digitalglarus_dggalleryplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_dggalleryplugin (cmsplugin_ptr_id, "dgGallery_id") FROM stdin;
\.


--
-- Data for Name: digitalglarus_dgpicture; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_dgpicture (id, description, gallery_id, image_id) FROM stdin;
\.


--
-- Data for Name: digitalglarus_dgsupportersplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_dgsupportersplugin (cmsplugin_ptr_id) FROM stdin;
\.


--
-- Data for Name: digitalglarus_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_membership (id, type_id, active, end_date, start_date) FROM stdin;
\.


--
-- Data for Name: digitalglarus_membershiporder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_membershiporder (id, created_at, approved, last4, cc_brand, stripe_charge_id, membership_id, billing_address_id, customer_id, amount, end_date, start_date, stripe_subscription_id) FROM stdin;
\.


--
-- Data for Name: digitalglarus_membershiptype; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_membershiptype (id, name, price) FROM stdin;
1	standard	20
\.


--
-- Data for Name: digitalglarus_supporter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.digitalglarus_supporter (id, name, description) FROM stdin;
1	Hack4Glarus	Supports the project.
2	Alpine Cloud	Supports the project.
3	Linux Verein	Supports the project.
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_celery_results_taskresult; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_celery_results_taskresult (id, task_id, status, content_type, content_encoding, result, date_done, traceback, hidden, meta) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	cms	placeholder
2	cms	page
3	djangocms_blog	latestpostsplugin
4	membership	customuser
5	membership	stripecustomer
6	membership	creditcards
7	membership	deleteduser
8	membership	calendar
9	admin	logentry
10	auth	permission
11	auth	group
12	contenttypes	contenttype
13	sessions	session
14	sites	site
15	multisite	alias
16	easy_thumbnails	source
17	easy_thumbnails	thumbnail
18	easy_thumbnails	thumbnaildimensions
19	utils	billingaddress
20	utils	userbillingaddress
21	utils	contactmessage
22	stored_messages	message
23	stored_messages	messagearchive
24	stored_messages	inbox
25	guardian	userobjectpermission
26	guardian	groupobjectpermission
27	taggit	tag
28	taggit	taggeditem
29	filer	folder
30	filer	folderpermission
31	filer	file
32	filer	clipboard
33	filer	clipboarditem
34	filer	image
35	filer	thumbnailoption
36	djangocms_blog	blogconfigtranslation
37	djangocms_blog	blogconfig
38	djangocms_blog	blogcategorytranslation
39	djangocms_blog	blogcategory
40	djangocms_blog	posttranslation
41	djangocms_blog	post
42	djangocms_blog	authorentriesplugin
43	djangocms_blog	genericblogplugin
44	cms	usersettings
45	cms	globalpagepermission
46	cms	pagepermission
47	cms	pageuser
48	cms	pageusergroup
49	cms	cmsplugin
50	cms	title
51	cms	placeholderreference
52	cms	staticplaceholder
53	cms	aliaspluginmodel
54	cms	urlconfrevision
55	aldryn_categories	categorytranslation
56	aldryn_categories	category
57	aldryn_newsblog	newsblogconfigtranslation
58	aldryn_newsblog	newsblogconfig
59	aldryn_newsblog	articletranslation
60	aldryn_newsblog	article
61	aldryn_newsblog	newsblogarchiveplugin
62	aldryn_newsblog	newsblogarticlesearchplugin
63	aldryn_newsblog	newsblogauthorsplugin
64	aldryn_newsblog	newsblogcategoriesplugin
65	aldryn_newsblog	newsblogfeaturedarticlesplugin
66	aldryn_newsblog	newsbloglatestarticlesplugin
67	aldryn_newsblog	newsblogrelatedplugin
68	aldryn_newsblog	newsblogtagsplugin
69	aldryn_people	grouptranslation
70	aldryn_people	group
71	aldryn_people	persontranslation
72	aldryn_people	person
73	aldryn_people	peopleplugin
74	menus	cachekey
75	cmsplugin_filer_image	filerimage
76	cmsplugin_filer_image	thumbnailoption
77	djangocms_file	file
78	djangocms_picture	picture
79	djangocms_video	video
80	djangocms_page_meta	pagemeta
81	djangocms_page_meta	titlemeta
82	djangocms_text_ckeditor	text
83	cmsplugin_filer_file	filerfile
84	cmsplugin_filer_folder	filerfolder
85	cmsplugin_filer_link	filerlinkplugin
86	cmsplugin_filer_video	filervideo
87	reversion	revision
88	reversion	version
89	ungleich	ungleichpage
90	ungleich_page	ungelichpicture
91	ungleich_page	sectionwithimage
92	ungleich_page	ungelichcontactussection
93	ungleich_page	ungelichtextsection
94	ungleich_page	service
95	ungleich_page	serviceitem
96	ungleich_page	about
97	ungleich_page	aboutitem
98	ungleich_page	ungleichserviceitem
99	ungleich_page	ungleichheaderwithbackgroundimageslider
100	ungleich_page	ungleichheaderwithbackgroundvideoslideritem
101	ungleich_page	ungleichproductitem
102	ungleich_page	ungleichproduct
103	ungleich_page	ungleichcustomer
104	ungleich_page	ungleichcustomeritem
105	ungleich_page	ungleichhtmlonly
106	ungleich_page	ungleichfooter
107	hosting	hostingplan
108	hosting	orderdetail
109	hosting	genericproduct
110	hosting	hostingorder
111	hosting	userhostingkey
112	hosting	hostingbill
113	hosting	monthlyhostingbill
114	hosting	hostingbilllineitem
115	hosting	vmdetail
116	hosting	usercarddetail
117	hosting	vatrates
118	hosting	stripetaxrate
119	hosting	incompletepaymentintents
120	hosting	incompletesubscriptions
121	digitalglarus	membershiptype
122	digitalglarus	membership
123	digitalglarus	membershiporder
124	digitalglarus	bookingprice
125	digitalglarus	booking
126	digitalglarus	bookingorder
127	digitalglarus	bookingcancellation
128	digitalglarus	supporter
129	digitalglarus	dggallery
130	digitalglarus	dgpicture
131	digitalglarus	dggalleryplugin
132	digitalglarus	dgsupportersplugin
133	nosystemd	donatorstatus
134	nosystemd	donation
135	datacenterlight	vmtemplate
136	datacenterlight	vmpricing
137	datacenterlight	stripeplan
138	datacenterlight	contactus
139	datacenterlight	cmsintegration
140	datacenterlight	cmsfaviconextension
141	datacenterlight	dclsectionpluginmodel
142	datacenterlight	dclbannerlistpluginmodel
143	datacenterlight	dclbanneritempluginmodel
144	datacenterlight	dcllinkpluginmodel
145	datacenterlight	dclnavbarpluginmodel
146	datacenterlight	dclnavbardropdownpluginmodel
147	datacenterlight	dclcontactpluginmodel
148	datacenterlight	dclfooterpluginmodel
149	datacenterlight	dclsectioniconpluginmodel
150	datacenterlight	dclsectionimagepluginmodel
151	datacenterlight	dclsectionpromopluginmodel
152	datacenterlight	dclcalculatorpluginmodel
153	django_celery_results	taskresult
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	membership	0001_initial	2026-09-30 11:26:49.506719+00
2	contenttypes	0001_initial	2026-09-30 11:26:49.662049+00
3	admin	0001_initial	2026-09-30 11:26:49.928911+00
4	admin	0002_logentry_remove_auto_add	2026-09-30 11:26:50.102164+00
5	aldryn_categories	0001_initial	2026-09-30 11:26:51.017555+00
6	aldryn_categories	0002_auto_20150109_1415	2026-09-30 11:26:51.051134+00
7	aldryn_categories	0003_auto_20150128_1359	2026-09-30 11:26:51.129994+00
8	aldryn_categories	0004_auto_20150623_0859	2026-09-30 11:26:51.161868+00
9	sites	0001_initial	2026-09-30 11:26:51.241304+00
10	auth	0001_initial	2026-09-30 11:26:51.854342+00
11	cms	0001_initial	2026-09-30 11:26:54.269476+00
12	cms	0002_auto_20140816_1918	2026-09-30 11:26:56.727404+00
13	cms	0003_auto_20140926_2347	2026-09-30 11:26:56.825432+00
14	taggit	0001_initial	2026-09-30 11:26:57.360751+00
15	filer	0001_initial	2026-09-30 11:26:58.943186+00
16	aldryn_people	0001_initial	2026-09-30 11:27:00.634555+00
17	aldryn_newsblog	0001_initial	2026-09-30 11:27:04.59591+00
18	aldryn_newsblog	0002_newsblogconfig_template_prefix	2026-09-30 11:27:04.70255+00
19	aldryn_newsblog	0003_auto_20150422_1921	2026-09-30 11:27:04.785726+00
20	aldryn_newsblog	0004_auto_20150622_1606	2026-09-30 11:27:04.835834+00
21	aldryn_newsblog	0005_auto_20150807_0207	2026-09-30 11:27:04.897326+00
22	aldryn_newsblog	0006_auto_20160105_1013	2026-09-30 11:27:05.207517+00
23	aldryn_newsblog	0007_default_newsblog_config	2026-09-30 11:27:05.513266+00
24	aldryn_newsblog	0008_auto_20160106_1735	2026-09-30 11:27:05.96914+00
25	aldryn_newsblog	0009_auto_20160211_1022	2026-09-30 11:27:06.046758+00
26	aldryn_newsblog	0010_auto_20160316_0935	2026-09-30 11:27:06.169073+00
27	aldryn_people	0002_auto_20150128_1411	2026-09-30 11:27:06.354806+00
28	aldryn_people	0003_auto_20150425_2103	2026-09-30 11:27:06.446778+00
29	aldryn_people	0004_auto_20150622_1606	2026-09-30 11:27:06.768795+00
30	aldryn_people	0005_auto_20150723_1508	2026-09-30 11:27:07.003215+00
31	aldryn_people	0006_person_groups	2026-09-30 11:27:07.280966+00
32	aldryn_people	0007_copy_group	2026-09-30 11:27:07.305156+00
33	aldryn_people	0008_remove_person_group	2026-09-30 11:27:07.461369+00
34	aldryn_people	0009_auto_20150724_1654	2026-09-30 11:27:07.692182+00
35	aldryn_people	0010_auto_20150724_1654	2026-09-30 11:27:07.709011+00
36	aldryn_people	0011_auto_20150724_1900	2026-09-30 11:27:08.125774+00
37	aldryn_people	0012_auto_20150728_1114	2026-09-30 11:27:08.214638+00
38	aldryn_people	0013_peopleplugin_show_ungrouped	2026-09-30 11:27:08.281328+00
39	aldryn_people	0014_auto_20150807_0033	2026-09-30 11:27:08.570213+00
40	aldryn_people	0015_m2m_remove_null	2026-09-30 11:27:08.670764+00
41	aldryn_people	0016_person_fk_to_one_to_one	2026-09-30 11:27:08.759426+00
42	aldryn_people	0017_auto_20160109_1951	2026-09-30 11:27:08.881451+00
43	contenttypes	0002_remove_content_type_name	2026-09-30 11:27:09.159437+00
44	auth	0002_alter_permission_name_max_length	2026-09-30 11:27:09.226098+00
45	auth	0003_alter_user_email_max_length	2026-09-30 11:27:09.284416+00
46	auth	0004_alter_user_username_opts	2026-09-30 11:27:09.340264+00
47	auth	0005_alter_user_last_login_null	2026-09-30 11:27:09.394383+00
48	auth	0006_require_contenttypes_0002	2026-09-30 11:27:09.403889+00
49	auth	0007_alter_validators_add_error_messages	2026-09-30 11:27:09.463668+00
50	cms	0004_auto_20140924_1038	2026-09-30 11:27:09.770769+00
51	cms	0005_auto_20140924_1039	2026-09-30 11:27:09.787445+00
52	cms	0006_auto_20140924_1110	2026-09-30 11:27:10.627344+00
53	cms	0007_auto_20141028_1559	2026-09-30 11:27:10.804858+00
54	cms	0008_auto_20150208_2149	2026-09-30 11:27:10.993175+00
55	cms	0008_auto_20150121_0059	2026-09-30 11:27:11.127195+00
56	cms	0009_merge	2026-09-30 11:27:11.138968+00
57	cms	0010_migrate_use_structure	2026-09-30 11:27:11.260166+00
58	cms	0011_auto_20150419_1006	2026-09-30 11:27:11.393235+00
59	cms	0012_auto_20150607_2207	2026-09-30 11:27:11.560339+00
60	cms	0013_urlconfrevision	2026-09-30 11:27:11.638521+00
61	cms	0014_auto_20160404_1908	2026-09-30 11:27:11.66149+00
62	cmsplugin_filer_file	0001_initial	2026-09-30 11:27:11.90722+00
63	cmsplugin_filer_file	0002_auto_20160112_1617	2026-09-30 11:27:12.051642+00
64	cmsplugin_filer_folder	0001_initial	2026-09-30 11:27:12.238773+00
65	cmsplugin_filer_folder	0002_auto_20160113_1318	2026-09-30 11:27:12.384961+00
66	cmsplugin_filer_image	0001_initial	2026-09-30 11:27:12.921324+00
67	cmsplugin_filer_image	0002_auto_20160108_1708	2026-09-30 11:27:13.206656+00
68	cmsplugin_filer_link	0001_initial	2026-09-30 11:27:13.498508+00
69	cmsplugin_filer_link	0002_auto_20160108_1710	2026-09-30 11:27:13.707361+00
70	cmsplugin_filer_video	0001_initial	2026-09-30 11:27:14.018494+00
71	cmsplugin_filer_video	0002_auto_20160108_1710	2026-09-30 11:27:14.27488+00
72	sites	0002_alter_domain_unique	2026-09-30 11:27:14.452659+00
73	datacenterlight	0001_initial	2026-09-30 11:27:14.533417+00
74	datacenterlight	0002_betaaccessvm	2026-09-30 11:27:14.608259+00
75	datacenterlight	0003_auto_20170214_1638	2026-09-30 11:27:14.654771+00
76	datacenterlight	0004_betaaccessvm	2026-09-30 11:27:14.855039+00
77	datacenterlight	0005_betaaccess_name	2026-09-30 11:27:14.944179+00
78	datacenterlight	0006_vmtemplate	2026-09-30 11:27:15.011073+00
79	datacenterlight	0007_stripeplan	2026-09-30 11:27:15.086418+00
80	datacenterlight	0008_auto_20170821_2024	2026-09-30 11:27:15.13414+00
81	datacenterlight	0007_contactus	2026-09-30 11:27:15.269114+00
82	datacenterlight	0009_merge	2026-09-30 11:27:15.280629+00
83	datacenterlight	0008_contactus_field	2026-09-30 11:27:15.310921+00
84	datacenterlight	0010_merge	2026-09-30 11:27:15.324046+00
85	datacenterlight	0011_auto_20180220_1423	2026-09-30 11:27:15.45599+00
86	datacenterlight	0012_dclcalculatorpluginmodel	2026-09-30 11:27:17.016091+00
87	datacenterlight	0013_dclnavbarpluginmodel	2026-09-30 11:27:17.282723+00
88	datacenterlight	0014_dclsectionpromopluginmodel	2026-09-30 11:27:17.638384+00
89	datacenterlight	0014_dclnavbarpluginmodel_language_dropdown	2026-09-30 11:27:17.758012+00
90	datacenterlight	0015_auto_20180323_0011	2026-09-30 11:27:17.857749+00
91	datacenterlight	0016_cmsintegration	2026-09-30 11:27:18.313711+00
92	datacenterlight	0017_auto_20180329_0056	2026-09-30 11:27:18.592966+00
93	datacenterlight	0018_auto_20180403_1930	2026-09-30 11:27:19.083923+00
94	datacenterlight	0019_cmsfaviconextension	2026-09-30 11:27:19.417467+00
95	datacenterlight	0019_auto_20180415_2236	2026-09-30 11:27:19.960461+00
96	datacenterlight	0020_merge	2026-09-30 11:27:19.970917+00
97	datacenterlight	0021_cmsintegration_calculator_placeholder	2026-09-30 11:27:20.250403+00
98	datacenterlight	0022_auto_20180506_1950	2026-09-30 11:27:20.504394+00
99	datacenterlight	0023_auto_20180524_0349	2026-09-30 11:27:20.60415+00
100	datacenterlight	0024_dclcalculatorpluginmodel_vm_templates_to_show	2026-09-30 11:27:20.737753+00
101	datacenterlight	0025_dclnavbarpluginmodel_show_login_option	2026-09-30 11:27:20.827156+00
102	datacenterlight	0026_dclcalculatorpluginmodel_default_selected_template	2026-09-30 11:27:20.915463+00
103	datacenterlight	0027_dclcalculatorpluginmodel_enable_512mb_ram	2026-09-30 11:27:21.137617+00
104	datacenterlight	0028_stripeplan_stripe_plan_name	2026-09-30 11:27:21.216745+00
105	datacenterlight	0029_auto_20190420_1022	2026-09-30 11:27:21.250102+00
106	datacenterlight	0030_dclnavbarpluginmodel_show_non_transparent_navbar_always	2026-09-30 11:27:21.360062+00
107	datacenterlight	0031_vmpricing_stripe_coupon_id	2026-09-30 11:27:21.460203+00
108	utils	0001_initial	2026-09-30 11:27:21.583058+00
109	utils	0002_billingaddress	2026-09-30 11:27:21.675409+00
110	membership	0002_auto_20160324_2336	2026-09-30 11:27:21.78335+00
111	membership	0003_auto_20160422_1002	2026-09-30 11:27:22.095132+00
112	membership	0004_stripecustomer	2026-09-30 11:27:22.429104+00
113	membership	0005_customuser_is_admin	2026-09-30 11:27:22.57253+00
114	membership	0006_auto_20160526_0445	2026-09-30 11:27:23.332453+00
115	filer	0002_auto_20150606_2003	2026-09-30 11:27:23.473914+00
116	digitalglarus	0001_initial	2026-09-30 11:27:24.431766+00
117	digitalglarus	0002_auto_20160324_2321	2026-09-30 11:27:24.442028+00
118	digitalglarus	0003_auto_20160325_1659	2026-09-30 11:27:25.265059+00
119	digitalglarus	0004_dggallery_dggalleryplugin_dgpicture_dgsupportersplugin_supporter	2026-09-30 11:27:25.991626+00
120	digitalglarus	0005_auto_20160407_0519	2026-09-30 11:27:26.027832+00
121	digitalglarus	0006_delete_message	2026-09-30 11:27:26.069724+00
122	digitalglarus	0007_auto_20160820_0408	2026-09-30 11:27:26.357511+00
123	digitalglarus	0008_auto_20160820_1959	2026-09-30 11:27:26.600851+00
124	digitalglarus	0009_booking_bookingorder_bookingprices	2026-09-30 11:27:27.30418+00
125	digitalglarus	0010_auto_20160828_1745	2026-09-30 11:27:27.347331+00
126	digitalglarus	0011_bookingprice_special_price_offer	2026-09-30 11:27:27.38932+00
127	digitalglarus	0012_booking_free_days	2026-09-30 11:27:27.522575+00
128	digitalglarus	0013_remove_booking_membership	2026-09-30 11:27:27.644547+00
129	digitalglarus	0014_booking_final_price	2026-09-30 11:27:27.757301+00
130	digitalglarus	0015_auto_20160908_0149	2026-09-30 11:27:27.935121+00
131	digitalglarus	0016_auto_20160909_0110	2026-09-30 11:27:28.112799+00
132	digitalglarus	0017_membership_active	2026-09-30 11:27:28.324115+00
133	digitalglarus	0018_auto_20160928_0424	2026-09-30 11:27:28.501913+00
134	digitalglarus	0019_auto_20160929_0324	2026-09-30 11:27:28.679702+00
135	digitalglarus	0020_auto_20161013_0253	2026-09-30 11:27:29.146434+00
136	digitalglarus	0021_auto_20161017_1958	2026-09-30 11:27:29.468747+00
137	digitalglarus	0022_auto_20161023_0218	2026-09-30 11:27:29.646658+00
138	digitalglarus	0023_bookingorder_status	2026-09-30 11:27:29.746712+00
139	digitalglarus	0024_bookingcancellation	2026-09-30 11:27:30.059409+00
140	digitalglarus	0025_membershiporder_stripe_subscription_id	2026-09-30 11:27:30.180621+00
141	digitalglarus	0026_auto_20180824_0739	2026-09-30 11:27:30.369283+00
142	django_celery_results	0001_initial	2026-09-30 11:27:30.61651+00
143	djangocms_blog	0001_initial	2026-09-30 11:27:33.385251+00
144	djangocms_blog	0002_post_sites	2026-09-30 11:27:33.731916+00
145	djangocms_blog	0003_auto_20141201_2252	2026-09-30 11:27:33.896198+00
146	djangocms_blog	0004_auto_20150108_1435	2026-09-30 11:27:34.373752+00
147	djangocms_blog	0005_auto_20150212_1118	2026-09-30 11:27:34.596031+00
148	djangocms_blog	0006_auto_20150214_1907	2026-09-30 11:27:34.718002+00
149	djangocms_blog	0007_auto_20150719_0933	2026-09-30 11:27:37.596911+00
150	djangocms_blog	0008_auto_20150814_0831	2026-09-30 11:27:37.696604+00
151	djangocms_blog	0009_latestpostsplugin_tags_new	2026-09-30 11:27:37.986138+00
152	djangocms_blog	0010_auto_20150923_1151	2026-09-30 11:27:39.755691+00
153	djangocms_blog	0011_auto_20151024_1809	2026-09-30 11:27:40.909657+00
154	djangocms_blog	0012_auto_20151220_1734	2026-09-30 11:27:41.009856+00
155	djangocms_blog	0013_auto_20160201_2235	2026-09-30 11:27:41.154117+00
156	djangocms_blog	0014_auto_20160215_1331	2026-09-30 11:27:41.172984+00
157	djangocms_blog	0015_auto_20160408_1849	2026-09-30 11:27:41.476733+00
158	djangocms_blog	0016_auto_20160502_1741	2026-09-30 11:27:41.765472+00
159	djangocms_blog	0017_thumbnail_move	2026-09-30 11:27:41.776704+00
160	djangocms_blog	0018_thumbnail_move2	2026-09-30 11:27:41.787822+00
161	djangocms_blog	0019_thumbnail_move3	2026-09-30 11:27:41.79943+00
162	djangocms_blog	0020_thumbnail_move4	2026-09-30 11:27:41.810548+00
163	djangocms_blog	0021_post_liveblog	2026-09-30 11:27:41.976848+00
164	djangocms_blog	0022_auto_20160605_2305	2026-09-30 11:27:42.232317+00
165	djangocms_blog	0023_auto_20160626_1539	2026-09-30 11:27:42.521265+00
166	djangocms_blog	0024_auto_20160706_1524	2026-09-30 11:27:42.810282+00
167	djangocms_blog	0025_auto_20160803_0858	2026-09-30 11:27:43.054892+00
168	djangocms_blog	0021_auto_20160823_2008	2026-09-30 11:27:43.599654+00
169	djangocms_blog	0026_merge	2026-09-30 11:27:43.6108+00
170	djangocms_blog	0027_post_date_featured	2026-09-30 11:27:43.854976+00
171	djangocms_blog	0028_auto_20170304_1040	2026-09-30 11:27:43.866224+00
172	djangocms_blog	0029_post_related	2026-09-30 11:27:44.250455+00
173	djangocms_blog	0030_auto_20170509_1831	2026-09-30 11:27:44.448856+00
174	djangocms_blog	0031_auto_20170610_1744	2026-09-30 11:27:44.615784+00
175	djangocms_blog	0032_auto_20180109_0023	2026-09-30 11:27:45.371738+00
176	djangocms_file	0001_initial	2026-09-30 11:27:45.538549+00
177	djangocms_file	0002_auto_20151202_1551	2026-09-30 11:27:45.894116+00
178	djangocms_file	0003_remove_related_name_for_cmsplugin_ptr	2026-09-30 11:27:46.138372+00
179	djangocms_file	0004_set_related_name_for_cmsplugin_ptr	2026-09-30 11:27:46.260961+00
180	djangocms_page_meta	0001_initial	2026-09-30 11:27:47.010699+00
181	djangocms_page_meta	0002_auto_20150807_0936	2026-09-30 11:27:47.129356+00
182	djangocms_page_meta	0003_auto_20151220_1734	2026-09-30 11:27:47.54105+00
183	djangocms_picture	0001_initial	2026-09-30 11:27:47.796494+00
184	djangocms_picture	0002_auto_20151018_1927	2026-09-30 11:27:48.028992+00
185	djangocms_picture	0003_set_related_name_for_cmsplugin_ptr	2026-09-30 11:27:48.15138+00
186	djangocms_text_ckeditor	0001_initial	2026-09-30 11:27:48.507501+00
187	djangocms_text_ckeditor	0002_remove_related_name_for_cmsplugin_ptr	2026-09-30 11:27:48.663326+00
188	djangocms_text_ckeditor	0003_set_related_name_for_cmsplugin_ptr	2026-09-30 11:27:48.785745+00
189	djangocms_video	0001_initial	2026-09-30 11:27:49.0077+00
190	djangocms_video	0002_set_related_name_for_cmsplugin_ptr	2026-09-30 11:27:49.141305+00
191	easy_thumbnails	0001_initial	2026-09-30 11:27:49.789829+00
192	easy_thumbnails	0002_thumbnaildimensions	2026-09-30 11:27:49.922089+00
193	filer	0003_thumbnailoption	2026-09-30 11:27:49.998136+00
194	filer	0004_auto_20160328_1434	2026-09-30 11:27:50.119789+00
195	guardian	0001_initial	2026-09-30 11:27:51.213699+00
196	membership	0007_auto_20180213_0128	2026-09-30 11:27:51.376316+00
197	hosting	0001_initial	2026-09-30 11:27:51.38747+00
198	hosting	0002_railsbetauser	2026-09-30 11:27:51.544248+00
199	hosting	0003_virtualmachinetypes	2026-09-30 11:27:51.669147+00
200	hosting	0004_auto_20160418_0034	2026-09-30 11:27:51.72487+00
201	hosting	0005_auto_20160418_0038	2026-09-30 11:27:51.766078+00
202	hosting	0006_auto_20160418_0103	2026-09-30 11:27:51.811822+00
203	hosting	0007_auto_20160418_0103	2026-09-30 11:27:51.856689+00
204	hosting	0008_virtualmachineplan	2026-09-30 11:27:52.270039+00
205	hosting	0009_auto_20160426_0444	2026-09-30 11:27:52.946753+00
206	hosting	0010_auto_20160426_0530	2026-09-30 11:27:53.22232+00
207	hosting	0011_auto_20160426_0555	2026-09-30 11:27:53.411469+00
208	hosting	0012_auto_20160501_1850	2026-09-30 11:27:53.778225+00
209	hosting	0013_auto_20160505_0302	2026-09-30 11:27:53.92283+00
210	hosting	0014_auto_20160505_0541	2026-09-30 11:27:54.068921+00
211	hosting	0015_auto_20160512_0448	2026-09-30 11:27:54.267079+00
212	hosting	0016_delete_railsbetauser	2026-09-30 11:27:54.290007+00
213	hosting	0017_virtualmachinetype_location	2026-09-30 11:27:54.411545+00
214	hosting	0018_virtualmachineplan_public_key	2026-09-30 11:27:54.722985+00
215	hosting	0019_virtualmachineplan_status	2026-09-30 11:27:54.856432+00
216	hosting	0020_auto_20160526_0258	2026-09-30 11:27:54.978769+00
217	hosting	0021_auto_20160526_0445	2026-09-30 11:27:55.09712+00
218	hosting	0022_virtualmachineplan_ip	2026-09-30 11:27:55.222914+00
219	hosting	0023_virtualmachineplan_configutarion	2026-09-30 11:27:55.467424+00
220	hosting	0024_auto_20160607_0231	2026-09-30 11:27:55.589821+00
221	hosting	0025_auto_20160621_0522	2026-09-30 11:27:55.812052+00
222	hosting	0026_auto_20160625_0028	2026-09-30 11:27:55.922718+00
223	hosting	0027_auto_20160711_0210	2026-09-30 11:27:56.036551+00
224	hosting	0028_managevm_userhostingkey	2026-09-30 11:27:56.435064+00
225	hosting	0029_userhostingkey_created_at	2026-09-30 11:27:56.57939+00
226	hosting	0030_userhostingkey_name	2026-09-30 11:27:56.701859+00
227	hosting	0031_auto_20170503_0554	2026-09-30 11:27:56.912117+00
228	hosting	0032_auto_20170504_0315	2026-09-30 11:27:57.390407+00
229	hosting	0033_virtualmachinetype_configuration	2026-09-30 11:27:57.512665+00
230	hosting	0034_auto_20170504_0331	2026-09-30 11:27:57.845865+00
231	hosting	0035_virtualmachineplan_opennebula_id	2026-09-30 11:27:58.101665+00
232	hosting	0036_auto_20170506_2312	2026-09-30 11:27:58.223726+00
233	utils	0003_userbillingaddress	2026-09-30 11:27:58.44767+00
234	utils	0004_auto_20161013_0253	2026-09-30 11:27:58.602133+00
235	utils	0005_auto_20170322_1443	2026-09-30 11:27:58.635374+00
236	hosting	0028_managevms	2026-09-30 11:27:58.656228+00
237	hosting	0029_managevm	2026-09-30 11:27:58.682488+00
238	hosting	0030_hostingbill	2026-09-30 11:27:58.949574+00
239	hosting	0031_hostingbill_total_price	2026-09-30 11:27:59.091175+00
240	hosting	0037_merge	2026-09-30 11:27:59.103047+00
241	hosting	0038_auto_20170512_1006	2026-09-30 11:27:59.581539+00
242	hosting	0039_hostingorder_price	2026-09-30 11:27:59.758316+00
243	hosting	0040_hostingplan	2026-09-30 11:27:59.836027+00
244	hosting	0041_userhostingkey_private_key	2026-09-30 11:28:00.003274+00
245	hosting	0042_hostingorder_subscription_id	2026-09-30 11:28:00.258285+00
246	hosting	0043_vmdetail	2026-09-30 11:28:00.648125+00
247	hosting	0044_hostingorder_vm_pricing	2026-09-30 11:28:00.892255+00
248	hosting	0045_auto_20180701_2028	2026-09-30 11:28:01.237805+00
249	hosting	0046_usercarddetail	2026-09-30 11:28:01.487627+00
250	hosting	0047_auto_20180821_1240	2026-09-30 11:28:01.881515+00
251	hosting	0048_auto_20181003_0757	2026-09-30 11:28:02.405351+00
252	hosting	0049_auto_20181005_0736	2026-09-30 11:28:02.559335+00
253	hosting	0050_monthlyhostingbill	2026-09-30 11:28:02.972408+00
254	hosting	0051_auto_20190403_0703	2026-09-30 11:28:03.349249+00
255	hosting	0052_hostingbilllineitem	2026-09-30 11:28:03.616815+00
256	hosting	0053_hostingbilllineitem_stripe_plan	2026-09-30 11:28:03.8278+00
257	hosting	0054_auto_20190508_2141	2026-09-30 11:28:03.994164+00
258	hosting	0055_auto_20190701_1614	2026-09-30 11:28:04.138761+00
259	hosting	0056_auto_20191026_0454	2026-09-30 11:28:04.562621+00
260	hosting	0057_vatrates	2026-09-30 11:28:04.72209+00
261	hosting	0058_genericproduct_product_subscription_interval	2026-09-30 11:28:04.863197+00
262	hosting	0059_stripetaxrate	2026-09-30 11:28:05.053339+00
263	hosting	0060_update_DE_vat_covid-19	2026-09-30 11:28:05.143062+00
264	hosting	0061_genericproduct_exclude_vat_calculations	2026-09-30 11:28:05.307771+00
265	hosting	0062_incompletesubscriptions	2026-09-30 11:28:05.432193+00
266	hosting	0063_auto_20201223_0612	2026-09-30 11:28:05.474825+00
267	hosting	0064_incompletepaymentintents	2026-09-30 11:28:05.622987+00
268	hosting	0065_auto_20201231_1041	2026-09-30 11:28:05.892+00
269	hosting	0066_auto_20230727_0812	2026-09-30 11:28:06.15347+00
270	membership	0008_change_user_id_to_customer_id_in_djangocms_blog	2026-09-30 11:29:35.332691+00
271	membership	0009_deleteduser	2026-09-30 11:29:35.773145+00
272	membership	0010_customuser_import_stripe_bill_remark	2026-09-30 11:29:36.128276+00
273	membership	0011_auto_20191218_1050	2026-09-30 11:29:36.682752+00
274	menus	0001_initial	2026-09-30 11:29:36.915605+00
275	multisite	0001_initial	2026-09-30 11:29:37.627207+00
276	nosystemd	0001_initial	2026-09-30 11:29:37.9831+00
277	nosystemd	0002_auto_20160723_1848	2026-09-30 11:29:38.196295+00
278	nosystemd	0003_donatorstatus	2026-09-30 11:29:38.428036+00
279	nosystemd	0004_auto_20160727_0521	2026-09-30 11:29:38.851329+00
280	reversion	0001_initial	2026-09-30 11:29:39.629897+00
281	reversion	0002_auto_20141216_1509	2026-09-30 11:29:40.107573+00
282	sessions	0001_initial	2026-09-30 11:29:40.340937+00
283	stored_messages	0001_initial	2026-09-30 11:29:41.278114+00
284	stored_messages	0002_message_url	2026-09-30 11:29:41.442127+00
285	taggit	0002_auto_20150616_2121	2026-09-30 11:29:41.641222+00
286	ungleich	0001_initial	2026-09-30 11:29:41.954302+00
287	ungleich	0002_ungleichpage_image	2026-09-30 11:29:42.286941+00
288	ungleich	0003_remove_ungleichpage_image_header	2026-09-30 11:29:42.430564+00
289	ungleich_page	0001_initial	2026-09-30 11:29:44.134356+00
290	ungleich_page	0002_sectionwithimage	2026-09-30 11:29:44.57765+00
291	ungleich_page	0003_auto_20171019_1007	2026-09-30 11:29:45.243969+00
292	ungleich_page	0004_auto_20171019_1113	2026-09-30 11:29:45.988118+00
293	ungleich_page	0005_auto_20171019_1517	2026-09-30 11:29:47.088746+00
294	ungleich_page	0006_aboutitem_link_url	2026-09-30 11:29:47.221916+00
295	ungleich_page	0007_auto_20171117_1011	2026-09-30 11:29:47.399835+00
296	ungleich_page	0008_ungleichserviceitem	2026-09-30 11:29:47.634056+00
297	ungleich_page	0009_ungleichheader_ungleichheaderitem	2026-09-30 11:29:48.28274+00
298	ungleich_page	0010_auto_20171119_1404	2026-09-30 11:29:48.467329+00
299	ungleich_page	0011_ungleichproduct_ungleichproductitem	2026-09-30 11:29:48.823411+00
300	ungleich_page	0012_ungleichcustomer_ungleichcustomeritem	2026-09-30 11:29:49.45888+00
301	ungleich_page	0013_ungleichhtmlonly	2026-09-30 11:29:49.801636+00
302	ungleich_page	0014_ungleichhtmlonly_name	2026-09-30 11:29:49.990709+00
303	ungleich_page	0015_ungleichsimpleheader	2026-09-30 11:29:50.351716+00
304	ungleich_page	0016_ungleichheaderwithbackgroundimageslider_ungleichheaderwithbackgroundimageslideritem	2026-09-30 11:29:50.962835+00
305	ungleich_page	0017_auto_20171219_1856	2026-09-30 11:29:51.318463+00
306	ungleich_page	0018_ungleichfooter	2026-09-30 11:29:51.571713+00
307	ungleich_page	0018_auto_20180105_1826	2026-09-30 11:29:53.172903+00
308	ungleich_page	0019_merge	2026-09-30 11:29:53.183007+00
309	ungleich_page	0020_auto_20180320_0216	2026-09-30 11:29:53.529292+00
310	ungleich_page	0021_ungleichproduct_animate	2026-09-30 11:29:53.816619+00
311	utils	0006_auto_20170810_1742	2026-09-30 11:29:54.083157+00
312	utils	0007_auto_20191226_0610	2026-09-30 11:29:55.461404+00
313	utils	0008_auto_20191226_1402	2026-09-30 11:29:55.727901+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
ybz5f9i2itkxns7jfo05i4fn16y05tup	NmQ0YmFhZTk5NjkwODk0MGQzMzYxOTRlOTE2ZGQxNGE4MjgxMTllOTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Ijc0IiwiX2F1dGhfdXNlcl9oYXNoIjoiNTEyOTBkOTVmZmIzNWNkNGYzNTQ2YmY1YjdjMDk5NDIxNzZjMjQ1MyJ9	2026-10-19 19:46:40.491246+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	example.com
2	ungleich.ch	ungleich.ch
3	datacenterlight.ch	datacenterlight.ch
4	rails-hosting.ch	rails-hosting.ch
5	127.0.0.1:8000	127.0.0.1:8000
6	comic.ungleich.ch	comic.ungleich.ch
7	django-hosting.ch	django-hosting.ch
8	hack4glarus.ch	hack4glarus.ch
9	digitalezukunft.ch	digitalezukunft.ch
10	ipv6onlyhosting.com	ipv6onlyhosting.com
11	node-hosting.ch	node-hosting.ch
12	xn--nglarus-n2a.ch	xn--nglarus-n2a.ch
13	localhost:8000	localhost:8000
14	blog.ungleich.ch	blog.ungleich.ch
15	digitalglarus.ch	digitalglarus.ch
16	devuanhosting.com	devuanhosting.com
17	devuanhosting.ch	devuanhosting.ch
\.


--
-- Data for Name: djangocms_blog_authorentriesplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_authorentriesplugin (cmsplugin_ptr_id, latest_posts, app_config_id, current_site, template_folder) FROM stdin;
\.


--
-- Data for Name: djangocms_blog_authorentriesplugin_authors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_authorentriesplugin_authors (id, authorentriesplugin_id, customuser_id) FROM stdin;
\.


--
-- Data for Name: djangocms_blog_blogcategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_blogcategory (id, date_created, date_modified, parent_id, app_config_id) FROM stdin;
3	2026-10-05 19:48:14.17489+00	2026-10-05 19:48:14.174991+00	\N	1
\.


--
-- Data for Name: djangocms_blog_blogcategory_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_blogcategory_translation (id, language_code, name, slug, master_id, meta_description) FROM stdin;
3	en	Operations	operations	3	
\.


--
-- Data for Name: djangocms_blog_blogconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_blogconfig (id, type, namespace, app_data) FROM stdin;
1	djangocms_blog.cms_appconfig.BlogConfig	Blog	{}
\.


--
-- Data for Name: djangocms_blog_blogconfig_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_blogconfig_translation (id, language_code, app_title, master_id, object_name) FROM stdin;
1	en-us	Blog	1	Article
2	de	Blog	1	Article
\.


--
-- Data for Name: djangocms_blog_genericblogplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_genericblogplugin (cmsplugin_ptr_id, app_config_id, current_site, template_folder) FROM stdin;
\.


--
-- Data for Name: djangocms_blog_latestpostsplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_latestpostsplugin (cmsplugin_ptr_id, latest_posts, app_config_id, current_site, template_folder) FROM stdin;
\.


--
-- Data for Name: djangocms_blog_latestpostsplugin_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_latestpostsplugin_categories (id, latestpostsplugin_id, blogcategory_id) FROM stdin;
\.


--
-- Data for Name: djangocms_blog_post; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_post (id, date_created, date_modified, date_published, date_published_end, publish, enable_comments, author_id, content_id, main_image_id, main_image_full_id, main_image_thumbnail_id, app_config_id, liveblog_id, enable_liveblog, date_featured) FROM stdin;
1	2026-10-05 19:48:14.223489+00	2026-10-05 19:48:14.223515+00	2026-10-05 19:48:14.222773+00	\N	t	f	74	1224	\N	\N	\N	1	1225	f	\N
2	2026-10-05 19:48:14.345466+00	2026-10-05 19:48:14.345498+00	2026-10-05 19:48:14.34489+00	\N	t	f	74	1226	\N	\N	\N	1	1227	f	\N
3	2026-10-05 19:48:14.402377+00	2026-10-05 19:48:14.402448+00	2026-10-05 19:48:14.400861+00	\N	t	f	74	1228	\N	\N	\N	1	1229	f	\N
4	2026-10-05 19:48:14.45673+00	2026-10-05 19:48:14.456768+00	2026-10-05 19:48:14.456152+00	\N	t	f	74	1230	\N	\N	\N	1	1231	f	\N
5	2026-10-05 19:48:14.546837+00	2026-10-05 19:48:14.546905+00	2026-10-05 19:48:14.545425+00	\N	t	f	74	1232	\N	\N	\N	1	1233	f	\N
6	2026-10-05 19:48:14.590244+00	2026-10-05 19:48:14.590359+00	2026-10-05 19:48:14.589502+00	\N	t	f	74	1234	\N	\N	\N	1	1235	f	\N
7	2026-10-05 19:48:14.646829+00	2026-10-05 19:48:14.646923+00	2026-10-05 19:48:14.645443+00	\N	t	f	74	1236	\N	\N	\N	1	1237	f	\N
8	2026-10-05 19:48:14.691699+00	2026-10-05 19:48:14.691767+00	2026-10-05 19:48:14.689997+00	\N	t	f	74	1238	\N	\N	\N	1	1239	f	\N
\.


--
-- Data for Name: djangocms_blog_post_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_post_categories (id, post_id, blogcategory_id) FROM stdin;
1	1	3
2	2	3
3	3	3
4	4	3
5	5	3
6	6	3
7	7	3
8	8	3
\.


--
-- Data for Name: djangocms_blog_post_related; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_post_related (id, from_post_id, to_post_id, sort_value) FROM stdin;
\.


--
-- Data for Name: djangocms_blog_post_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_post_sites (id, post_id, site_id) FROM stdin;
1	1	14
2	2	14
3	3	14
4	4	14
5	5	14
6	6	14
7	7	14
8	8	14
\.


--
-- Data for Name: djangocms_blog_post_translation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_blog_post_translation (id, language_code, title, slug, abstract, meta_description, meta_keywords, meta_title, post_text, master_id) FROM stdin;
1	en	Operations note 1	operations-note-1	<p>Short summary of note 1.</p>					1
2	en	Operations note 2	operations-note-2	<p>Short summary of note 2.</p>					2
3	en	Operations note 3	operations-note-3	<p>Short summary of note 3.</p>					3
4	en	Operations note 4	operations-note-4	<p>Short summary of note 4.</p>					4
5	en	Operations note 5	operations-note-5	<p>Short summary of note 5.</p>					5
6	en	Operations note 6	operations-note-6	<p>Short summary of note 6.</p>					6
7	en	Operations note 7	operations-note-7	<p>Short summary of note 7.</p>					7
8	en	Operations note 8	operations-note-8	<p>Short summary of note 8.</p>					8
\.


--
-- Data for Name: djangocms_file_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_file_file (cmsplugin_ptr_id, file, title, target, tooltip) FROM stdin;
\.


--
-- Data for Name: djangocms_page_meta_pagemeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_page_meta_pagemeta (id, og_type, og_author_url, og_author_fbid, og_publisher, og_app_id, twitter_author, twitter_site, twitter_type, gplus_author, gplus_type, extended_object_id, image_id, og_author_id, public_extension_id) FROM stdin;
\.


--
-- Data for Name: djangocms_page_meta_titlemeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_page_meta_titlemeta (id, keywords, description, og_description, twitter_description, gplus_description, extended_object_id, image_id, public_extension_id) FROM stdin;
\.


--
-- Data for Name: djangocms_picture_picture; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_picture_picture (cmsplugin_ptr_id, image, url, alt, longdesc, "float", page_link_id, height, width) FROM stdin;
\.


--
-- Data for Name: djangocms_text_ckeditor_text; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_text_ckeditor_text (cmsplugin_ptr_id, body) FROM stdin;
607	<h1>ungleich blog</h1><p>Notes from running data centers, networks and free software.</p>
624	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
608	<h1>ungleich blog</h1><p>Notes from running data centers, networks and free software.</p>
609	<h1>About</h1><p>ungleich blog is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
625	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
610	<h1>About</h1><p>ungleich blog is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
611	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
643	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
612	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
613	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
626	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
614	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
615	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
627	<h1>Data Center Light</h1><p>Virtual machines from a Swiss, ecological data center.</p>
616	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
617	<h1>ungleich comic</h1><p>Life in the data center, one panel at a time.</p>
636	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
618	<h1>ungleich comic</h1><p>Life in the data center, one panel at a time.</p>
619	<h1>About</h1><p>ungleich comic is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
628	<h1>Data Center Light</h1><p>Virtual machines from a Swiss, ecological data center.</p>
620	<h1>About</h1><p>ungleich comic is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
621	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
629	<h1>About</h1><p>Data Center Light is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
622	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
623	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
637	<h1>Devuan Hosting</h1><p>Hosting on Devuan, the systemd-free Linux.</p>
648	<h1>Devuan Hosting</h1><p>Hosting on Devuan, the systemd-free Linux.</p>
630	<h1>About</h1><p>Data Center Light is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
631	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
638	<h1>Devuan Hosting</h1><p>Hosting on Devuan, the systemd-free Linux.</p>
632	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
633	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
639	<h1>About</h1><p>Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
634	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
635	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
644	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
640	<h1>About</h1><p>Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
641	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
645	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
642	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
649	<h1>About</h1><p>Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
646	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
647	<h1>Devuan Hosting</h1><p>Hosting on Devuan, the systemd-free Linux.</p>
651	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
653	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
650	<h1>About</h1><p>Devuan Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
652	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
654	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
655	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
656	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
657	<h1>digitalezukunft.ch</h1><p>Welcome to digitalezukunft.ch.</p>
658	<h1>digitalezukunft.ch</h1><p>Welcome to digitalezukunft.ch.</p>
659	<h1>About</h1><p>digitalezukunft.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
660	<h1>About</h1><p>digitalezukunft.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
661	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
679	<h1>About</h1><p>Django Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
662	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
663	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
690	<h1>About</h1><p>hack4glarus.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
664	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
665	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
680	<h1>About</h1><p>Django Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
666	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
667	<h1>Digital Glarus</h1><p>The Swiss IT valley in Schwanden, Glarus.</p>
681	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
668	<h1>Digital Glarus</h1><p>The Swiss IT valley in Schwanden, Glarus.</p>
669	<h1>About</h1><p>Digital Glarus is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
691	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
670	<h1>About</h1><p>Digital Glarus is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
671	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
682	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
672	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
673	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
683	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
674	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
675	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
702	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
676	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
677	<h1>Django Hosting</h1><p>Managed hosting for Django applications.</p>
684	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
678	<h1>Django Hosting</h1><p>Managed hosting for Django applications.</p>
685	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
698	<h1>ipv6onlyhosting.com</h1><p>Welcome to ipv6onlyhosting.com.</p>
692	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
686	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
687	<h1>hack4glarus.ch</h1><p>Welcome to hack4glarus.ch.</p>
693	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
688	<h1>hack4glarus.ch</h1><p>Welcome to hack4glarus.ch.</p>
689	<h1>About</h1><p>hack4glarus.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
699	<h1>About</h1><p>ipv6onlyhosting.com is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
694	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
695	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
703	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
696	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
697	<h1>ipv6onlyhosting.com</h1><p>Welcome to ipv6onlyhosting.com.</p>
700	<h1>About</h1><p>ipv6onlyhosting.com is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
701	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
708	<h1>Node.js Hosting</h1><p>Managed hosting for Node.js applications.</p>
706	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
704	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
705	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
707	<h1>Node.js Hosting</h1><p>Managed hosting for Node.js applications.</p>
710	<h1>About</h1><p>Node.js Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
709	<h1>About</h1><p>Node.js Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
711	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
712	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
713	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
714	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
715	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
716	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
717	<h1>Rails Hosting</h1><p>Managed hosting for Ruby on Rails applications.</p>
734	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
718	<h1>Rails Hosting</h1><p>Managed hosting for Ruby on Rails applications.</p>
719	<h1>About</h1><p>Rails Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
735	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
720	<h1>About</h1><p>Rails Hosting is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
721	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
722	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
723	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
746	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
736	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
724	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
725	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
737	<h1>xn--nglarus-n2a.ch</h1><p>Welcome to xn--nglarus-n2a.ch.</p>
726	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
727	<h1>ungleich</h1><p>Swiss IT infrastructure, hosting and open source.</p>
728	<h1>ungleich</h1><p>Swiss IT infrastructure, hosting and open source.</p>
729	<h1>About</h1><p>ungleich is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
738	<h1>xn--nglarus-n2a.ch</h1><p>Welcome to xn--nglarus-n2a.ch.</p>
730	<h1>About</h1><p>ungleich is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
731	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
739	<h1>About</h1><p>xn--nglarus-n2a.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
732	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
733	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
740	<h1>About</h1><p>xn--nglarus-n2a.ch is operated by ungleich GmbH in Switzerland. We run our own hardware and publish what we build as free software.</p>
741	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
742	<h1>Services</h1><p>Virtual machines, managed hosting and consulting, all running in our own data centers.</p>
743	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
744	<h1>Pricing</h1><p>Simple monthly plans, billed per resource with no minimum term.</p>
745	<h1>Contact</h1><p>Write to support@ungleich.ch and we will answer within one working day.</p>
\.


--
-- Data for Name: djangocms_video_video; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_video_video (cmsplugin_ptr_id, movie, movie_url, image, width, height, auto_play, auto_hide, fullscreen, loop, bgcolor, textcolor, seekbarcolor, seekbarbgcolor, loadingbarcolor, buttonoutcolor, buttonovercolor, buttonhighlightcolor) FROM stdin;
\.


--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.easy_thumbnails_source (id, storage_hash, name, modified) FROM stdin;
\.


--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM stdin;
\.


--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
\.


--
-- Data for Name: filer_clipboard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_clipboard (id, user_id) FROM stdin;
\.


--
-- Data for Name: filer_clipboarditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_clipboarditem (id, clipboard_id, file_id) FROM stdin;
\.


--
-- Data for Name: filer_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_file (id, file, _file_size, sha1, has_all_mandatory_data, original_filename, name, description, uploaded_at, modified_at, is_public, folder_id, owner_id, polymorphic_ctype_id) FROM stdin;
\.


--
-- Data for Name: filer_folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_folder (id, name, uploaded_at, created_at, modified_at, lft, rght, tree_id, level, owner_id, parent_id) FROM stdin;
\.


--
-- Data for Name: filer_folderpermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_folderpermission (id, type, everybody, can_edit, can_read, can_add_children, folder_id, group_id, user_id) FROM stdin;
\.


--
-- Data for Name: filer_image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_image (file_ptr_id, _height, _width, date_taken, default_alt_text, default_caption, author, must_always_publish_author_credit, must_always_publish_copyright, subject_location) FROM stdin;
\.


--
-- Data for Name: filer_thumbnailoption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_thumbnailoption (id, name, width, height, crop, upscale) FROM stdin;
\.


--
-- Data for Name: guardian_groupobjectpermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guardian_groupobjectpermission (id, object_pk, content_type_id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: guardian_userobjectpermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guardian_userobjectpermission (id, object_pk, content_type_id, permission_id, user_id) FROM stdin;
\.


--
-- Data for Name: hosting_genericproduct; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_genericproduct (id, product_name, product_slug, product_description, created_at, product_price, product_vat, product_is_subscription, product_subscription_interval, exclude_vat_calculations) FROM stdin;
\.


--
-- Data for Name: hosting_hostingbill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_hostingbill (id, billing_address_id, customer_id, total_price) FROM stdin;
\.


--
-- Data for Name: hosting_hostingbilllineitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_hostingbilllineitem (id, amount, description, discountable, metadata, period_start, period_end, proration, quantity, unit_amount, monthly_hosting_bill_id, stripe_plan_id) FROM stdin;
\.


--
-- Data for Name: hosting_hostingorder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_hostingorder (id, created_at, billing_address_id, customer_id, approved, stripe_charge_id, cc_brand, last4, vm_id, price, subscription_id, vm_pricing_id, order_detail_id, generic_payment_description, generic_product_id) FROM stdin;
\.


--
-- Data for Name: hosting_hostingplan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_hostingplan (id, disk_size, cpu_cores, memory) FROM stdin;
1	10	1	1
2	40	2	4
3	100	4	8
\.


--
-- Data for Name: hosting_incompletepaymentintents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_incompletepaymentintents (id, completed_at, created_at, payment_intent_id, request, stripe_api_cus_id, card_details_response, stripe_subscription_id, stripe_charge_id, gp_details, billing_address_data) FROM stdin;
\.


--
-- Data for Name: hosting_incompletesubscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_incompletesubscriptions (id, created_at, completed_at, subscription_id, subscription_status, name, email, request, stripe_api_cus_id, card_details_response, stripe_subscription_obj, stripe_onetime_charge, gp_details, specs, vm_template_id, template, billing_address_data) FROM stdin;
\.


--
-- Data for Name: hosting_monthlyhostingbill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_monthlyhostingbill (id, created, receipt_number, invoice_number, paid_at, period_start, period_end, billing_reason, discount, total, lines_data_count, invoice_id, lines_meta_data_csv, customer_id, order_id, subscription_ids_csv) FROM stdin;
\.


--
-- Data for Name: hosting_orderdetail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_orderdetail (id, cores, memory, hdd_size, ssd_size, vm_template_id) FROM stdin;
\.


--
-- Data for Name: hosting_stripetaxrate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_stripetaxrate (id, tax_rate_id, jurisdiction, inclusive, display_name, percentage, description) FROM stdin;
\.


--
-- Data for Name: hosting_usercarddetail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_usercarddetail (id, last4, brand, card_id, fingerprint, exp_month, exp_year, preferred, stripe_customer_id) FROM stdin;
\.


--
-- Data for Name: hosting_userhostingkey; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_userhostingkey (id, public_key, user_id, created_at, name, private_key) FROM stdin;
\.


--
-- Data for Name: hosting_vatrates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_vatrates (id, start_date, stop_date, territory_codes, currency_code, rate, rate_type, description) FROM stdin;
1	2020-07-01	\N	DE	EUR	0.16	standard	Germany (member state) standard VAT rate - COVID 19 reduced rate
\.


--
-- Data for Name: hosting_vmdetail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hosting_vmdetail (id, vm_id, disk_size, cores, memory, configuration, ipv4, ipv6, created_at, terminated_at, user_id) FROM stdin;
\.


--
-- Data for Name: membership_calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_calendar (id, datebooked, user_id) FROM stdin;
\.


--
-- Data for Name: membership_creditcards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_creditcards (id, name, card_number, expiry_date, ccv, payment_type, user_id_id) FROM stdin;
\.


--
-- Data for Name: membership_customuser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_customuser (id, password, last_login, name, email, validated, validation_slug, site_id, is_admin, is_superuser, import_stripe_bill_remark, in_ldap, username) FROM stdin;
1		\N	Anonymous	anonymous@ungleich.ch	0	!aBjbhsCRhyU1kkIg89cK8UamYS9zuwFnPhI2Uwuf	1	f	f		f	\N
75	pbkdf2_sha256$24000$JRUs11xUPLYj$XROqZFGPVOqpn8ukVxa8ESxuEwneqTHU2jOUg8mvp0w=	\N	Anna Dummy	dummy-customer-1@example.com	1	!CjoggzU7u4NQPB12iJzFj3Jjnn6Je3gd3wZWIgB0	1	f	f		f	\N
76	pbkdf2_sha256$24000$MjKxholzomy0$M2JWLP7Af/4ZwQqeVAbXDKPPR0xaAQ+DqRR9xPYtQvY=	\N	Luca Dummy	dummy-customer-2@example.com	1	!OPleEq8bdtj9I6HhsNjZpsz5Nj5I14KiUUl5DNsJ	1	f	f		f	\N
77	pbkdf2_sha256$24000$MiwQLUsYPoXb$xclIYl+y09MXFO7WEu53wNR/tQaegbPGZhAcEJIQBPE=	\N	Marta Dummy	dummy-customer-3@example.com	1	!YyCQt2GnxXUukwN3j7qx9PNnjj3tZqA8VVhJHqAs	1	f	f		f	\N
78	pbkdf2_sha256$24000$CZSdwZdDEvQZ$VMYVM8zpcww7uKcQuEOqb1Pzwlo4eO8DcaJvjodHBS8=	\N	Jonas Dummy	dummy-customer-4@example.com	0	!3Q4mbHeUY2OfAW5inmTWBUf49AMTbT9KzXdZ4nCM	1	f	f		f	\N
79	pbkdf2_sha256$24000$PcPTLSePYsVS$fOmEaiinJQSnAcJs4OVuc2ihInvEPJDqbpbEVoX7BHk=	\N	Sofia Dummy	dummy-customer-5@example.com	1	!bh0uSCCvNKvmUkM0k4Smij63cT3znEcRSjRSieZy	1	f	f		f	\N
80	pbkdf2_sha256$24000$lseazjgahp0X$y+gFbYso95P8JImFgq8g1rX0+NJnwOpKlOvozR6VVig=	\N	Noah Dummy	dummy-customer-6@example.com	1	!yanZ9WayLr9pX81oMIRWkg5uyML7134Ig40oajbQ	1	f	f		f	\N
81	pbkdf2_sha256$24000$mHtOgnK8uMuG$8+lTof32RolqDB9XApxzK9mmgkamImIWBUITbVEQOV8=	\N	Elena Dummy	dummy-customer-7@example.com	1	!Szr5ik6mjwB6IgfI3cmdsiQJKnOjHrkiEUIPlhwx	1	f	f		f	\N
82	pbkdf2_sha256$24000$m9af6a1219uK$3AfCxHYnsLn+LTsqtU/PTTnjMyhmGH1Bs2B9UbKeMFU=	\N	Felix Dummy	dummy-customer-8@example.com	0	!KkE5fw6Kl9bNC7Tk0dmEkqvoYB7y4iaOSGp2foXA	1	f	f		f	\N
83	pbkdf2_sha256$24000$IqHL7xyoWtzF$L2UJhdax+21CZr18HuTK3eweV9CvRk2jWppRKyBur1Q=	\N	Nina Dummy	dummy-customer-9@example.com	1	!ophjEslVK3506SAvG64AUGBFjk3LcKGDEVvkC2Gi	1	f	f		f	\N
84	pbkdf2_sha256$24000$wfqLGn8bcjn1$uFsh9ROB58xyEO+ivLjtYJwitbreazSBD/KygqXHHJs=	\N	Paul Dummy	dummy-customer-10@example.com	1	!VPOfFYoobouV8paqF4q8xzadaEA7Z5HFLsprRnEi	1	f	f		f	\N
85	pbkdf2_sha256$24000$wf0s21dMUT2G$O3/ixzZuuDtzBDtm+gPKaE8B8GGwkfxyHQrCSx61J7Q=	\N	Clara Dummy	dummy-customer-11@example.com	1	!6b2j0eUZBxkNhhEDfq5dtePUHeR1xgkuIUOh0SQu	1	f	f		f	\N
86	pbkdf2_sha256$24000$lmGeJ5tHYMR6$OjmQwHfo5LmLeLtyQoCaqh/TpLL2bAPB2nZwyEWp5mM=	\N	Ivan Dummy	dummy-customer-12@example.com	0	!g4H1e1GRP5FfMKWF5pb3Hhobml5oVv4en8V3daC1	1	f	f		f	\N
74	pbkdf2_sha256$24000$MlXB2w2xbKQw$XzNOTLhCKbE3jrvuezkDEx35cGRMjLQDH1pt/2YGbD8=	2026-10-05 19:46:40.357302+00	Dummy Admin	dummy-admin@example.com	1	!BDEynaln18u5rlTmKMuFrKL4LypFZSZecEk4Zl6k	1	t	t		f	\N
\.


--
-- Data for Name: membership_customuser_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_customuser_groups (id, customuser_id, group_id) FROM stdin;
\.


--
-- Data for Name: membership_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.


--
-- Data for Name: membership_deleteduser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_deleteduser (id, user_id, name, email, deleted_at) FROM stdin;
\.


--
-- Data for Name: membership_stripecustomer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_stripecustomer (id, stripe_id, user_id) FROM stdin;
\.


--
-- Data for Name: menus_cachekey; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menus_cachekey (id, language, site, key) FROM stdin;
33	en-us	2	menu_cache_menu_nodes_en-us_2
34	en-us	15	menu_cache_menu_nodes_en-us_15
35	en-us	16	menu_cache_menu_nodes_en-us_16
36	en-us	14	menu_cache_menu_nodes_en-us_14
37	en-us	6	menu_cache_menu_nodes_en-us_6
38	en-us	17	menu_cache_menu_nodes_en-us_17
39	en-us	9	menu_cache_menu_nodes_en-us_9
40	en-us	7	menu_cache_menu_nodes_en-us_7
41	en-us	8	menu_cache_menu_nodes_en-us_8
42	en-us	10	menu_cache_menu_nodes_en-us_10
43	en-us	11	menu_cache_menu_nodes_en-us_11
44	en-us	4	menu_cache_menu_nodes_en-us_4
45	en-us	12	menu_cache_menu_nodes_en-us_12
\.


--
-- Data for Name: multisite_alias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.multisite_alias (id, domain, is_canonical, redirect_to_canonical, site_id) FROM stdin;
1	example.com	t	t	1
2	ungleich.ch	t	t	2
3	datacenterlight.ch	t	t	3
4	rails-hosting.ch	t	t	4
5	127.0.0.1:8000	t	t	5
6	comic.ungleich.ch	t	t	6
7	django-hosting.ch	t	t	7
8	hack4glarus.ch	t	t	8
9	digitalezukunft.ch	t	t	9
10	ipv6onlyhosting.com	t	t	10
11	node-hosting.ch	t	t	11
12	xn--nglarus-n2a.ch	t	t	12
13	localhost:8000	t	t	13
14	blog.ungleich.ch	t	t	14
15	digitalglarus.ch	t	t	15
16	devuanhosting.com	t	t	16
17	devuanhosting.ch	t	t	17
\.


--
-- Data for Name: nosystemd_donation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nosystemd_donation (id, donation, created_at, last4, cc_brand, stripe_charge_id, billing_address_id, donator_id) FROM stdin;
\.


--
-- Data for Name: nosystemd_donatorstatus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nosystemd_donatorstatus (id, status, user_id) FROM stdin;
\.


--
-- Data for Name: reversion_revision; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reversion_revision (id, manager_slug, date_created, comment, user_id) FROM stdin;
\.


--
-- Data for Name: reversion_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reversion_version (id, object_id, object_id_int, format, serialized_data, object_repr, content_type_id, revision_id) FROM stdin;
\.


--
-- Data for Name: stored_messages_inbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stored_messages_inbox (id, message_id, user_id) FROM stdin;
\.


--
-- Data for Name: stored_messages_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stored_messages_message (id, message, level, tags, date, url) FROM stdin;
\.


--
-- Data for Name: stored_messages_messagearchive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stored_messages_messagearchive (id, message_id, user_id) FROM stdin;
\.


--
-- Data for Name: taggit_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taggit_tag (id, name, slug) FROM stdin;
\.


--
-- Data for Name: taggit_taggeditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM stdin;
\.


--
-- Data for Name: ungleich_page_about; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_about (service_ptr_id) FROM stdin;
\.


--
-- Data for Name: ungleich_page_aboutitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_aboutitem (ungelichpicture_ptr_id, inverted, link_url) FROM stdin;
\.


--
-- Data for Name: ungleich_page_sectionwithimage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_sectionwithimage (ungelichpicture_ptr_id, price_tag_url, price_tag_image_id, menu_text) FROM stdin;
\.


--
-- Data for Name: ungleich_page_service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_service (cmsplugin_ptr_id, title, sub_title, menu_text) FROM stdin;
\.


--
-- Data for Name: ungleich_page_serviceitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_serviceitem (cmsplugin_ptr_id, title, description, image_id) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungelichcontactussection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungelichcontactussection (cmsplugin_ptr_id, email, menu_text, address, contact_form_header_text, contact_text, country, organization_name) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungelichpicture; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungelichpicture (cmsplugin_ptr_id, title, image_id) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungelichtextsection; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungelichtextsection (cmsplugin_ptr_id, title, description, menu_text) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichcustomer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichcustomer (service_ptr_id, section_class, carousel_data_interval, bottom_text) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichcustomeritem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichcustomeritem (cmsplugin_ptr_id, url, description, image_id) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichfooter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichfooter (cmsplugin_ptr_id, copyright_label, link_text, link_url, twitter_url, linkedin_url, github_url, facebook_url, youtube_url) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichheaderwithbackgroundimageslider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichheaderwithbackgroundimageslider (cmsplugin_ptr_id, carousel_data_interval) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem (cmsplugin_ptr_id, description, image_id, btn_link, btn_text, heading, video_id) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichhtmlonly; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichhtmlonly (cmsplugin_ptr_id, "HTML", name) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichproduct; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichproduct (service_ptr_id, section_class, animate) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichproductitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichproductitem (serviceitem_ptr_id, url) FROM stdin;
\.


--
-- Data for Name: ungleich_page_ungleichserviceitem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_page_ungleichserviceitem (serviceitem_ptr_id, data_replaced_image_id) FROM stdin;
\.


--
-- Data for Name: ungleich_ungleichpage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ungleich_ungleichpage (id, extended_object_id, public_extension_id, image_id) FROM stdin;
\.


--
-- Data for Name: utils_billingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.utils_billingaddress (id, street_address, city, postal_code, country, cardholder_name, stripe_tax_id, vat_number, vat_number_validated_on, vat_validation_status) FROM stdin;
\.


--
-- Data for Name: utils_contactmessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.utils_contactmessage (id, name, email, phone_number, message, received_date) FROM stdin;
1	Visitor 1	visitor-1@example.com		Question number 1 about hosting.	2026-10-05 19:48:14.73432+00
2	Visitor 2	visitor-2@example.com		Question number 2 about hosting.	2026-10-05 19:48:14.745416+00
3	Visitor 3	visitor-3@example.com		Question number 3 about hosting.	2026-10-05 19:48:14.756459+00
4	Visitor 4	visitor-4@example.com		Question number 4 about hosting.	2026-10-05 19:48:14.767592+00
5	Visitor 5	visitor-5@example.com		Question number 5 about hosting.	2026-10-05 19:48:14.778843+00
6	Visitor 6	visitor-6@example.com		Question number 6 about hosting.	2026-10-05 19:48:14.790178+00
7	Visitor 7	visitor-7@example.com		Question number 7 about hosting.	2026-10-05 19:48:14.801301+00
8	Visitor 8	visitor-8@example.com		Question number 8 about hosting.	2026-10-05 19:48:14.812257+00
\.


--
-- Data for Name: utils_userbillingaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.utils_userbillingaddress (id, street_address, city, postal_code, country, current, user_id, cardholder_name, stripe_tax_id, vat_number, vat_number_validated_on, vat_validation_status) FROM stdin;
\.


--
-- Name: aldryn_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_categories_category_id_seq', 1, false);


--
-- Name: aldryn_categories_category_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_categories_category_translation_id_seq', 1, false);


--
-- Name: aldryn_newsblog_article_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_newsblog_article_categories_id_seq', 1, false);


--
-- Name: aldryn_newsblog_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_newsblog_article_id_seq', 1, false);


--
-- Name: aldryn_newsblog_article_related_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_newsblog_article_related_id_seq', 1, false);


--
-- Name: aldryn_newsblog_article_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_newsblog_article_translation_id_seq', 1, false);


--
-- Name: aldryn_newsblog_newsblogconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_newsblog_newsblogconfig_id_seq', 1, false);


--
-- Name: aldryn_newsblog_newsblogconfig_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_newsblog_newsblogconfig_translation_id_seq', 1, true);


--
-- Name: aldryn_people_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_people_group_id_seq', 1, false);


--
-- Name: aldryn_people_group_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_people_group_translation_id_seq', 1, false);


--
-- Name: aldryn_people_peopleplugin_people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_people_peopleplugin_people_id_seq', 1, false);


--
-- Name: aldryn_people_person_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_people_person_groups_id_seq', 1, false);


--
-- Name: aldryn_people_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_people_person_id_seq', 1, false);


--
-- Name: aldryn_people_person_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aldryn_people_person_translation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 445, true);


--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_cmsplugin_id_seq', 746, true);


--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_globalpagepermission_id_seq', 1, false);


--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_globalpagepermission_sites_id_seq', 1, false);


--
-- Name: cms_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_page_id_seq', 808, true);


--
-- Name: cms_page_placeholders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_page_placeholders_id_seq', 1215, true);


--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_pagepermission_id_seq', 1, false);


--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_placeholder_id_seq', 1239, true);


--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_staticplaceholder_id_seq', 1, false);


--
-- Name: cms_title_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_title_id_seq', 811, true);


--
-- Name: cms_urlconfrevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_urlconfrevision_id_seq', 1, false);


--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_usersettings_id_seq', 1, true);


--
-- Name: cmsplugin_filer_image_thumbnailoption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cmsplugin_filer_image_thumbnailoption_id_seq', 1, false);


--
-- Name: datacenterlight_cmsfaviconextension_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.datacenterlight_cmsfaviconextension_id_seq', 1, false);


--
-- Name: datacenterlight_cmsintegration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.datacenterlight_cmsintegration_id_seq', 1, false);


--
-- Name: datacenterlight_contactus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.datacenterlight_contactus_id_seq', 5, true);


--
-- Name: datacenterlight_stripeplan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.datacenterlight_stripeplan_id_seq', 1, false);


--
-- Name: datacenterlight_vmpricing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.datacenterlight_vmpricing_id_seq', 1, false);


--
-- Name: datacenterlight_vmtemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.datacenterlight_vmtemplate_id_seq', 1, false);


--
-- Name: digitalglarus_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_booking_id_seq', 1, false);


--
-- Name: digitalglarus_bookingcancellation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_bookingcancellation_id_seq', 1, false);


--
-- Name: digitalglarus_bookingorder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_bookingorder_id_seq', 1, false);


--
-- Name: digitalglarus_bookingprices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_bookingprices_id_seq', 1, false);


--
-- Name: digitalglarus_dggallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_dggallery_id_seq', 1, false);


--
-- Name: digitalglarus_dgpicture_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_dgpicture_id_seq', 1, false);


--
-- Name: digitalglarus_membership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_membership_id_seq', 1, false);


--
-- Name: digitalglarus_membershiporder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_membershiporder_id_seq', 1, false);


--
-- Name: digitalglarus_membershiptype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_membershiptype_id_seq', 1, true);


--
-- Name: digitalglarus_supporter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.digitalglarus_supporter_id_seq', 3, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_celery_results_taskresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_celery_results_taskresult_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 153, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 313, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_site_id_seq', 17, true);


--
-- Name: djangocms_blog_authorentriesplugin_authors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_authorentriesplugin_authors_id_seq', 1, false);


--
-- Name: djangocms_blog_blogcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_blogcategory_id_seq', 3, true);


--
-- Name: djangocms_blog_blogcategory_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_blogcategory_translation_id_seq', 3, true);


--
-- Name: djangocms_blog_blogconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_blogconfig_id_seq', 1, true);


--
-- Name: djangocms_blog_blogconfig_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_blogconfig_translation_id_seq', 2, true);


--
-- Name: djangocms_blog_latestpostsplugin_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_latestpostsplugin_categories_id_seq', 1, false);


--
-- Name: djangocms_blog_post_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_post_categories_id_seq', 8, true);


--
-- Name: djangocms_blog_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_post_id_seq', 8, true);


--
-- Name: djangocms_blog_post_related_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_post_related_id_seq', 1, false);


--
-- Name: djangocms_blog_post_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_post_sites_id_seq', 8, true);


--
-- Name: djangocms_blog_post_translation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_blog_post_translation_id_seq', 8, true);


--
-- Name: djangocms_page_meta_pagemeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_page_meta_pagemeta_id_seq', 1, false);


--
-- Name: djangocms_page_meta_titlemeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocms_page_meta_titlemeta_id_seq', 1, false);


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.easy_thumbnails_source_id_seq', 1, false);


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnail_id_seq', 1, false);


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnaildimensions_id_seq', 1, false);


--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_clipboard_id_seq', 1, false);


--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_clipboarditem_id_seq', 1, false);


--
-- Name: filer_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_file_id_seq', 1, false);


--
-- Name: filer_folder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_folder_id_seq', 1, false);


--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_folderpermission_id_seq', 1, false);


--
-- Name: filer_thumbnailoption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_thumbnailoption_id_seq', 1, false);


--
-- Name: guardian_groupobjectpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.guardian_groupobjectpermission_id_seq', 1, false);


--
-- Name: guardian_userobjectpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.guardian_userobjectpermission_id_seq', 1, false);


--
-- Name: hosting_genericproduct_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_genericproduct_id_seq', 1, false);


--
-- Name: hosting_hostingbill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_hostingbill_id_seq', 1, false);


--
-- Name: hosting_hostingbilllineitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_hostingbilllineitem_id_seq', 1, false);


--
-- Name: hosting_hostingorder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_hostingorder_id_seq', 1, false);


--
-- Name: hosting_hostingplan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_hostingplan_id_seq', 3, true);


--
-- Name: hosting_incompletepaymentintents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_incompletepaymentintents_id_seq', 1, false);


--
-- Name: hosting_incompletesubscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_incompletesubscriptions_id_seq', 1, false);


--
-- Name: hosting_monthlyhostingbill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_monthlyhostingbill_id_seq', 1, false);


--
-- Name: hosting_orderdetail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_orderdetail_id_seq', 1, false);


--
-- Name: hosting_stripetaxrate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_stripetaxrate_id_seq', 1, false);


--
-- Name: hosting_usercarddetail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_usercarddetail_id_seq', 1, false);


--
-- Name: hosting_userhostingkey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_userhostingkey_id_seq', 1, false);


--
-- Name: hosting_vatrates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_vatrates_id_seq', 1, true);


--
-- Name: hosting_vmdetail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hosting_vmdetail_id_seq', 1, false);


--
-- Name: membership_calendar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_calendar_id_seq', 1, false);


--
-- Name: membership_creditcards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_creditcards_id_seq', 1, false);


--
-- Name: membership_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_customuser_groups_id_seq', 1, false);


--
-- Name: membership_customuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_customuser_id_seq', 86, true);


--
-- Name: membership_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_customuser_user_permissions_id_seq', 1, false);


--
-- Name: membership_deleteduser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_deleteduser_id_seq', 1, false);


--
-- Name: membership_stripecustomer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_stripecustomer_id_seq', 1, false);


--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.menus_cachekey_id_seq', 45, true);


--
-- Name: multisite_alias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.multisite_alias_id_seq', 17, true);


--
-- Name: nosystemd_donation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nosystemd_donation_id_seq', 1, false);


--
-- Name: nosystemd_donatorstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nosystemd_donatorstatus_id_seq', 1, false);


--
-- Name: reversion_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reversion_revision_id_seq', 1, false);


--
-- Name: reversion_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reversion_version_id_seq', 1, false);


--
-- Name: stored_messages_inbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stored_messages_inbox_id_seq', 1, false);


--
-- Name: stored_messages_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stored_messages_message_id_seq', 1, false);


--
-- Name: stored_messages_messagearchive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stored_messages_messagearchive_id_seq', 1, false);


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggit_tag_id_seq', 1, false);


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggit_taggeditem_id_seq', 1, false);


--
-- Name: ungleich_ungleichpage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ungleich_ungleichpage_id_seq', 1, false);


--
-- Name: utils_billingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.utils_billingaddress_id_seq', 1, false);


--
-- Name: utils_contactmessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.utils_contactmessage_id_seq', 8, true);


--
-- Name: utils_userbillingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.utils_userbillingaddress_id_seq', 1, false);


--
-- Name: aldryn_categories_category aldryn_categories_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_categories_category
    ADD CONSTRAINT aldryn_categories_category_pkey PRIMARY KEY (id);


--
-- Name: aldryn_categories_category_translation aldryn_categories_category_translat_language_code_3582e565_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_categories_category_translation
    ADD CONSTRAINT aldryn_categories_category_translat_language_code_3582e565_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_categories_category_translation aldryn_categories_category_translat_language_code_6e9e9727_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_categories_category_translation
    ADD CONSTRAINT aldryn_categories_category_translat_language_code_6e9e9727_uniq UNIQUE (language_code, slug);


--
-- Name: aldryn_categories_category_translation aldryn_categories_category_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_categories_category_translation
    ADD CONSTRAINT aldryn_categories_category_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article_categories aldryn_newsblog_article_categories_article_id_4661b9b8_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_categories
    ADD CONSTRAINT aldryn_newsblog_article_categories_article_id_4661b9b8_uniq UNIQUE (article_id, category_id);


--
-- Name: aldryn_newsblog_article_categories aldryn_newsblog_article_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_categories
    ADD CONSTRAINT aldryn_newsblog_article_categories_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article aldryn_newsblog_article_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article
    ADD CONSTRAINT aldryn_newsblog_article_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article_related aldryn_newsblog_article_related_from_article_id_3a35b706_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_related
    ADD CONSTRAINT aldryn_newsblog_article_related_from_article_id_3a35b706_uniq UNIQUE (from_article_id, to_article_id);


--
-- Name: aldryn_newsblog_article_related aldryn_newsblog_article_related_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_related
    ADD CONSTRAINT aldryn_newsblog_article_related_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_article_translation aldryn_newsblog_article_translation_language_code_914685f3_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_newsblog_article_translation_language_code_914685f3_uniq UNIQUE (language_code, slug);


--
-- Name: aldryn_newsblog_article_translation aldryn_newsblog_article_translation_language_code_a0349fa4_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_newsblog_article_translation_language_code_a0349fa4_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_newsblog_article_translation aldryn_newsblog_article_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_newsblog_article_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_newsblogarchiveplugin aldryn_newsblog_newsblogarchiveplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogarchiveplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogarchiveplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin aldryn_newsblog_newsblogarticlesearchplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogarticlesearchplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogarticlesearchplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogauthorsplugin aldryn_newsblog_newsblogauthorsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogauthorsplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogauthorsplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogcategoriesplugin aldryn_newsblog_newsblogcategoriesplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogcategoriesplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogcategoriesplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogconfig aldryn_newsblog_newsblogconfig_namespace_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldryn_newsblog_newsblogconfig_namespace_key UNIQUE (namespace);


--
-- Name: aldryn_newsblog_newsblogconfig aldryn_newsblog_newsblogconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldryn_newsblog_newsblogconfig_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_newsblogconfig_translation aldryn_newsblog_newsblogconfig_tran_language_code_a6d06161_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig_translation
    ADD CONSTRAINT aldryn_newsblog_newsblogconfig_tran_language_code_a6d06161_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_newsblog_newsblogconfig_translation aldryn_newsblog_newsblogconfig_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig_translation
    ADD CONSTRAINT aldryn_newsblog_newsblogconfig_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin aldryn_newsblog_newsblogfeaturedarticlesplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogfeaturedarticlesplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogfeaturedarticlesplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin aldryn_newsblog_newsbloglatestarticlesplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsbloglatestarticlesplugin
    ADD CONSTRAINT aldryn_newsblog_newsbloglatestarticlesplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogrelatedplugin aldryn_newsblog_newsblogrelatedplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogrelatedplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogrelatedplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_newsblog_newsblogtagsplugin aldryn_newsblog_newsblogtagsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogtagsplugin
    ADD CONSTRAINT aldryn_newsblog_newsblogtagsplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_people_group aldryn_people_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_group
    ADD CONSTRAINT aldryn_people_group_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_group_translation aldryn_people_group_translation_language_code_fafaba2c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_group_translation
    ADD CONSTRAINT aldryn_people_group_translation_language_code_fafaba2c_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_people_group_translation aldryn_people_group_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_group_translation
    ADD CONSTRAINT aldryn_people_group_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_peopleplugin_people aldryn_people_peopleplugin_people_peopleplugin_id_9c48e610_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_peopleplugin_people
    ADD CONSTRAINT aldryn_people_peopleplugin_people_peopleplugin_id_9c48e610_uniq UNIQUE (peopleplugin_id, person_id);


--
-- Name: aldryn_people_peopleplugin_people aldryn_people_peopleplugin_people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_peopleplugin_people
    ADD CONSTRAINT aldryn_people_peopleplugin_people_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_peopleplugin aldryn_people_peopleplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_peopleplugin
    ADD CONSTRAINT aldryn_people_peopleplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: aldryn_people_person_groups aldryn_people_person_groups_person_id_667b1dda_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_groups
    ADD CONSTRAINT aldryn_people_person_groups_person_id_667b1dda_uniq UNIQUE (person_id, group_id);


--
-- Name: aldryn_people_person_groups aldryn_people_person_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_groups
    ADD CONSTRAINT aldryn_people_person_groups_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_person aldryn_people_person_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person
    ADD CONSTRAINT aldryn_people_person_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_person_translation aldryn_people_person_translation_language_code_55cab0f6_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_translation
    ADD CONSTRAINT aldryn_people_person_translation_language_code_55cab0f6_uniq UNIQUE (language_code, master_id);


--
-- Name: aldryn_people_person_translation aldryn_people_person_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_translation
    ADD CONSTRAINT aldryn_people_person_translation_pkey PRIMARY KEY (id);


--
-- Name: aldryn_people_person aldryn_people_person_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person
    ADD CONSTRAINT aldryn_people_person_user_id_key UNIQUE (user_id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: cms_aliaspluginmodel cms_aliaspluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cms_cmsplugin cms_cmsplugin_path_4917bb44_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_path_4917bb44_uniq UNIQUE (path);


--
-- Name: cms_cmsplugin cms_cmsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_pkey PRIMARY KEY (id);


--
-- Name: cms_globalpagepermission_sites cms_globalpagepermission__globalpagepermission_id_db684f41_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission__globalpagepermission_id_db684f41_uniq UNIQUE (globalpagepermission_id, site_id);


--
-- Name: cms_globalpagepermission cms_globalpagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_globalpagepermission_sites cms_globalpagepermission_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission_sites_pkey PRIMARY KEY (id);


--
-- Name: cms_page cms_page_path_d3a06f3d_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_path_d3a06f3d_uniq UNIQUE (path);


--
-- Name: cms_page cms_page_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_pkey PRIMARY KEY (id);


--
-- Name: cms_page_placeholders cms_page_placeholders_page_id_ab7fbfb8_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_page_id_ab7fbfb8_uniq UNIQUE (page_id, placeholder_id);


--
-- Name: cms_page_placeholders cms_page_placeholders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_pkey PRIMARY KEY (id);


--
-- Name: cms_page cms_page_publisher_is_draft_8c776642_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_publisher_is_draft_8c776642_uniq UNIQUE (publisher_is_draft, site_id, application_namespace);


--
-- Name: cms_page cms_page_publisher_public_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_publisher_public_id_key UNIQUE (publisher_public_id);


--
-- Name: cms_page cms_page_reverse_id_d5d1256a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_reverse_id_d5d1256a_uniq UNIQUE (reverse_id, site_id, publisher_is_draft);


--
-- Name: cms_pagepermission cms_pagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_pageuser cms_pageuser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageuser
    ADD CONSTRAINT cms_pageuser_pkey PRIMARY KEY (customuser_ptr_id);


--
-- Name: cms_pageusergroup cms_pageusergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_pkey PRIMARY KEY (group_ptr_id);


--
-- Name: cms_placeholder cms_placeholder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholder
    ADD CONSTRAINT cms_placeholder_pkey PRIMARY KEY (id);


--
-- Name: cms_placeholderreference cms_placeholderreference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholderreference
    ADD CONSTRAINT cms_placeholderreference_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cms_staticplaceholder cms_staticplaceholder_code_21ba079c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_code_21ba079c_uniq UNIQUE (code, site_id);


--
-- Name: cms_staticplaceholder cms_staticplaceholder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_pkey PRIMARY KEY (id);


--
-- Name: cms_title cms_title_language_61aaf084_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_title
    ADD CONSTRAINT cms_title_language_61aaf084_uniq UNIQUE (language, page_id);


--
-- Name: cms_title cms_title_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_title
    ADD CONSTRAINT cms_title_pkey PRIMARY KEY (id);


--
-- Name: cms_title cms_title_publisher_public_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_title
    ADD CONSTRAINT cms_title_publisher_public_id_key UNIQUE (publisher_public_id);


--
-- Name: cms_urlconfrevision cms_urlconfrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_urlconfrevision
    ADD CONSTRAINT cms_urlconfrevision_pkey PRIMARY KEY (id);


--
-- Name: cms_usersettings cms_usersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_pkey PRIMARY KEY (id);


--
-- Name: cms_usersettings cms_usersettings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_user_id_key UNIQUE (user_id);


--
-- Name: cmsplugin_filer_file_filerfile cmsplugin_filer_file_filerfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_file_filerfile
    ADD CONSTRAINT cmsplugin_filer_file_filerfile_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_filer_folder_filerfolder cmsplugin_filer_folder_filerfolder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_folder_filerfolder
    ADD CONSTRAINT cmsplugin_filer_folder_filerfolder_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_filer_image_filerimage cmsplugin_filer_image_filerimage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_filerimage
    ADD CONSTRAINT cmsplugin_filer_image_filerimage_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_filer_image_thumbnailoption cmsplugin_filer_image_thumbnailoption_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_thumbnailoption
    ADD CONSTRAINT cmsplugin_filer_image_thumbnailoption_pkey PRIMARY KEY (id);


--
-- Name: cmsplugin_filer_link_filerlinkplugin cmsplugin_filer_link_filerlinkplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_link_filerlinkplugin
    ADD CONSTRAINT cmsplugin_filer_link_filerlinkplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cmsplugin_filer_video_filervideo cmsplugin_filer_video_filervideo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_video_filervideo
    ADD CONSTRAINT cmsplugin_filer_video_filervideo_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_cmsfaviconextension datacenterlight_cmsfaviconextension_extended_object_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsfaviconextension
    ADD CONSTRAINT datacenterlight_cmsfaviconextension_extended_object_id_key UNIQUE (extended_object_id);


--
-- Name: datacenterlight_cmsfaviconextension datacenterlight_cmsfaviconextension_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsfaviconextension
    ADD CONSTRAINT datacenterlight_cmsfaviconextension_pkey PRIMARY KEY (id);


--
-- Name: datacenterlight_cmsfaviconextension datacenterlight_cmsfaviconextension_public_extension_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsfaviconextension
    ADD CONSTRAINT datacenterlight_cmsfaviconextension_public_extension_id_key UNIQUE (public_extension_id);


--
-- Name: datacenterlight_cmsintegration datacenterlight_cmsintegration_name_5e4f6e5b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsintegration
    ADD CONSTRAINT datacenterlight_cmsintegration_name_5e4f6e5b_uniq UNIQUE (name, domain_id);


--
-- Name: datacenterlight_cmsintegration datacenterlight_cmsintegration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsintegration
    ADD CONSTRAINT datacenterlight_cmsintegration_pkey PRIMARY KEY (id);


--
-- Name: datacenterlight_contactus datacenterlight_contactus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_contactus
    ADD CONSTRAINT datacenterlight_contactus_pkey PRIMARY KEY (id);


--
-- Name: datacenterlight_dclbanneritempluginmodel datacenterlight_dclbanneritempluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclbanneritempluginmodel
    ADD CONSTRAINT datacenterlight_dclbanneritempluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclbannerlistpluginmodel datacenterlight_dclbannerlistpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclbannerlistpluginmodel
    ADD CONSTRAINT datacenterlight_dclbannerlistpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclcontactpluginmodel datacenterlight_dclcontactpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclcontactpluginmodel
    ADD CONSTRAINT datacenterlight_dclcontactpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclcalculatorpluginmodel datacenterlight_dclcustompricingmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclcalculatorpluginmodel
    ADD CONSTRAINT datacenterlight_dclcustompricingmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclfooterpluginmodel datacenterlight_dclfooterpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclfooterpluginmodel
    ADD CONSTRAINT datacenterlight_dclfooterpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dcllinkpluginmodel datacenterlight_dcllinkpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dcllinkpluginmodel
    ADD CONSTRAINT datacenterlight_dcllinkpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclnavbardropdownpluginmodel datacenterlight_dclnavbardropdownpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclnavbardropdownpluginmodel
    ADD CONSTRAINT datacenterlight_dclnavbardropdownpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclnavbarpluginmodel datacenterlight_dclnavbarpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclnavbarpluginmodel
    ADD CONSTRAINT datacenterlight_dclnavbarpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclsectioniconpluginmodel datacenterlight_dclsectioniconpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectioniconpluginmodel
    ADD CONSTRAINT datacenterlight_dclsectioniconpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclsectionimagepluginmodel datacenterlight_dclsectionimagepluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionimagepluginmodel
    ADD CONSTRAINT datacenterlight_dclsectionimagepluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclsectionpluginmodel datacenterlight_dclsectionpluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionpluginmodel
    ADD CONSTRAINT datacenterlight_dclsectionpluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_dclsectionpromopluginmodel datacenterlight_dclsectionpromopluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionpromopluginmodel
    ADD CONSTRAINT datacenterlight_dclsectionpromopluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: datacenterlight_stripeplan datacenterlight_stripeplan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_stripeplan
    ADD CONSTRAINT datacenterlight_stripeplan_pkey PRIMARY KEY (id);


--
-- Name: datacenterlight_vmpricing datacenterlight_vmpricing_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_vmpricing
    ADD CONSTRAINT datacenterlight_vmpricing_name_key UNIQUE (name);


--
-- Name: datacenterlight_vmpricing datacenterlight_vmpricing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_vmpricing
    ADD CONSTRAINT datacenterlight_vmpricing_pkey PRIMARY KEY (id);


--
-- Name: datacenterlight_vmtemplate datacenterlight_vmtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_vmtemplate
    ADD CONSTRAINT datacenterlight_vmtemplate_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_booking digitalglarus_booking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_booking
    ADD CONSTRAINT digitalglarus_booking_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_bookingcancellation digitalglarus_bookingcancellation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingcancellation
    ADD CONSTRAINT digitalglarus_bookingcancellation_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_bookingorder digitalglarus_bookingorder_booking_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingorder
    ADD CONSTRAINT digitalglarus_bookingorder_booking_id_key UNIQUE (booking_id);


--
-- Name: digitalglarus_bookingorder digitalglarus_bookingorder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingorder
    ADD CONSTRAINT digitalglarus_bookingorder_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_bookingprice digitalglarus_bookingprices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingprice
    ADD CONSTRAINT digitalglarus_bookingprices_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_dggallery digitalglarus_dggallery_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dggallery
    ADD CONSTRAINT digitalglarus_dggallery_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_dggalleryplugin digitalglarus_dggalleryplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dggalleryplugin
    ADD CONSTRAINT digitalglarus_dggalleryplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: digitalglarus_dgpicture digitalglarus_dgpicture_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dgpicture
    ADD CONSTRAINT digitalglarus_dgpicture_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_dgsupportersplugin digitalglarus_dgsupportersplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dgsupportersplugin
    ADD CONSTRAINT digitalglarus_dgsupportersplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: digitalglarus_membership digitalglarus_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membership
    ADD CONSTRAINT digitalglarus_membership_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_membershiporder digitalglarus_membershiporder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membershiporder
    ADD CONSTRAINT digitalglarus_membershiporder_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_membershiptype digitalglarus_membershiptype_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membershiptype
    ADD CONSTRAINT digitalglarus_membershiptype_pkey PRIMARY KEY (id);


--
-- Name: digitalglarus_supporter digitalglarus_supporter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_supporter
    ADD CONSTRAINT digitalglarus_supporter_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_celery_results_taskresult django_celery_results_taskresult_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_results_taskresult
    ADD CONSTRAINT django_celery_results_taskresult_pkey PRIMARY KEY (id);


--
-- Name: django_celery_results_taskresult django_celery_results_taskresult_task_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_celery_results_taskresult
    ADD CONSTRAINT django_celery_results_taskresult_task_id_key UNIQUE (task_id);


--
-- Name: django_content_type django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_authorentriesplugin_authors djangocms_blog_authorentri_authorentriesplugin_id_af2d338d_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin_authors
    ADD CONSTRAINT djangocms_blog_authorentri_authorentriesplugin_id_af2d338d_uniq UNIQUE (authorentriesplugin_id, customuser_id);


--
-- Name: djangocms_blog_authorentriesplugin_authors djangocms_blog_authorentriesplugin_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin_authors
    ADD CONSTRAINT djangocms_blog_authorentriesplugin_authors_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_authorentriesplugin djangocms_blog_authorentriesplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin
    ADD CONSTRAINT djangocms_blog_authorentriesplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_blog_blogcategory djangocms_blog_blogcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory
    ADD CONSTRAINT djangocms_blog_blogcategory_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_blogcategory_translation djangocms_blog_blogcategory_transla_language_code_01f38e6e_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory_translation
    ADD CONSTRAINT djangocms_blog_blogcategory_transla_language_code_01f38e6e_uniq UNIQUE (language_code, slug);


--
-- Name: djangocms_blog_blogcategory_translation djangocms_blog_blogcategory_transla_language_code_5d6c122e_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory_translation
    ADD CONSTRAINT djangocms_blog_blogcategory_transla_language_code_5d6c122e_uniq UNIQUE (language_code, master_id);


--
-- Name: djangocms_blog_blogcategory_translation djangocms_blog_blogcategory_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory_translation
    ADD CONSTRAINT djangocms_blog_blogcategory_translation_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_blogconfig djangocms_blog_blogconfig_namespace_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogconfig
    ADD CONSTRAINT djangocms_blog_blogconfig_namespace_key UNIQUE (namespace);


--
-- Name: djangocms_blog_blogconfig djangocms_blog_blogconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogconfig
    ADD CONSTRAINT djangocms_blog_blogconfig_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_blogconfig_translation djangocms_blog_blogconfig_translati_language_code_b9ba0f8e_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogconfig_translation
    ADD CONSTRAINT djangocms_blog_blogconfig_translati_language_code_b9ba0f8e_uniq UNIQUE (language_code, master_id);


--
-- Name: djangocms_blog_blogconfig_translation djangocms_blog_blogconfig_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogconfig_translation
    ADD CONSTRAINT djangocms_blog_blogconfig_translation_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_genericblogplugin djangocms_blog_genericblogplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_genericblogplugin
    ADD CONSTRAINT djangocms_blog_genericblogplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_blog_latestpostsplugin_categories djangocms_blog_latestpostspl_latestpostsplugin_id_5c7dad66_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin_categories
    ADD CONSTRAINT djangocms_blog_latestpostspl_latestpostsplugin_id_5c7dad66_uniq UNIQUE (latestpostsplugin_id, blogcategory_id);


--
-- Name: djangocms_blog_latestpostsplugin_categories djangocms_blog_latestpostsplugin_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin_categories
    ADD CONSTRAINT djangocms_blog_latestpostsplugin_categories_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_latestpostsplugin djangocms_blog_latestpostsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin
    ADD CONSTRAINT djangocms_blog_latestpostsplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_blog_post_categories djangocms_blog_post_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_categories
    ADD CONSTRAINT djangocms_blog_post_categories_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_post_categories djangocms_blog_post_categories_post_id_85ffd9f3_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_categories
    ADD CONSTRAINT djangocms_blog_post_categories_post_id_85ffd9f3_uniq UNIQUE (post_id, blogcategory_id);


--
-- Name: djangocms_blog_post djangocms_blog_post_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT djangocms_blog_post_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_post_related djangocms_blog_post_related_from_post_id_55f7a6be_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_related
    ADD CONSTRAINT djangocms_blog_post_related_from_post_id_55f7a6be_uniq UNIQUE (from_post_id, to_post_id);


--
-- Name: djangocms_blog_post_related djangocms_blog_post_related_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_related
    ADD CONSTRAINT djangocms_blog_post_related_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_post_sites djangocms_blog_post_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_sites
    ADD CONSTRAINT djangocms_blog_post_sites_pkey PRIMARY KEY (id);


--
-- Name: djangocms_blog_post_sites djangocms_blog_post_sites_post_id_ea203167_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_sites
    ADD CONSTRAINT djangocms_blog_post_sites_post_id_ea203167_uniq UNIQUE (post_id, site_id);


--
-- Name: djangocms_blog_post_translation djangocms_blog_post_translation_language_code_39d00571_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_translation
    ADD CONSTRAINT djangocms_blog_post_translation_language_code_39d00571_uniq UNIQUE (language_code, slug);


--
-- Name: djangocms_blog_post_translation djangocms_blog_post_translation_language_code_8d8b75b1_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_translation
    ADD CONSTRAINT djangocms_blog_post_translation_language_code_8d8b75b1_uniq UNIQUE (language_code, master_id);


--
-- Name: djangocms_blog_post_translation djangocms_blog_post_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_translation
    ADD CONSTRAINT djangocms_blog_post_translation_pkey PRIMARY KEY (id);


--
-- Name: djangocms_file_file djangocms_file_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_file
    ADD CONSTRAINT djangocms_file_file_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_page_meta_pagemeta djangocms_page_meta_pagemeta_extended_object_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta
    ADD CONSTRAINT djangocms_page_meta_pagemeta_extended_object_id_key UNIQUE (extended_object_id);


--
-- Name: djangocms_page_meta_pagemeta djangocms_page_meta_pagemeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta
    ADD CONSTRAINT djangocms_page_meta_pagemeta_pkey PRIMARY KEY (id);


--
-- Name: djangocms_page_meta_pagemeta djangocms_page_meta_pagemeta_public_extension_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta
    ADD CONSTRAINT djangocms_page_meta_pagemeta_public_extension_id_key UNIQUE (public_extension_id);


--
-- Name: djangocms_page_meta_titlemeta djangocms_page_meta_titlemeta_extended_object_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_titlemeta
    ADD CONSTRAINT djangocms_page_meta_titlemeta_extended_object_id_key UNIQUE (extended_object_id);


--
-- Name: djangocms_page_meta_titlemeta djangocms_page_meta_titlemeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_titlemeta
    ADD CONSTRAINT djangocms_page_meta_titlemeta_pkey PRIMARY KEY (id);


--
-- Name: djangocms_page_meta_titlemeta djangocms_page_meta_titlemeta_public_extension_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_titlemeta
    ADD CONSTRAINT djangocms_page_meta_titlemeta_public_extension_id_key UNIQUE (public_extension_id);


--
-- Name: djangocms_picture_picture djangocms_picture_picture_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_picture_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_text_ckeditor_text djangocms_text_ckeditor_text_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_text_ckeditor_text
    ADD CONSTRAINT djangocms_text_ckeditor_text_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_video_video djangocms_video_video_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_video
    ADD CONSTRAINT djangocms_video_video_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_storage_hash_481ce32d_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_storage_hash_481ce32d_uniq UNIQUE (storage_hash, name);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnail_storage_hash_fb375270_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_storage_hash_fb375270_uniq UNIQUE (storage_hash, name, source_id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: filer_clipboard filer_clipboard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboard
    ADD CONSTRAINT filer_clipboard_pkey PRIMARY KEY (id);


--
-- Name: filer_clipboarditem filer_clipboarditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_pkey PRIMARY KEY (id);


--
-- Name: filer_file filer_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_file_pkey PRIMARY KEY (id);


--
-- Name: filer_folder filer_folder_parent_id_bc773258_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_parent_id_bc773258_uniq UNIQUE (parent_id, name);


--
-- Name: filer_folder filer_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_pkey PRIMARY KEY (id);


--
-- Name: filer_folderpermission filer_folderpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_pkey PRIMARY KEY (id);


--
-- Name: filer_image filer_image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_image
    ADD CONSTRAINT filer_image_pkey PRIMARY KEY (file_ptr_id);


--
-- Name: filer_thumbnailoption filer_thumbnailoption_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_thumbnailoption
    ADD CONSTRAINT filer_thumbnailoption_pkey PRIMARY KEY (id);


--
-- Name: guardian_groupobjectpermission guardian_groupobjectpermission_group_id_3f189f7c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_groupobjectpermission
    ADD CONSTRAINT guardian_groupobjectpermission_group_id_3f189f7c_uniq UNIQUE (group_id, permission_id, object_pk);


--
-- Name: guardian_groupobjectpermission guardian_groupobjectpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_groupobjectpermission
    ADD CONSTRAINT guardian_groupobjectpermission_pkey PRIMARY KEY (id);


--
-- Name: guardian_userobjectpermission guardian_userobjectpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_userobjectpermission
    ADD CONSTRAINT guardian_userobjectpermission_pkey PRIMARY KEY (id);


--
-- Name: guardian_userobjectpermission guardian_userobjectpermission_user_id_b0b3d2fc_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_userobjectpermission
    ADD CONSTRAINT guardian_userobjectpermission_user_id_b0b3d2fc_uniq UNIQUE (user_id, permission_id, object_pk);


--
-- Name: hosting_genericproduct hosting_genericproduct_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_genericproduct
    ADD CONSTRAINT hosting_genericproduct_pkey PRIMARY KEY (id);


--
-- Name: hosting_genericproduct hosting_genericproduct_product_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_genericproduct
    ADD CONSTRAINT hosting_genericproduct_product_slug_key UNIQUE (product_slug);


--
-- Name: hosting_hostingbill hosting_hostingbill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbill
    ADD CONSTRAINT hosting_hostingbill_pkey PRIMARY KEY (id);


--
-- Name: hosting_hostingbilllineitem hosting_hostingbilllineitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbilllineitem
    ADD CONSTRAINT hosting_hostingbilllineitem_pkey PRIMARY KEY (id);


--
-- Name: hosting_hostingorder hosting_hostingorder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingorder
    ADD CONSTRAINT hosting_hostingorder_pkey PRIMARY KEY (id);


--
-- Name: hosting_hostingplan hosting_hostingplan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingplan
    ADD CONSTRAINT hosting_hostingplan_pkey PRIMARY KEY (id);


--
-- Name: hosting_incompletepaymentintents hosting_incompletepaymentintents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_incompletepaymentintents
    ADD CONSTRAINT hosting_incompletepaymentintents_pkey PRIMARY KEY (id);


--
-- Name: hosting_incompletesubscriptions hosting_incompletesubscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_incompletesubscriptions
    ADD CONSTRAINT hosting_incompletesubscriptions_pkey PRIMARY KEY (id);


--
-- Name: hosting_monthlyhostingbill hosting_monthlyhostingbill_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_monthlyhostingbill
    ADD CONSTRAINT hosting_monthlyhostingbill_invoice_id_key UNIQUE (invoice_id);


--
-- Name: hosting_monthlyhostingbill hosting_monthlyhostingbill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_monthlyhostingbill
    ADD CONSTRAINT hosting_monthlyhostingbill_pkey PRIMARY KEY (id);


--
-- Name: hosting_orderdetail hosting_orderdetail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_orderdetail
    ADD CONSTRAINT hosting_orderdetail_pkey PRIMARY KEY (id);


--
-- Name: hosting_stripetaxrate hosting_stripetaxrate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_stripetaxrate
    ADD CONSTRAINT hosting_stripetaxrate_pkey PRIMARY KEY (id);


--
-- Name: hosting_stripetaxrate hosting_stripetaxrate_tax_rate_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_stripetaxrate
    ADD CONSTRAINT hosting_stripetaxrate_tax_rate_id_key UNIQUE (tax_rate_id);


--
-- Name: hosting_usercarddetail hosting_usercarddetail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_usercarddetail
    ADD CONSTRAINT hosting_usercarddetail_pkey PRIMARY KEY (id);


--
-- Name: hosting_userhostingkey hosting_userhostingkey_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_userhostingkey
    ADD CONSTRAINT hosting_userhostingkey_pkey PRIMARY KEY (id);


--
-- Name: hosting_vatrates hosting_vatrates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_vatrates
    ADD CONSTRAINT hosting_vatrates_pkey PRIMARY KEY (id);


--
-- Name: hosting_vmdetail hosting_vmdetail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_vmdetail
    ADD CONSTRAINT hosting_vmdetail_pkey PRIMARY KEY (id);


--
-- Name: membership_calendar membership_calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_calendar
    ADD CONSTRAINT membership_calendar_pkey PRIMARY KEY (id);


--
-- Name: membership_creditcards membership_creditcards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_creditcards
    ADD CONSTRAINT membership_creditcards_pkey PRIMARY KEY (id);


--
-- Name: membership_customuser membership_customuser_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser
    ADD CONSTRAINT membership_customuser_email_key UNIQUE (email);


--
-- Name: membership_customuser_groups membership_customuser_groups_customuser_id_e079d2cd_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_groups
    ADD CONSTRAINT membership_customuser_groups_customuser_id_e079d2cd_uniq UNIQUE (customuser_id, group_id);


--
-- Name: membership_customuser_groups membership_customuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_groups
    ADD CONSTRAINT membership_customuser_groups_pkey PRIMARY KEY (id);


--
-- Name: membership_customuser membership_customuser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser
    ADD CONSTRAINT membership_customuser_pkey PRIMARY KEY (id);


--
-- Name: membership_customuser_user_permissions membership_customuser_user_permissi_customuser_id_de7594d9_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_user_permissions
    ADD CONSTRAINT membership_customuser_user_permissi_customuser_id_de7594d9_uniq UNIQUE (customuser_id, permission_id);


--
-- Name: membership_customuser_user_permissions membership_customuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_user_permissions
    ADD CONSTRAINT membership_customuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: membership_customuser membership_customuser_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser
    ADD CONSTRAINT membership_customuser_username_key UNIQUE (username);


--
-- Name: membership_customuser membership_customuser_validation_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser
    ADD CONSTRAINT membership_customuser_validation_slug_key UNIQUE (validation_slug);


--
-- Name: membership_deleteduser membership_deleteduser_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_deleteduser
    ADD CONSTRAINT membership_deleteduser_email_key UNIQUE (email);


--
-- Name: membership_deleteduser membership_deleteduser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_deleteduser
    ADD CONSTRAINT membership_deleteduser_pkey PRIMARY KEY (id);


--
-- Name: membership_stripecustomer membership_stripecustomer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_stripecustomer
    ADD CONSTRAINT membership_stripecustomer_pkey PRIMARY KEY (id);


--
-- Name: membership_stripecustomer membership_stripecustomer_stripe_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_stripecustomer
    ADD CONSTRAINT membership_stripecustomer_stripe_id_key UNIQUE (stripe_id);


--
-- Name: membership_stripecustomer membership_stripecustomer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_stripecustomer
    ADD CONSTRAINT membership_stripecustomer_user_id_key UNIQUE (user_id);


--
-- Name: menus_cachekey menus_cachekey_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_cachekey
    ADD CONSTRAINT menus_cachekey_pkey PRIMARY KEY (id);


--
-- Name: multisite_alias multisite_alias_domain_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.multisite_alias
    ADD CONSTRAINT multisite_alias_domain_key UNIQUE (domain);


--
-- Name: multisite_alias multisite_alias_is_canonical_6bc86489_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.multisite_alias
    ADD CONSTRAINT multisite_alias_is_canonical_6bc86489_uniq UNIQUE (is_canonical, site_id);


--
-- Name: multisite_alias multisite_alias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.multisite_alias
    ADD CONSTRAINT multisite_alias_pkey PRIMARY KEY (id);


--
-- Name: nosystemd_donation nosystemd_donation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donation
    ADD CONSTRAINT nosystemd_donation_pkey PRIMARY KEY (id);


--
-- Name: nosystemd_donatorstatus nosystemd_donatorstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donatorstatus
    ADD CONSTRAINT nosystemd_donatorstatus_pkey PRIMARY KEY (id);


--
-- Name: nosystemd_donatorstatus nosystemd_donatorstatus_user_id_faa76894_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donatorstatus
    ADD CONSTRAINT nosystemd_donatorstatus_user_id_faa76894_uniq UNIQUE (user_id);


--
-- Name: reversion_revision reversion_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reversion_revision
    ADD CONSTRAINT reversion_revision_pkey PRIMARY KEY (id);


--
-- Name: reversion_version reversion_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reversion_version
    ADD CONSTRAINT reversion_version_pkey PRIMARY KEY (id);


--
-- Name: stored_messages_inbox stored_messages_inbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_inbox
    ADD CONSTRAINT stored_messages_inbox_pkey PRIMARY KEY (id);


--
-- Name: stored_messages_message stored_messages_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_message
    ADD CONSTRAINT stored_messages_message_pkey PRIMARY KEY (id);


--
-- Name: stored_messages_messagearchive stored_messages_messagearchive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_messagearchive
    ADD CONSTRAINT stored_messages_messagearchive_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag taggit_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_name_key UNIQUE (name);


--
-- Name: taggit_tag taggit_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag taggit_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_slug_key UNIQUE (slug);


--
-- Name: taggit_taggeditem taggit_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: ungleich_page_about ungleich_page_about_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_about
    ADD CONSTRAINT ungleich_page_about_pkey PRIMARY KEY (service_ptr_id);


--
-- Name: ungleich_page_aboutitem ungleich_page_aboutitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_aboutitem
    ADD CONSTRAINT ungleich_page_aboutitem_pkey PRIMARY KEY (ungelichpicture_ptr_id);


--
-- Name: ungleich_page_sectionwithimage ungleich_page_sectionwithimage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_sectionwithimage
    ADD CONSTRAINT ungleich_page_sectionwithimage_pkey PRIMARY KEY (ungelichpicture_ptr_id);


--
-- Name: ungleich_page_service ungleich_page_service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_service
    ADD CONSTRAINT ungleich_page_service_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_serviceitem ungleich_page_serviceitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_serviceitem
    ADD CONSTRAINT ungleich_page_serviceitem_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungelichcontactussection ungleich_page_ungelichcontactussection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungelichcontactussection
    ADD CONSTRAINT ungleich_page_ungelichcontactussection_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungelichpicture ungleich_page_ungelichpicture_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungelichpicture
    ADD CONSTRAINT ungleich_page_ungelichpicture_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungelichtextsection ungleich_page_ungelichtextsection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungelichtextsection
    ADD CONSTRAINT ungleich_page_ungelichtextsection_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungleichcustomer ungleich_page_ungleichcustomer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichcustomer
    ADD CONSTRAINT ungleich_page_ungleichcustomer_pkey PRIMARY KEY (service_ptr_id);


--
-- Name: ungleich_page_ungleichcustomeritem ungleich_page_ungleichcustomeritem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichcustomeritem
    ADD CONSTRAINT ungleich_page_ungleichcustomeritem_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungleichfooter ungleich_page_ungleichfooter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichfooter
    ADD CONSTRAINT ungleich_page_ungleichfooter_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungleichheaderwithbackgroundimageslider ungleich_page_ungleichheaderwithbackgroundimageslider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichheaderwithbackgroundimageslider
    ADD CONSTRAINT ungleich_page_ungleichheaderwithbackgroundimageslider_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem ungleich_page_ungleichheaderwithbackgroundvideoslideritem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem
    ADD CONSTRAINT ungleich_page_ungleichheaderwithbackgroundvideoslideritem_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungleichhtmlonly ungleich_page_ungleichhtmlonly_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichhtmlonly
    ADD CONSTRAINT ungleich_page_ungleichhtmlonly_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: ungleich_page_ungleichproduct ungleich_page_ungleichproduct_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichproduct
    ADD CONSTRAINT ungleich_page_ungleichproduct_pkey PRIMARY KEY (service_ptr_id);


--
-- Name: ungleich_page_ungleichproductitem ungleich_page_ungleichproductitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichproductitem
    ADD CONSTRAINT ungleich_page_ungleichproductitem_pkey PRIMARY KEY (serviceitem_ptr_id);


--
-- Name: ungleich_page_ungleichserviceitem ungleich_page_ungleichserviceitem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichserviceitem
    ADD CONSTRAINT ungleich_page_ungleichserviceitem_pkey PRIMARY KEY (serviceitem_ptr_id);


--
-- Name: ungleich_ungleichpage ungleich_ungleichpage_extended_object_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_ungleichpage
    ADD CONSTRAINT ungleich_ungleichpage_extended_object_id_key UNIQUE (extended_object_id);


--
-- Name: ungleich_ungleichpage ungleich_ungleichpage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_ungleichpage
    ADD CONSTRAINT ungleich_ungleichpage_pkey PRIMARY KEY (id);


--
-- Name: ungleich_ungleichpage ungleich_ungleichpage_public_extension_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_ungleichpage
    ADD CONSTRAINT ungleich_ungleichpage_public_extension_id_key UNIQUE (public_extension_id);


--
-- Name: utils_billingaddress utils_billingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utils_billingaddress
    ADD CONSTRAINT utils_billingaddress_pkey PRIMARY KEY (id);


--
-- Name: utils_contactmessage utils_contactmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utils_contactmessage
    ADD CONSTRAINT utils_contactmessage_pkey PRIMARY KEY (id);


--
-- Name: utils_userbillingaddress utils_userbillingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utils_userbillingaddress
    ADD CONSTRAINT utils_userbillingaddress_pkey PRIMARY KEY (id);


--
-- Name: aldryn_categories_category_0d000fbb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_0d000fbb ON public.aldryn_categories_category USING btree (rgt);


--
-- Name: aldryn_categories_category_12a055bf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_12a055bf ON public.aldryn_categories_category USING btree (depth);


--
-- Name: aldryn_categories_category_656442a0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_656442a0 ON public.aldryn_categories_category USING btree (tree_id);


--
-- Name: aldryn_categories_category_caf7cc51; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_caf7cc51 ON public.aldryn_categories_category USING btree (lft);


--
-- Name: aldryn_categories_category_translat_language_code_95324fde_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_translat_language_code_95324fde_like ON public.aldryn_categories_category_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_categories_category_translation_2dbcba41; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_translation_2dbcba41 ON public.aldryn_categories_category_translation USING btree (slug);


--
-- Name: aldryn_categories_category_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_translation_60716c2f ON public.aldryn_categories_category_translation USING btree (language_code);


--
-- Name: aldryn_categories_category_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_translation_90349b61 ON public.aldryn_categories_category_translation USING btree (master_id);


--
-- Name: aldryn_categories_category_translation_slug_a8fa2ddf_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_categories_category_translation_slug_a8fa2ddf_like ON public.aldryn_categories_category_translation USING btree (slug varchar_pattern_ops);


--
-- Name: aldryn_newsblog_article_39b2604d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_39b2604d ON public.aldryn_newsblog_article USING btree (is_featured);


--
-- Name: aldryn_newsblog_article_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_40e85b1f ON public.aldryn_newsblog_article USING btree (app_config_id);


--
-- Name: aldryn_newsblog_article_4f331e2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_4f331e2f ON public.aldryn_newsblog_article USING btree (author_id);


--
-- Name: aldryn_newsblog_article_5e7b1936; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_5e7b1936 ON public.aldryn_newsblog_article USING btree (owner_id);


--
-- Name: aldryn_newsblog_article_75892900; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_75892900 ON public.aldryn_newsblog_article USING btree (is_published);


--
-- Name: aldryn_newsblog_article_categories_a00c1b00; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_categories_a00c1b00 ON public.aldryn_newsblog_article_categories USING btree (article_id);


--
-- Name: aldryn_newsblog_article_categories_b583a629; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_categories_b583a629 ON public.aldryn_newsblog_article_categories USING btree (category_id);


--
-- Name: aldryn_newsblog_article_cdbc3e64; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_cdbc3e64 ON public.aldryn_newsblog_article USING btree (featured_image_id);


--
-- Name: aldryn_newsblog_article_e14f02ad; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_e14f02ad ON public.aldryn_newsblog_article USING btree (content_id);


--
-- Name: aldryn_newsblog_article_related_58b6ddc3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_related_58b6ddc3 ON public.aldryn_newsblog_article_related USING btree (to_article_id);


--
-- Name: aldryn_newsblog_article_related_be73af96; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_related_be73af96 ON public.aldryn_newsblog_article_related USING btree (from_article_id);


--
-- Name: aldryn_newsblog_article_translation_2dbcba41; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_translation_2dbcba41 ON public.aldryn_newsblog_article_translation USING btree (slug);


--
-- Name: aldryn_newsblog_article_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_translation_60716c2f ON public.aldryn_newsblog_article_translation USING btree (language_code);


--
-- Name: aldryn_newsblog_article_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_translation_90349b61 ON public.aldryn_newsblog_article_translation USING btree (master_id);


--
-- Name: aldryn_newsblog_article_translation_language_code_a6c57a68_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_translation_language_code_a6c57a68_like ON public.aldryn_newsblog_article_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_newsblog_article_translation_slug_e7c9f2e4_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_article_translation_slug_e7c9f2e4_like ON public.aldryn_newsblog_article_translation USING btree (slug varchar_pattern_ops);


--
-- Name: aldryn_newsblog_newsblogarchiveplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogarchiveplugin_40e85b1f ON public.aldryn_newsblog_newsblogarchiveplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogarticlesearchplugin_40e85b1f ON public.aldryn_newsblog_newsblogarticlesearchplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogauthorsplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogauthorsplugin_40e85b1f ON public.aldryn_newsblog_newsblogauthorsplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogcategoriesplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogcategoriesplugin_40e85b1f ON public.aldryn_newsblog_newsblogcategoriesplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogconfig_55561819; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_55561819 ON public.aldryn_newsblog_newsblogconfig USING btree (placeholder_base_top_id);


--
-- Name: aldryn_newsblog_newsblogconfig_5918df56; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_5918df56 ON public.aldryn_newsblog_newsblogconfig USING btree (placeholder_detail_footer_id);


--
-- Name: aldryn_newsblog_newsblogconfig_7c049d9f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_7c049d9f ON public.aldryn_newsblog_newsblogconfig USING btree (placeholder_base_sidebar_id);


--
-- Name: aldryn_newsblog_newsblogconfig_8806551e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_8806551e ON public.aldryn_newsblog_newsblogconfig USING btree (placeholder_list_footer_id);


--
-- Name: aldryn_newsblog_newsblogconfig_90b0156f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_90b0156f ON public.aldryn_newsblog_newsblogconfig USING btree (placeholder_detail_top_id);


--
-- Name: aldryn_newsblog_newsblogconfig_ba2f8115; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_ba2f8115 ON public.aldryn_newsblog_newsblogconfig USING btree (placeholder_list_top_id);


--
-- Name: aldryn_newsblog_newsblogconfig_e2d1ed82; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_e2d1ed82 ON public.aldryn_newsblog_newsblogconfig USING btree (placeholder_detail_bottom_id);


--
-- Name: aldryn_newsblog_newsblogconfig_namespace_8e9500a5_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_namespace_8e9500a5_like ON public.aldryn_newsblog_newsblogconfig USING btree (namespace varchar_pattern_ops);


--
-- Name: aldryn_newsblog_newsblogconfig_tran_language_code_abb2daa0_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_tran_language_code_abb2daa0_like ON public.aldryn_newsblog_newsblogconfig_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_newsblog_newsblogconfig_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_translation_60716c2f ON public.aldryn_newsblog_newsblogconfig_translation USING btree (language_code);


--
-- Name: aldryn_newsblog_newsblogconfig_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogconfig_translation_90349b61 ON public.aldryn_newsblog_newsblogconfig_translation USING btree (master_id);


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogfeaturedarticlesplugin_40e85b1f ON public.aldryn_newsblog_newsblogfeaturedarticlesplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsbloglatestarticlesplugin_40e85b1f ON public.aldryn_newsblog_newsbloglatestarticlesplugin USING btree (app_config_id);


--
-- Name: aldryn_newsblog_newsblogtagsplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_newsblog_newsblogtagsplugin_40e85b1f ON public.aldryn_newsblog_newsblogtagsplugin USING btree (app_config_id);


--
-- Name: aldryn_people_group_translation_2dbcba41; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_group_translation_2dbcba41 ON public.aldryn_people_group_translation USING btree (slug);


--
-- Name: aldryn_people_group_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_group_translation_60716c2f ON public.aldryn_people_group_translation USING btree (language_code);


--
-- Name: aldryn_people_group_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_group_translation_90349b61 ON public.aldryn_people_group_translation USING btree (master_id);


--
-- Name: aldryn_people_group_translation_language_code_d40f3f14_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_group_translation_language_code_d40f3f14_like ON public.aldryn_people_group_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: aldryn_people_peopleplugin_people_7d22caae; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_peopleplugin_people_7d22caae ON public.aldryn_people_peopleplugin_people USING btree (peopleplugin_id);


--
-- Name: aldryn_people_peopleplugin_people_a8452ca7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_peopleplugin_people_a8452ca7 ON public.aldryn_people_peopleplugin_people USING btree (person_id);


--
-- Name: aldryn_people_person_6e0547d0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_person_6e0547d0 ON public.aldryn_people_person USING btree (visual_id);


--
-- Name: aldryn_people_person_groups_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_person_groups_0e939a4f ON public.aldryn_people_person_groups USING btree (group_id);


--
-- Name: aldryn_people_person_groups_a8452ca7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_person_groups_a8452ca7 ON public.aldryn_people_person_groups USING btree (person_id);


--
-- Name: aldryn_people_person_translation_2dbcba41; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_person_translation_2dbcba41 ON public.aldryn_people_person_translation USING btree (slug);


--
-- Name: aldryn_people_person_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_person_translation_60716c2f ON public.aldryn_people_person_translation USING btree (language_code);


--
-- Name: aldryn_people_person_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_person_translation_90349b61 ON public.aldryn_people_person_translation USING btree (master_id);


--
-- Name: aldryn_people_person_translation_language_code_db5e4538_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX aldryn_people_person_translation_language_code_db5e4538_like ON public.aldryn_people_person_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_0e939a4f ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_8373b171 ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_417f1b1c ON public.auth_permission USING btree (content_type_id);


--
-- Name: cms_aliaspluginmodel_921abf5c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_aliaspluginmodel_921abf5c ON public.cms_aliaspluginmodel USING btree (alias_placeholder_id);


--
-- Name: cms_aliaspluginmodel_b25eaab4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_aliaspluginmodel_b25eaab4 ON public.cms_aliaspluginmodel USING btree (plugin_id);


--
-- Name: cms_cmsplugin_667a6151; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_667a6151 ON public.cms_cmsplugin USING btree (placeholder_id);


--
-- Name: cms_cmsplugin_6be37982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_6be37982 ON public.cms_cmsplugin USING btree (parent_id);


--
-- Name: cms_cmsplugin_8512ae7d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_8512ae7d ON public.cms_cmsplugin USING btree (language);


--
-- Name: cms_cmsplugin_b5e4cf8f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_b5e4cf8f ON public.cms_cmsplugin USING btree (plugin_type);


--
-- Name: cms_cmsplugin_language_bbea8a48_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_language_bbea8a48_like ON public.cms_cmsplugin USING btree (language varchar_pattern_ops);


--
-- Name: cms_cmsplugin_path_4917bb44_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_path_4917bb44_like ON public.cms_cmsplugin USING btree (path varchar_pattern_ops);


--
-- Name: cms_cmsplugin_plugin_type_94e96ebf_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_plugin_type_94e96ebf_like ON public.cms_cmsplugin USING btree (plugin_type varchar_pattern_ops);


--
-- Name: cms_globalpagepermission_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_0e939a4f ON public.cms_globalpagepermission USING btree (group_id);


--
-- Name: cms_globalpagepermission_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_e8701ad4 ON public.cms_globalpagepermission USING btree (user_id);


--
-- Name: cms_globalpagepermission_sites_9365d6e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_sites_9365d6e7 ON public.cms_globalpagepermission_sites USING btree (site_id);


--
-- Name: cms_globalpagepermission_sites_a3d12ecd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_sites_a3d12ecd ON public.cms_globalpagepermission_sites USING btree (globalpagepermission_id);


--
-- Name: cms_page_1d85575d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_1d85575d ON public.cms_page USING btree (soft_root);


--
-- Name: cms_page_2247c5f0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_2247c5f0 ON public.cms_page USING btree (publication_end_date);


--
-- Name: cms_page_3d9ef52f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_3d9ef52f ON public.cms_page USING btree (reverse_id);


--
-- Name: cms_page_4fa1c803; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_4fa1c803 ON public.cms_page USING btree (is_home);


--
-- Name: cms_page_6be37982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_6be37982 ON public.cms_page USING btree (parent_id);


--
-- Name: cms_page_7b8acfa6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_7b8acfa6 ON public.cms_page USING btree (navigation_extenders);


--
-- Name: cms_page_9365d6e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_9365d6e7 ON public.cms_page USING btree (site_id);


--
-- Name: cms_page_93b83098; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_93b83098 ON public.cms_page USING btree (publication_date);


--
-- Name: cms_page_application_urls_9ef47497_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_application_urls_9ef47497_like ON public.cms_page USING btree (application_urls varchar_pattern_ops);


--
-- Name: cms_page_b7700099; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_b7700099 ON public.cms_page USING btree (publisher_is_draft);


--
-- Name: cms_page_cb540373; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_cb540373 ON public.cms_page USING btree (limit_visibility_in_menu);


--
-- Name: cms_page_db3eb53f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_db3eb53f ON public.cms_page USING btree (in_navigation);


--
-- Name: cms_page_e721871e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_e721871e ON public.cms_page USING btree (application_urls);


--
-- Name: cms_page_navigation_extenders_c24af8dd_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_navigation_extenders_c24af8dd_like ON public.cms_page USING btree (navigation_extenders varchar_pattern_ops);


--
-- Name: cms_page_path_d3a06f3d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_path_d3a06f3d_like ON public.cms_page USING btree (path varchar_pattern_ops);


--
-- Name: cms_page_placeholders_1a63c800; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_placeholders_1a63c800 ON public.cms_page_placeholders USING btree (page_id);


--
-- Name: cms_page_placeholders_667a6151; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_placeholders_667a6151 ON public.cms_page_placeholders USING btree (placeholder_id);


--
-- Name: cms_page_reverse_id_ffc9ede2_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_reverse_id_ffc9ede2_like ON public.cms_page USING btree (reverse_id varchar_pattern_ops);


--
-- Name: cms_pagepermission_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pagepermission_0e939a4f ON public.cms_pagepermission USING btree (group_id);


--
-- Name: cms_pagepermission_1a63c800; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pagepermission_1a63c800 ON public.cms_pagepermission USING btree (page_id);


--
-- Name: cms_pagepermission_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pagepermission_e8701ad4 ON public.cms_pagepermission USING btree (user_id);


--
-- Name: cms_pageuser_e93cb7eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageuser_e93cb7eb ON public.cms_pageuser USING btree (created_by_id);


--
-- Name: cms_pageusergroup_e93cb7eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageusergroup_e93cb7eb ON public.cms_pageusergroup USING btree (created_by_id);


--
-- Name: cms_placeholder_5e97994e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_placeholder_5e97994e ON public.cms_placeholder USING btree (slot);


--
-- Name: cms_placeholder_slot_0bc04d21_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_placeholder_slot_0bc04d21_like ON public.cms_placeholder USING btree (slot varchar_pattern_ops);


--
-- Name: cms_placeholderreference_328d0afc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_placeholderreference_328d0afc ON public.cms_placeholderreference USING btree (placeholder_ref_id);


--
-- Name: cms_staticplaceholder_1ee2744d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_staticplaceholder_1ee2744d ON public.cms_staticplaceholder USING btree (public_id);


--
-- Name: cms_staticplaceholder_5cb48773; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_staticplaceholder_5cb48773 ON public.cms_staticplaceholder USING btree (draft_id);


--
-- Name: cms_staticplaceholder_9365d6e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_staticplaceholder_9365d6e7 ON public.cms_staticplaceholder USING btree (site_id);


--
-- Name: cms_title_1268de9a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_1268de9a ON public.cms_title USING btree (has_url_overwrite);


--
-- Name: cms_title_1a63c800; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_1a63c800 ON public.cms_title USING btree (page_id);


--
-- Name: cms_title_2dbcba41; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_2dbcba41 ON public.cms_title USING btree (slug);


--
-- Name: cms_title_8512ae7d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_8512ae7d ON public.cms_title USING btree (language);


--
-- Name: cms_title_b7700099; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_b7700099 ON public.cms_title USING btree (publisher_is_draft);


--
-- Name: cms_title_d6fe1d0b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_d6fe1d0b ON public.cms_title USING btree (path);


--
-- Name: cms_title_f7202fc0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_f7202fc0 ON public.cms_title USING btree (publisher_state);


--
-- Name: cms_title_language_50a0dfa1_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_language_50a0dfa1_like ON public.cms_title USING btree (language varchar_pattern_ops);


--
-- Name: cms_title_path_c484314c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_path_c484314c_like ON public.cms_title USING btree (path varchar_pattern_ops);


--
-- Name: cms_title_slug_4947d146_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_slug_4947d146_like ON public.cms_title USING btree (slug varchar_pattern_ops);


--
-- Name: cms_usersettings_2655b062; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_usersettings_2655b062 ON public.cms_usersettings USING btree (clipboard_id);


--
-- Name: cmsplugin_filer_file_filerfile_814552b9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_file_filerfile_814552b9 ON public.cmsplugin_filer_file_filerfile USING btree (file_id);


--
-- Name: cmsplugin_filer_folder_filerfolder_a8a44dbb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_folder_filerfolder_a8a44dbb ON public.cmsplugin_filer_folder_filerfolder USING btree (folder_id);


--
-- Name: cmsplugin_filer_image_filerimage_0fe0fc57; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_image_filerimage_0fe0fc57 ON public.cmsplugin_filer_image_filerimage USING btree (file_link_id);


--
-- Name: cmsplugin_filer_image_filerimage_6b85b7b1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_image_filerimage_6b85b7b1 ON public.cmsplugin_filer_image_filerimage USING btree (thumbnail_option_id);


--
-- Name: cmsplugin_filer_image_filerimage_d916d256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_image_filerimage_d916d256 ON public.cmsplugin_filer_image_filerimage USING btree (page_link_id);


--
-- Name: cmsplugin_filer_image_filerimage_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_image_filerimage_f33175e6 ON public.cmsplugin_filer_image_filerimage USING btree (image_id);


--
-- Name: cmsplugin_filer_link_filerlinkplugin_814552b9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_link_filerlinkplugin_814552b9 ON public.cmsplugin_filer_link_filerlinkplugin USING btree (file_id);


--
-- Name: cmsplugin_filer_link_filerlinkplugin_d916d256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_link_filerlinkplugin_d916d256 ON public.cmsplugin_filer_link_filerlinkplugin USING btree (page_link_id);


--
-- Name: cmsplugin_filer_video_filervideo_d1b173c8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_video_filervideo_d1b173c8 ON public.cmsplugin_filer_video_filervideo USING btree (movie_id);


--
-- Name: cmsplugin_filer_video_filervideo_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cmsplugin_filer_video_filervideo_f33175e6 ON public.cmsplugin_filer_video_filervideo USING btree (image_id);


--
-- Name: datacenterlight_cmsfaviconextension_1b3bedae; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_cmsfaviconextension_1b3bedae ON public.datacenterlight_cmsfaviconextension USING btree (favicon_id);


--
-- Name: datacenterlight_cmsintegration_0eb96ada; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_cmsintegration_0eb96ada ON public.datacenterlight_cmsintegration USING btree (footer_placeholder_id);


--
-- Name: datacenterlight_cmsintegration_4a335b93; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_cmsintegration_4a335b93 ON public.datacenterlight_cmsintegration USING btree (navbar_placeholder_id);


--
-- Name: datacenterlight_cmsintegration_662cbf12; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_cmsintegration_662cbf12 ON public.datacenterlight_cmsintegration USING btree (domain_id);


--
-- Name: datacenterlight_cmsintegration_ad821e0e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_cmsintegration_ad821e0e ON public.datacenterlight_cmsintegration USING btree (calculator_placeholder_id);


--
-- Name: datacenterlight_dclbanneritempluginmodel_b85cdbc5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclbanneritempluginmodel_b85cdbc5 ON public.datacenterlight_dclbanneritempluginmodel USING btree (banner_image_id);


--
-- Name: datacenterlight_dclbannerlistpluginmodel_aee1fcf8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclbannerlistpluginmodel_aee1fcf8 ON public.datacenterlight_dclbannerlistpluginmodel USING btree (html_id);


--
-- Name: datacenterlight_dclbannerlistpluginmodel_html_id_c099e9f2_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclbannerlistpluginmodel_html_id_c099e9f2_like ON public.datacenterlight_dclbannerlistpluginmodel USING btree (html_id varchar_pattern_ops);


--
-- Name: datacenterlight_dclcustompricingmodel_a3bda3b9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclcustompricingmodel_a3bda3b9 ON public.datacenterlight_dclcalculatorpluginmodel USING btree (pricing_id);


--
-- Name: datacenterlight_dclnavbarpluginmodel_33ef20d3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclnavbarpluginmodel_33ef20d3 ON public.datacenterlight_dclnavbarpluginmodel USING btree (logo_light_id);


--
-- Name: datacenterlight_dclnavbarpluginmodel_69bd8762; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclnavbarpluginmodel_69bd8762 ON public.datacenterlight_dclnavbarpluginmodel USING btree (logo_dark_id);


--
-- Name: datacenterlight_dclsectionimagepluginmodel_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclsectionimagepluginmodel_f33175e6 ON public.datacenterlight_dclsectionimagepluginmodel USING btree (image_id);


--
-- Name: datacenterlight_dclsectionpluginmodel_aee1fcf8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclsectionpluginmodel_aee1fcf8 ON public.datacenterlight_dclsectionpluginmodel USING btree (html_id);


--
-- Name: datacenterlight_dclsectionpluginmodel_html_id_96c1aadd_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclsectionpluginmodel_html_id_96c1aadd_like ON public.datacenterlight_dclsectionpluginmodel USING btree (html_id varchar_pattern_ops);


--
-- Name: datacenterlight_dclsectionpromopluginmode_html_id_03b2579d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclsectionpromopluginmode_html_id_03b2579d_like ON public.datacenterlight_dclsectionpromopluginmodel USING btree (html_id varchar_pattern_ops);


--
-- Name: datacenterlight_dclsectionpromopluginmodel_560be1e0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclsectionpromopluginmodel_560be1e0 ON public.datacenterlight_dclsectionpromopluginmodel USING btree (background_image_id);


--
-- Name: datacenterlight_dclsectionpromopluginmodel_aee1fcf8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_dclsectionpromopluginmodel_aee1fcf8 ON public.datacenterlight_dclsectionpromopluginmodel USING btree (html_id);


--
-- Name: datacenterlight_vmpricing_name_217872a4_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX datacenterlight_vmpricing_name_217872a4_like ON public.datacenterlight_vmpricing USING btree (name varchar_pattern_ops);


--
-- Name: digitalglarus_bookingcancellation_69dfcb07; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_bookingcancellation_69dfcb07 ON public.digitalglarus_bookingcancellation USING btree (order_id);


--
-- Name: digitalglarus_bookingorder_cb24373b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_bookingorder_cb24373b ON public.digitalglarus_bookingorder USING btree (customer_id);


--
-- Name: digitalglarus_bookingorder_e9192ced; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_bookingorder_e9192ced ON public.digitalglarus_bookingorder USING btree (billing_address_id);


--
-- Name: digitalglarus_dggallery_6be37982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_dggallery_6be37982 ON public.digitalglarus_dggallery USING btree (parent_id);


--
-- Name: digitalglarus_dggalleryplugin_6cc1e242; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_dggalleryplugin_6cc1e242 ON public.digitalglarus_dggalleryplugin USING btree ("dgGallery_id");


--
-- Name: digitalglarus_dgpicture_6d994cdb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_dgpicture_6d994cdb ON public.digitalglarus_dgpicture USING btree (gallery_id);


--
-- Name: digitalglarus_dgpicture_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_dgpicture_f33175e6 ON public.digitalglarus_dgpicture USING btree (image_id);


--
-- Name: digitalglarus_membership_94757cae; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_membership_94757cae ON public.digitalglarus_membership USING btree (type_id);


--
-- Name: digitalglarus_membershiporder_a40b5d20; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_membershiporder_a40b5d20 ON public.digitalglarus_membershiporder USING btree (membership_id);


--
-- Name: digitalglarus_membershiporder_cb24373b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_membershiporder_cb24373b ON public.digitalglarus_membershiporder USING btree (customer_id);


--
-- Name: digitalglarus_membershiporder_e9192ced; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX digitalglarus_membershiporder_e9192ced ON public.digitalglarus_membershiporder USING btree (billing_address_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_417f1b1c ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_e8701ad4 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_celery_results_taskresult_662f707d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_celery_results_taskresult_662f707d ON public.django_celery_results_taskresult USING btree (hidden);


--
-- Name: django_celery_results_taskresult_task_id_de0d95bf_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_celery_results_taskresult_task_id_de0d95bf_like ON public.django_celery_results_taskresult USING btree (task_id varchar_pattern_ops);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_de54fa62 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: djangocms_blog_authorentriesplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_authorentriesplugin_40e85b1f ON public.djangocms_blog_authorentriesplugin USING btree (app_config_id);


--
-- Name: djangocms_blog_authorentriesplugin_authors_721e74b0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_authorentriesplugin_authors_721e74b0 ON public.djangocms_blog_authorentriesplugin_authors USING btree (customuser_id);


--
-- Name: djangocms_blog_authorentriesplugin_authors_793c8338; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_authorentriesplugin_authors_793c8338 ON public.djangocms_blog_authorentriesplugin_authors USING btree (authorentriesplugin_id);


--
-- Name: djangocms_blog_blogcategory_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogcategory_40e85b1f ON public.djangocms_blog_blogcategory USING btree (app_config_id);


--
-- Name: djangocms_blog_blogcategory_6be37982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogcategory_6be37982 ON public.djangocms_blog_blogcategory USING btree (parent_id);


--
-- Name: djangocms_blog_blogcategory_transla_language_code_b6d813ea_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogcategory_transla_language_code_b6d813ea_like ON public.djangocms_blog_blogcategory_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: djangocms_blog_blogcategory_translation_2dbcba41; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogcategory_translation_2dbcba41 ON public.djangocms_blog_blogcategory_translation USING btree (slug);


--
-- Name: djangocms_blog_blogcategory_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogcategory_translation_60716c2f ON public.djangocms_blog_blogcategory_translation USING btree (language_code);


--
-- Name: djangocms_blog_blogcategory_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogcategory_translation_90349b61 ON public.djangocms_blog_blogcategory_translation USING btree (master_id);


--
-- Name: djangocms_blog_blogcategory_translation_slug_5bb923d9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogcategory_translation_slug_5bb923d9_like ON public.djangocms_blog_blogcategory_translation USING btree (slug varchar_pattern_ops);


--
-- Name: djangocms_blog_blogconfig_namespace_dc5077dd_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogconfig_namespace_dc5077dd_like ON public.djangocms_blog_blogconfig USING btree (namespace varchar_pattern_ops);


--
-- Name: djangocms_blog_blogconfig_translati_language_code_7ea60850_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogconfig_translati_language_code_7ea60850_like ON public.djangocms_blog_blogconfig_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: djangocms_blog_blogconfig_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogconfig_translation_60716c2f ON public.djangocms_blog_blogconfig_translation USING btree (language_code);


--
-- Name: djangocms_blog_blogconfig_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_blogconfig_translation_90349b61 ON public.djangocms_blog_blogconfig_translation USING btree (master_id);


--
-- Name: djangocms_blog_genericblogplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_genericblogplugin_40e85b1f ON public.djangocms_blog_genericblogplugin USING btree (app_config_id);


--
-- Name: djangocms_blog_latestpostsplugin_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_latestpostsplugin_40e85b1f ON public.djangocms_blog_latestpostsplugin USING btree (app_config_id);


--
-- Name: djangocms_blog_latestpostsplugin_categories_efb54956; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_latestpostsplugin_categories_efb54956 ON public.djangocms_blog_latestpostsplugin_categories USING btree (blogcategory_id);


--
-- Name: djangocms_blog_latestpostsplugin_categories_fda89e10; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_latestpostsplugin_categories_fda89e10 ON public.djangocms_blog_latestpostsplugin_categories USING btree (latestpostsplugin_id);


--
-- Name: djangocms_blog_post_36b62cbe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_36b62cbe ON public.djangocms_blog_post USING btree (main_image_id);


--
-- Name: djangocms_blog_post_40e85b1f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_40e85b1f ON public.djangocms_blog_post USING btree (app_config_id);


--
-- Name: djangocms_blog_post_4f331e2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_4f331e2f ON public.djangocms_blog_post USING btree (author_id);


--
-- Name: djangocms_blog_post_53808359; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_53808359 ON public.djangocms_blog_post USING btree (main_image_full_id);


--
-- Name: djangocms_blog_post_9d0a35cc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_9d0a35cc ON public.djangocms_blog_post USING btree (main_image_thumbnail_id);


--
-- Name: djangocms_blog_post_categories_efb54956; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_categories_efb54956 ON public.djangocms_blog_post_categories USING btree (blogcategory_id);


--
-- Name: djangocms_blog_post_categories_f3aa1999; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_categories_f3aa1999 ON public.djangocms_blog_post_categories USING btree (post_id);


--
-- Name: djangocms_blog_post_ce1d1ab0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_ce1d1ab0 ON public.djangocms_blog_post USING btree (liveblog_id);


--
-- Name: djangocms_blog_post_e14f02ad; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_e14f02ad ON public.djangocms_blog_post USING btree (content_id);


--
-- Name: djangocms_blog_post_related_532066b6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_related_532066b6 ON public.djangocms_blog_post_related USING btree (to_post_id);


--
-- Name: djangocms_blog_post_related_af81dabe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_related_af81dabe ON public.djangocms_blog_post_related USING btree (from_post_id);


--
-- Name: djangocms_blog_post_sites_9365d6e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_sites_9365d6e7 ON public.djangocms_blog_post_sites USING btree (site_id);


--
-- Name: djangocms_blog_post_sites_f3aa1999; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_sites_f3aa1999 ON public.djangocms_blog_post_sites USING btree (post_id);


--
-- Name: djangocms_blog_post_translation_60716c2f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_translation_60716c2f ON public.djangocms_blog_post_translation USING btree (language_code);


--
-- Name: djangocms_blog_post_translation_90349b61; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_translation_90349b61 ON public.djangocms_blog_post_translation USING btree (master_id);


--
-- Name: djangocms_blog_post_translation_language_code_d6b20a83_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_blog_post_translation_language_code_d6b20a83_like ON public.djangocms_blog_post_translation USING btree (language_code varchar_pattern_ops);


--
-- Name: djangocms_page_meta_pagemeta_f149115b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_page_meta_pagemeta_f149115b ON public.djangocms_page_meta_pagemeta USING btree (og_author_id);


--
-- Name: djangocms_page_meta_pagemeta_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_page_meta_pagemeta_f33175e6 ON public.djangocms_page_meta_pagemeta USING btree (image_id);


--
-- Name: djangocms_page_meta_titlemeta_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_page_meta_titlemeta_f33175e6 ON public.djangocms_page_meta_titlemeta USING btree (image_id);


--
-- Name: djangocms_picture_picture_d916d256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_picture_picture_d916d256 ON public.djangocms_picture_picture USING btree (page_link_id);


--
-- Name: easy_thumbnails_source_b068931c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_b068931c ON public.easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_b454e115; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_b454e115 ON public.easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_source_name_5fe0edc6_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6_like ON public.easy_thumbnails_source USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9_like ON public.easy_thumbnails_source USING btree (storage_hash varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_0afd9202; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_0afd9202 ON public.easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_b068931c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_b068931c ON public.easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_b454e115; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_b454e115 ON public.easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31_like ON public.easy_thumbnails_thumbnail USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49_like ON public.easy_thumbnails_thumbnail USING btree (storage_hash varchar_pattern_ops);


--
-- Name: filer_clipboard_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_clipboard_e8701ad4 ON public.filer_clipboard USING btree (user_id);


--
-- Name: filer_clipboarditem_2655b062; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_clipboarditem_2655b062 ON public.filer_clipboarditem USING btree (clipboard_id);


--
-- Name: filer_clipboarditem_814552b9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_clipboarditem_814552b9 ON public.filer_clipboarditem USING btree (file_id);


--
-- Name: filer_file_5e7b1936; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_file_5e7b1936 ON public.filer_file USING btree (owner_id);


--
-- Name: filer_file_a8a44dbb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_file_a8a44dbb ON public.filer_file USING btree (folder_id);


--
-- Name: filer_file_d3e32c49; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_file_d3e32c49 ON public.filer_file USING btree (polymorphic_ctype_id);


--
-- Name: filer_folder_3cfbd988; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_3cfbd988 ON public.filer_folder USING btree (rght);


--
-- Name: filer_folder_5e7b1936; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_5e7b1936 ON public.filer_folder USING btree (owner_id);


--
-- Name: filer_folder_656442a0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_656442a0 ON public.filer_folder USING btree (tree_id);


--
-- Name: filer_folder_6be37982; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_6be37982 ON public.filer_folder USING btree (parent_id);


--
-- Name: filer_folder_c9e9a848; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_c9e9a848 ON public.filer_folder USING btree (level);


--
-- Name: filer_folder_caf7cc51; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_caf7cc51 ON public.filer_folder USING btree (lft);


--
-- Name: filer_folderpermission_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folderpermission_0e939a4f ON public.filer_folderpermission USING btree (group_id);


--
-- Name: filer_folderpermission_a8a44dbb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folderpermission_a8a44dbb ON public.filer_folderpermission USING btree (folder_id);


--
-- Name: filer_folderpermission_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folderpermission_e8701ad4 ON public.filer_folderpermission USING btree (user_id);


--
-- Name: guardian_groupobjectpermission_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guardian_groupobjectpermission_0e939a4f ON public.guardian_groupobjectpermission USING btree (group_id);


--
-- Name: guardian_groupobjectpermission_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guardian_groupobjectpermission_417f1b1c ON public.guardian_groupobjectpermission USING btree (content_type_id);


--
-- Name: guardian_groupobjectpermission_8373b171; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guardian_groupobjectpermission_8373b171 ON public.guardian_groupobjectpermission USING btree (permission_id);


--
-- Name: guardian_userobjectpermission_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guardian_userobjectpermission_417f1b1c ON public.guardian_userobjectpermission USING btree (content_type_id);


--
-- Name: guardian_userobjectpermission_8373b171; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guardian_userobjectpermission_8373b171 ON public.guardian_userobjectpermission USING btree (permission_id);


--
-- Name: guardian_userobjectpermission_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX guardian_userobjectpermission_e8701ad4 ON public.guardian_userobjectpermission USING btree (user_id);


--
-- Name: hosting_genericproduct_product_slug_7dba1873_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_genericproduct_product_slug_7dba1873_like ON public.hosting_genericproduct USING btree (product_slug varchar_pattern_ops);


--
-- Name: hosting_hostingbill_cb24373b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingbill_cb24373b ON public.hosting_hostingbill USING btree (customer_id);


--
-- Name: hosting_hostingbill_e9192ced; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingbill_e9192ced ON public.hosting_hostingbill USING btree (billing_address_id);


--
-- Name: hosting_hostingbilllineitem_18b9ce52; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingbilllineitem_18b9ce52 ON public.hosting_hostingbilllineitem USING btree (stripe_plan_id);


--
-- Name: hosting_hostingbilllineitem_d2757eed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingbilllineitem_d2757eed ON public.hosting_hostingbilllineitem USING btree (monthly_hosting_bill_id);


--
-- Name: hosting_hostingorder_759af109; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingorder_759af109 ON public.hosting_hostingorder USING btree (order_detail_id);


--
-- Name: hosting_hostingorder_816f06f2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingorder_816f06f2 ON public.hosting_hostingorder USING btree (generic_product_id);


--
-- Name: hosting_hostingorder_cb24373b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingorder_cb24373b ON public.hosting_hostingorder USING btree (customer_id);


--
-- Name: hosting_hostingorder_e9192ced; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingorder_e9192ced ON public.hosting_hostingorder USING btree (billing_address_id);


--
-- Name: hosting_hostingorder_fc5399e5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_hostingorder_fc5399e5 ON public.hosting_hostingorder USING btree (vm_pricing_id);


--
-- Name: hosting_monthlyhostingbill_69dfcb07; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_monthlyhostingbill_69dfcb07 ON public.hosting_monthlyhostingbill USING btree (order_id);


--
-- Name: hosting_monthlyhostingbill_cb24373b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_monthlyhostingbill_cb24373b ON public.hosting_monthlyhostingbill USING btree (customer_id);


--
-- Name: hosting_monthlyhostingbill_invoice_id_3a992632_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_monthlyhostingbill_invoice_id_3a992632_like ON public.hosting_monthlyhostingbill USING btree (invoice_id varchar_pattern_ops);


--
-- Name: hosting_orderdetail_ebdfd5b3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_orderdetail_ebdfd5b3 ON public.hosting_orderdetail USING btree (vm_template_id);


--
-- Name: hosting_stripetaxrate_tax_rate_id_2cc6015c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_stripetaxrate_tax_rate_id_2cc6015c_like ON public.hosting_stripetaxrate USING btree (tax_rate_id varchar_pattern_ops);


--
-- Name: hosting_usercarddetail_f75b7600; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_usercarddetail_f75b7600 ON public.hosting_usercarddetail USING btree (stripe_customer_id);


--
-- Name: hosting_userhostingkey_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_userhostingkey_e8701ad4 ON public.hosting_userhostingkey USING btree (user_id);


--
-- Name: hosting_vmdetail_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hosting_vmdetail_e8701ad4 ON public.hosting_vmdetail USING btree (user_id);


--
-- Name: membership_calendar_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_calendar_e8701ad4 ON public.membership_calendar USING btree (user_id);


--
-- Name: membership_creditcards_18624dd3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_creditcards_18624dd3 ON public.membership_creditcards USING btree (user_id_id);


--
-- Name: membership_customuser_9365d6e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_customuser_9365d6e7 ON public.membership_customuser USING btree (site_id);


--
-- Name: membership_customuser_email_aac7c430_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_customuser_email_aac7c430_like ON public.membership_customuser USING btree (email varchar_pattern_ops);


--
-- Name: membership_customuser_groups_0e939a4f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_customuser_groups_0e939a4f ON public.membership_customuser_groups USING btree (group_id);


--
-- Name: membership_customuser_groups_721e74b0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_customuser_groups_721e74b0 ON public.membership_customuser_groups USING btree (customuser_id);


--
-- Name: membership_customuser_user_permissions_721e74b0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_customuser_user_permissions_721e74b0 ON public.membership_customuser_user_permissions USING btree (customuser_id);


--
-- Name: membership_customuser_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_customuser_user_permissions_8373b171 ON public.membership_customuser_user_permissions USING btree (permission_id);


--
-- Name: membership_customuser_validation_slug_7094f696_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_customuser_validation_slug_7094f696_like ON public.membership_customuser USING btree (validation_slug varchar_pattern_ops);


--
-- Name: membership_deleteduser_email_95357269_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_deleteduser_email_95357269_like ON public.membership_deleteduser USING btree (email varchar_pattern_ops);


--
-- Name: membership_stripecustomer_stripe_id_828c5ff8_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX membership_stripecustomer_stripe_id_828c5ff8_like ON public.membership_stripecustomer USING btree (stripe_id varchar_pattern_ops);


--
-- Name: multisite_alias_9365d6e7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX multisite_alias_9365d6e7 ON public.multisite_alias USING btree (site_id);


--
-- Name: multisite_alias_domain_3746202e_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX multisite_alias_domain_3746202e_like ON public.multisite_alias USING btree (domain varchar_pattern_ops);


--
-- Name: nosystemd_donation_740d224f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nosystemd_donation_740d224f ON public.nosystemd_donation USING btree (donator_id);


--
-- Name: nosystemd_donation_e9192ced; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nosystemd_donation_e9192ced ON public.nosystemd_donation USING btree (billing_address_id);


--
-- Name: nosystemd_donatorstatus_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nosystemd_donatorstatus_e8701ad4 ON public.nosystemd_donatorstatus USING btree (user_id);


--
-- Name: reversion_revision_b16b0f06; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reversion_revision_b16b0f06 ON public.reversion_revision USING btree (manager_slug);


--
-- Name: reversion_revision_c69e55a4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reversion_revision_c69e55a4 ON public.reversion_revision USING btree (date_created);


--
-- Name: reversion_revision_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reversion_revision_e8701ad4 ON public.reversion_revision USING btree (user_id);


--
-- Name: reversion_revision_manager_slug_388da6fe_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reversion_revision_manager_slug_388da6fe_like ON public.reversion_revision USING btree (manager_slug varchar_pattern_ops);


--
-- Name: reversion_version_0c9ba3a3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reversion_version_0c9ba3a3 ON public.reversion_version USING btree (object_id_int);


--
-- Name: reversion_version_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reversion_version_417f1b1c ON public.reversion_version USING btree (content_type_id);


--
-- Name: reversion_version_5de09a8d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reversion_version_5de09a8d ON public.reversion_version USING btree (revision_id);


--
-- Name: stored_messages_inbox_4ccaa172; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stored_messages_inbox_4ccaa172 ON public.stored_messages_inbox USING btree (message_id);


--
-- Name: stored_messages_inbox_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stored_messages_inbox_e8701ad4 ON public.stored_messages_inbox USING btree (user_id);


--
-- Name: stored_messages_messagearchive_4ccaa172; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stored_messages_messagearchive_4ccaa172 ON public.stored_messages_messagearchive USING btree (message_id);


--
-- Name: stored_messages_messagearchive_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stored_messages_messagearchive_e8701ad4 ON public.stored_messages_messagearchive USING btree (user_id);


--
-- Name: taggit_tag_name_58eb2ed9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tag_name_58eb2ed9_like ON public.taggit_tag USING btree (name varchar_pattern_ops);


--
-- Name: taggit_tag_slug_6be58b2c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tag_slug_6be58b2c_like ON public.taggit_tag USING btree (slug varchar_pattern_ops);


--
-- Name: taggit_taggeditem_417f1b1c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_417f1b1c ON public.taggit_taggeditem USING btree (content_type_id);


--
-- Name: taggit_taggeditem_76f094bc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_76f094bc ON public.taggit_taggeditem USING btree (tag_id);


--
-- Name: taggit_taggeditem_af31437c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_af31437c ON public.taggit_taggeditem USING btree (object_id);


--
-- Name: taggit_taggeditem_content_type_id_196cc965_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_content_type_id_196cc965_idx ON public.taggit_taggeditem USING btree (content_type_id, object_id);


--
-- Name: ungleich_page_sectionwithimage_6502254f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_page_sectionwithimage_6502254f ON public.ungleich_page_sectionwithimage USING btree (price_tag_image_id);


--
-- Name: ungleich_page_serviceitem_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_page_serviceitem_f33175e6 ON public.ungleich_page_serviceitem USING btree (image_id);


--
-- Name: ungleich_page_ungelichpicture_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_page_ungelichpicture_f33175e6 ON public.ungleich_page_ungelichpicture USING btree (image_id);


--
-- Name: ungleich_page_ungleichcustomeritem_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_page_ungleichcustomeritem_f33175e6 ON public.ungleich_page_ungleichcustomeritem USING btree (image_id);


--
-- Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem_ba32a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_page_ungleichheaderwithbackgroundvideoslideritem_ba32a ON public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem USING btree (video_id);


--
-- Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem_fb1c4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_page_ungleichheaderwithbackgroundvideoslideritem_fb1c4 ON public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem USING btree (image_id);


--
-- Name: ungleich_page_ungleichserviceitem_c93b8a4e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_page_ungleichserviceitem_c93b8a4e ON public.ungleich_page_ungleichserviceitem USING btree (data_replaced_image_id);


--
-- Name: ungleich_ungleichpage_f33175e6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ungleich_ungleichpage_f33175e6 ON public.ungleich_ungleichpage USING btree (image_id);


--
-- Name: utils_userbillingaddress_e8701ad4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX utils_userbillingaddress_e8701ad4 ON public.utils_userbillingaddress USING btree (user_id);


--
-- Name: ungleich_page_about D08e3513b114d150d28c4abb3bce2c35; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_about
    ADD CONSTRAINT "D08e3513b114d150d28c4abb3bce2c35" FOREIGN KEY (service_ptr_id) REFERENCES public.ungleich_page_service(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_page_meta_titlemeta D2d8ebbe3eb478fd3740ac099735b0c7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_titlemeta
    ADD CONSTRAINT "D2d8ebbe3eb478fd3740ac099735b0c7" FOREIGN KEY (public_extension_id) REFERENCES public.djangocms_page_meta_titlemeta(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_image_filerimage D33b02a2afb653b0641c32a07c6e12d0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_filerimage
    ADD CONSTRAINT "D33b02a2afb653b0641c32a07c6e12d0" FOREIGN KEY (thumbnail_option_id) REFERENCES public.cmsplugin_filer_image_thumbnailoption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post D5f70eada6e688daae6be1de2e35fbab; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT "D5f70eada6e688daae6be1de2e35fbab" FOREIGN KEY (main_image_full_id) REFERENCES public.cmsplugin_filer_image_thumbnailoption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_cmsfaviconextension D6a689b7f4e064039723390e1816d9c8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsfaviconextension
    ADD CONSTRAINT "D6a689b7f4e064039723390e1816d9c8" FOREIGN KEY (public_extension_id) REFERENCES public.datacenterlight_cmsfaviconextension(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichproduct D6e4cfd65052b6fa9888635bc8a0d3aa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichproduct
    ADD CONSTRAINT "D6e4cfd65052b6fa9888635bc8a0d3aa" FOREIGN KEY (service_ptr_id) REFERENCES public.ungleich_page_service(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post D8801706e0cb92694308cd45314b19c9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT "D8801706e0cb92694308cd45314b19c9" FOREIGN KEY (main_image_thumbnail_id) REFERENCES public.cmsplugin_filer_image_thumbnailoption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichcustomer D932ad9d7219b31898c55a7918264d91; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichcustomer
    ADD CONSTRAINT "D932ad9d7219b31898c55a7918264d91" FOREIGN KEY (service_ptr_id) REFERENCES public.ungleich_page_service(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_page_meta_pagemeta ab8489de252b8b141e49a49c513eed89; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta
    ADD CONSTRAINT ab8489de252b8b141e49a49c513eed89 FOREIGN KEY (public_extension_id) REFERENCES public.djangocms_page_meta_pagemeta(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingbilllineitem af906f3b2f8a509dcb333f13b34f450e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbilllineitem
    ADD CONSTRAINT af906f3b2f8a509dcb333f13b34f450e FOREIGN KEY (monthly_hosting_bill_id) REFERENCES public.hosting_monthlyhostingbill(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogarchiveplugin ald_app_config_id_0a3af4b2_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogarchiveplugin
    ADD CONSTRAINT ald_app_config_id_0a3af4b2_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin ald_app_config_id_28b9a296_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogarticlesearchplugin
    ADD CONSTRAINT ald_app_config_id_28b9a296_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogtagsplugin ald_app_config_id_512dbb54_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogtagsplugin
    ADD CONSTRAINT ald_app_config_id_512dbb54_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogcategoriesplugin ald_app_config_id_600879b3_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogcategoriesplugin
    ADD CONSTRAINT ald_app_config_id_600879b3_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article ald_app_config_id_6555e531_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article
    ADD CONSTRAINT ald_app_config_id_6555e531_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogauthorsplugin ald_app_config_id_bce6f333_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogauthorsplugin
    ADD CONSTRAINT ald_app_config_id_bce6f333_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin ald_app_config_id_dfd61698_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogfeaturedarticlesplugin
    ADD CONSTRAINT ald_app_config_id_dfd61698_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin ald_app_config_id_fa9883a7_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsbloglatestarticlesplugin
    ADD CONSTRAINT ald_app_config_id_fa9883a7_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig ald_placeholder_detail_bottom_id_c1207034_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT ald_placeholder_detail_bottom_id_c1207034_fk_cms_placeholder_id FOREIGN KEY (placeholder_detail_bottom_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig ald_placeholder_detail_footer_id_a6b076d4_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT ald_placeholder_detail_footer_id_a6b076d4_fk_cms_placeholder_id FOREIGN KEY (placeholder_detail_footer_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig aldr_placeholder_base_sidebar_id_74e2a8b2_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldr_placeholder_base_sidebar_id_74e2a8b2_fk_cms_placeholder_id FOREIGN KEY (placeholder_base_sidebar_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig aldry_placeholder_list_footer_id_a2dbbead_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldry_placeholder_list_footer_id_a2dbbead_fk_cms_placeholder_id FOREIGN KEY (placeholder_list_footer_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig_translation aldryn__master_id_8f242d76_fk_aldryn_newsblog_newsblogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig_translation
    ADD CONSTRAINT aldryn__master_id_8f242d76_fk_aldryn_newsblog_newsblogconfig_id FOREIGN KEY (master_id) REFERENCES public.aldryn_newsblog_newsblogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_categories_category_translation aldryn_cate_master_id_9e28f597_fk_aldryn_categories_category_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_categories_category_translation
    ADD CONSTRAINT aldryn_cate_master_id_9e28f597_fk_aldryn_categories_category_id FOREIGN KEY (master_id) REFERENCES public.aldryn_categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article_related aldryn_n_from_article_id_6c411149_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_related
    ADD CONSTRAINT aldryn_n_from_article_id_6c411149_fk_aldryn_newsblog_article_id FOREIGN KEY (from_article_id) REFERENCES public.aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig aldryn_n_placeholder_base_top_id_a65c77e8_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldryn_n_placeholder_base_top_id_a65c77e8_fk_cms_placeholder_id FOREIGN KEY (placeholder_base_top_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig aldryn_n_placeholder_list_top_id_c94dd081_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldryn_n_placeholder_list_top_id_c94dd081_fk_cms_placeholder_id FOREIGN KEY (placeholder_list_top_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article_categories aldryn_ne_category_id_e9b97cb3_fk_aldryn_categories_category_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_categories
    ADD CONSTRAINT aldryn_ne_category_id_e9b97cb3_fk_aldryn_categories_category_id FOREIGN KEY (category_id) REFERENCES public.aldryn_categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article aldryn_ne_featured_image_id_0966e4bf_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article
    ADD CONSTRAINT aldryn_ne_featured_image_id_0966e4bf_fk_filer_image_file_ptr_id FOREIGN KEY (featured_image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article_related aldryn_new_to_article_id_73f9645b_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_related
    ADD CONSTRAINT aldryn_new_to_article_id_73f9645b_fk_aldryn_newsblog_article_id FOREIGN KEY (to_article_id) REFERENCES public.aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article_categories aldryn_newsbl_article_id_bd51b260_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_categories
    ADD CONSTRAINT aldryn_newsbl_article_id_bd51b260_fk_aldryn_newsblog_article_id FOREIGN KEY (article_id) REFERENCES public.aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article_translation aldryn_newsblo_master_id_ef165122_fk_aldryn_newsblog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article_translation
    ADD CONSTRAINT aldryn_newsblo_master_id_ef165122_fk_aldryn_newsblog_article_id FOREIGN KEY (master_id) REFERENCES public.aldryn_newsblog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article aldryn_newsblog_a_author_id_e5e747e3_fk_aldryn_people_person_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article
    ADD CONSTRAINT aldryn_newsblog_a_author_id_e5e747e3_fk_aldryn_people_person_id FOREIGN KEY (author_id) REFERENCES public.aldryn_people_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article aldryn_newsblog_a_owner_id_453354fd_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article
    ADD CONSTRAINT aldryn_newsblog_a_owner_id_453354fd_fk_membership_customuser_id FOREIGN KEY (owner_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_article aldryn_newsblog_artic_content_id_c409fd81_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_article
    ADD CONSTRAINT aldryn_newsblog_artic_content_id_c409fd81_fk_cms_placeholder_id FOREIGN KEY (content_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogcategoriesplugin aldryn_newsblog_n_cmsplugin_ptr_id_2b0f3198_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogcategoriesplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_2b0f3198_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsbloglatestarticlesplugin aldryn_newsblog_n_cmsplugin_ptr_id_3f92bd8d_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsbloglatestarticlesplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_3f92bd8d_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogtagsplugin aldryn_newsblog_n_cmsplugin_ptr_id_544e5b0c_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogtagsplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_544e5b0c_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogarticlesearchplugin aldryn_newsblog_n_cmsplugin_ptr_id_8d9560d0_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogarticlesearchplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_8d9560d0_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogarchiveplugin aldryn_newsblog_n_cmsplugin_ptr_id_bb9f2e87_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogarchiveplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_bb9f2e87_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogfeaturedarticlesplugin aldryn_newsblog_n_cmsplugin_ptr_id_daacf4ff_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogfeaturedarticlesplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_daacf4ff_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogauthorsplugin aldryn_newsblog_n_cmsplugin_ptr_id_e07d9843_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogauthorsplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_e07d9843_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogrelatedplugin aldryn_newsblog_n_cmsplugin_ptr_id_e34e8bee_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogrelatedplugin
    ADD CONSTRAINT aldryn_newsblog_n_cmsplugin_ptr_id_e34e8bee_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_group_translation aldryn_people_grou_master_id_567bda2b_fk_aldryn_people_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_group_translation
    ADD CONSTRAINT aldryn_people_grou_master_id_567bda2b_fk_aldryn_people_group_id FOREIGN KEY (master_id) REFERENCES public.aldryn_people_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_peopleplugin aldryn_people_peo_cmsplugin_ptr_id_08aba4ae_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_peopleplugin
    ADD CONSTRAINT aldryn_people_peo_cmsplugin_ptr_id_08aba4ae_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_peopleplugin_people aldryn_people_peo_person_id_bc82db3d_fk_aldryn_people_person_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_peopleplugin_people
    ADD CONSTRAINT aldryn_people_peo_person_id_bc82db3d_fk_aldryn_people_person_id FOREIGN KEY (person_id) REFERENCES public.aldryn_people_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_person_translation aldryn_people_per_master_id_a70b6bb1_fk_aldryn_people_person_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_translation
    ADD CONSTRAINT aldryn_people_per_master_id_a70b6bb1_fk_aldryn_people_person_id FOREIGN KEY (master_id) REFERENCES public.aldryn_people_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_person_groups aldryn_people_per_person_id_18080c1f_fk_aldryn_people_person_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_groups
    ADD CONSTRAINT aldryn_people_per_person_id_18080c1f_fk_aldryn_people_person_id FOREIGN KEY (person_id) REFERENCES public.aldryn_people_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_person aldryn_people_per_visual_id_6211661f_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person
    ADD CONSTRAINT aldryn_people_per_visual_id_6211661f_fk_filer_image_file_ptr_id FOREIGN KEY (visual_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_person aldryn_people_pers_user_id_35c83992_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person
    ADD CONSTRAINT aldryn_people_pers_user_id_35c83992_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_person_groups aldryn_people_perso_group_id_5ed5e3d0_fk_aldryn_people_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_person_groups
    ADD CONSTRAINT aldryn_people_perso_group_id_5ed5e3d0_fk_aldryn_people_group_id FOREIGN KEY (group_id) REFERENCES public.aldryn_people_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_newsblog_newsblogconfig aldryn_placeholder_detail_top_id_ac288c7f_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_newsblog_newsblogconfig
    ADD CONSTRAINT aldryn_placeholder_detail_top_id_ac288c7f_fk_cms_placeholder_id FOREIGN KEY (placeholder_detail_top_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission_sites b4080ff35eabeb4614337f54a925d17d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT b4080ff35eabeb4614337f54a925d17d FOREIGN KEY (globalpagepermission_id) REFERENCES public.cms_globalpagepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_sectionwithimage c1ae55222eb7e9ce9d4fc36888a7c2b9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_sectionwithimage
    ADD CONSTRAINT c1ae55222eb7e9ce9d4fc36888a7c2b9 FOREIGN KEY (ungelichpicture_ptr_id) REFERENCES public.ungleich_page_ungelichpicture(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliaspluginmodel cms_aliaspl_alias_placeholder_id_6d6e0c8a_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspl_alias_placeholder_id_6d6e0c8a_fk_cms_placeholder_id FOREIGN KEY (alias_placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliaspluginmodel cms_aliaspluginmo_cmsplugin_ptr_id_f71dfd31_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmo_cmsplugin_ptr_id_f71dfd31_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliaspluginmodel cms_aliaspluginmodel_plugin_id_9867676e_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_plugin_id_9867676e_fk_cms_cmsplugin_id FOREIGN KEY (plugin_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_cmsplugin cms_cmsplugin_parent_id_fd3bd9dd_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_parent_id_fd3bd9dd_fk_cms_cmsplugin_id FOREIGN KEY (parent_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_cmsplugin cms_cmsplugin_placeholder_id_0bfa3b26_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_placeholder_id_0bfa3b26_fk_cms_placeholder_id FOREIGN KEY (placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission cms_globalpageperm_user_id_a227cee1_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission
    ADD CONSTRAINT cms_globalpageperm_user_id_a227cee1_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission cms_globalpagepermission_group_id_991b4733_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermission_group_id_991b4733_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission_sites cms_globalpagepermission_sit_site_id_00460b53_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission_sit_site_id_00460b53_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageuser cms_page_customuser_ptr_id_dae7a156_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageuser
    ADD CONSTRAINT cms_page_customuser_ptr_id_dae7a156_fk_membership_customuser_id FOREIGN KEY (customuser_ptr_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page cms_page_parent_id_f89b72e4_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_parent_id_f89b72e4_fk_cms_page_id FOREIGN KEY (parent_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page_placeholders cms_page_placehol_placeholder_id_6b120886_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page_placeholders
    ADD CONSTRAINT cms_page_placehol_placeholder_id_6b120886_fk_cms_placeholder_id FOREIGN KEY (placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page_placeholders cms_page_placeholders_page_id_f2ce8dec_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page_placeholders
    ADD CONSTRAINT cms_page_placeholders_page_id_f2ce8dec_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page cms_page_publisher_public_id_d619fca0_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_publisher_public_id_d619fca0_fk_cms_page_id FOREIGN KEY (publisher_public_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page cms_page_site_id_4323d3ff_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_site_id_4323d3ff_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission cms_pagepermission_group_id_af5af193_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_group_id_af5af193_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission cms_pagepermission_page_id_0ae9a163_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_page_id_0ae9a163_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission cms_pagepermission_user_id_0c7d2b3c_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_user_id_0c7d2b3c_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageusergroup cms_pageuser_created_by_id_7d57fa39_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageusergroup
    ADD CONSTRAINT cms_pageuser_created_by_id_7d57fa39_fk_membership_customuser_id FOREIGN KEY (created_by_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageuser cms_pageuser_created_by_id_8e9fbf83_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageuser
    ADD CONSTRAINT cms_pageuser_created_by_id_8e9fbf83_fk_membership_customuser_id FOREIGN KEY (created_by_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageusergroup cms_pageusergroup_group_ptr_id_34578d93_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_group_ptr_id_34578d93_fk_auth_group_id FOREIGN KEY (group_ptr_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_placeholderreference cms_placehold_placeholder_ref_id_244759b1_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholderreference
    ADD CONSTRAINT cms_placehold_placeholder_ref_id_244759b1_fk_cms_placeholder_id FOREIGN KEY (placeholder_ref_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_placeholderreference cms_placeholderre_cmsplugin_ptr_id_6977ec85_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholderreference
    ADD CONSTRAINT cms_placeholderre_cmsplugin_ptr_id_6977ec85_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplaceholder cms_staticplaceholder_draft_id_5aee407b_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_draft_id_5aee407b_fk_cms_placeholder_id FOREIGN KEY (draft_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplaceholder cms_staticplaceholder_public_id_876aaa66_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_public_id_876aaa66_fk_cms_placeholder_id FOREIGN KEY (public_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplaceholder cms_staticplaceholder_site_id_dc6a85b6_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_site_id_dc6a85b6_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_title cms_title_page_id_5fade2a3_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_title
    ADD CONSTRAINT cms_title_page_id_5fade2a3_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_title cms_title_publisher_public_id_003a2702_fk_cms_title_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_title
    ADD CONSTRAINT cms_title_publisher_public_id_003a2702_fk_cms_title_id FOREIGN KEY (publisher_public_id) REFERENCES public.cms_title(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_usersettings cms_usersettings_clipboard_id_3ae17c19_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_clipboard_id_3ae17c19_fk_cms_placeholder_id FOREIGN KEY (clipboard_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_usersettings cms_usersettings_user_id_09633b2d_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_user_id_09633b2d_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_file_filerfile cmsplugin_filer_f_cmsplugin_ptr_id_29c8a3bc_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_file_filerfile
    ADD CONSTRAINT cmsplugin_filer_f_cmsplugin_ptr_id_29c8a3bc_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_folder_filerfolder cmsplugin_filer_f_cmsplugin_ptr_id_7a439bc8_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_folder_filerfolder
    ADD CONSTRAINT cmsplugin_filer_f_cmsplugin_ptr_id_7a439bc8_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_file_filerfile cmsplugin_filer_file_filerfil_file_id_50ca113b_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_file_filerfile
    ADD CONSTRAINT cmsplugin_filer_file_filerfil_file_id_50ca113b_fk_filer_file_id FOREIGN KEY (file_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_folder_filerfolder cmsplugin_filer_folder_fi_folder_id_57adba8a_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_folder_filerfolder
    ADD CONSTRAINT cmsplugin_filer_folder_fi_folder_id_57adba8a_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_image_filerimage cmsplugin_filer_i_cmsplugin_ptr_id_42d4b8ae_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_filerimage
    ADD CONSTRAINT cmsplugin_filer_i_cmsplugin_ptr_id_42d4b8ae_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_image_filerimage cmsplugin_filer_im_image_id_a134915d_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_filerimage
    ADD CONSTRAINT cmsplugin_filer_im_image_id_a134915d_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_image_filerimage cmsplugin_filer_image_fi_file_link_id_40caefbe_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_filerimage
    ADD CONSTRAINT cmsplugin_filer_image_fi_file_link_id_40caefbe_fk_filer_file_id FOREIGN KEY (file_link_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_image_filerimage cmsplugin_filer_image_file_page_link_id_03ccb2ba_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_image_filerimage
    ADD CONSTRAINT cmsplugin_filer_image_file_page_link_id_03ccb2ba_fk_cms_page_id FOREIGN KEY (page_link_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_link_filerlinkplugin cmsplugin_filer_l_cmsplugin_ptr_id_58175d61_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_link_filerlinkplugin
    ADD CONSTRAINT cmsplugin_filer_l_cmsplugin_ptr_id_58175d61_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_link_filerlinkplugin cmsplugin_filer_link_filer_page_link_id_aff382a5_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_link_filerlinkplugin
    ADD CONSTRAINT cmsplugin_filer_link_filer_page_link_id_aff382a5_fk_cms_page_id FOREIGN KEY (page_link_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_link_filerlinkplugin cmsplugin_filer_link_filerlin_file_id_1e616d87_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_link_filerlinkplugin
    ADD CONSTRAINT cmsplugin_filer_link_filerlin_file_id_1e616d87_fk_filer_file_id FOREIGN KEY (file_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_video_filervideo cmsplugin_filer_v_cmsplugin_ptr_id_43296b80_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_video_filervideo
    ADD CONSTRAINT cmsplugin_filer_v_cmsplugin_ptr_id_43296b80_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_video_filervideo cmsplugin_filer_vi_image_id_455a7ef0_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_video_filervideo
    ADD CONSTRAINT cmsplugin_filer_vi_image_id_455a7ef0_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cmsplugin_filer_video_filervideo cmsplugin_filer_video_filerv_movie_id_756ccd23_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cmsplugin_filer_video_filervideo
    ADD CONSTRAINT cmsplugin_filer_video_filerv_movie_id_756ccd23_fk_filer_file_id FOREIGN KEY (movie_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichserviceitem d97271c7dd978eb6b3d5ce49659fdcd2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichserviceitem
    ADD CONSTRAINT d97271c7dd978eb6b3d5ce49659fdcd2 FOREIGN KEY (serviceitem_ptr_id) REFERENCES public.ungleich_page_serviceitem(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aldryn_people_peopleplugin_people da1cc505e1141e0557e3a1455ee324f4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aldryn_people_peopleplugin_people
    ADD CONSTRAINT da1cc505e1141e0557e3a1455ee324f4 FOREIGN KEY (peopleplugin_id) REFERENCES public.aldryn_people_peopleplugin(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_cmsintegration datace_calculator_placeholder_id_c8a548e5_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsintegration
    ADD CONSTRAINT datace_calculator_placeholder_id_c8a548e5_fk_cms_placeholder_id FOREIGN KEY (calculator_placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclsectionpromopluginmodel datacen_background_image_id_8969a866_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionpromopluginmodel
    ADD CONSTRAINT datacen_background_image_id_8969a866_fk_filer_image_file_ptr_id FOREIGN KEY (background_image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_cmsintegration datacenter_footer_placeholder_id_f9d0543b_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsintegration
    ADD CONSTRAINT datacenter_footer_placeholder_id_f9d0543b_fk_cms_placeholder_id FOREIGN KEY (footer_placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_cmsintegration datacenter_navbar_placeholder_id_0b0dcdca_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsintegration
    ADD CONSTRAINT datacenter_navbar_placeholder_id_0b0dcdca_fk_cms_placeholder_id FOREIGN KEY (navbar_placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclbanneritempluginmodel datacenterl_banner_image_id_a54d4287_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclbanneritempluginmodel
    ADD CONSTRAINT datacenterl_banner_image_id_a54d4287_fk_filer_image_file_ptr_id FOREIGN KEY (banner_image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclcalculatorpluginmodel datacenterl_pricing_id_6c0164d6_fk_datacenterlight_vmpricing_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclcalculatorpluginmodel
    ADD CONSTRAINT datacenterl_pricing_id_6c0164d6_fk_datacenterlight_vmpricing_id FOREIGN KEY (pricing_id) REFERENCES public.datacenterlight_vmpricing(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclnavbarpluginmodel datacenterlig_logo_light_id_841e7b8e_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclnavbarpluginmodel
    ADD CONSTRAINT datacenterlig_logo_light_id_841e7b8e_fk_filer_image_file_ptr_id FOREIGN KEY (logo_light_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclnavbarpluginmodel datacenterligh_logo_dark_id_68121679_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclnavbarpluginmodel
    ADD CONSTRAINT datacenterligh_logo_dark_id_68121679_fk_filer_image_file_ptr_id FOREIGN KEY (logo_dark_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_cmsfaviconextension datacenterlight_cmsf_extended_object_id_be9d5c42_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsfaviconextension
    ADD CONSTRAINT datacenterlight_cmsf_extended_object_id_be9d5c42_fk_cms_page_id FOREIGN KEY (extended_object_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_cmsfaviconextension datacenterlight_cmsfavicon_favicon_id_e4a848fa_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsfaviconextension
    ADD CONSTRAINT datacenterlight_cmsfavicon_favicon_id_e4a848fa_fk_filer_file_id FOREIGN KEY (favicon_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_cmsintegration datacenterlight_cmsintegra_domain_id_62281453_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_cmsintegration
    ADD CONSTRAINT datacenterlight_cmsintegra_domain_id_62281453_fk_django_site_id FOREIGN KEY (domain_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclcalculatorpluginmodel datacenterlight_d_cmsplugin_ptr_id_1649e70f_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclcalculatorpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_1649e70f_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dcllinkpluginmodel datacenterlight_d_cmsplugin_ptr_id_2414b7b3_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dcllinkpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_2414b7b3_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclbannerlistpluginmodel datacenterlight_d_cmsplugin_ptr_id_3ad339a4_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclbannerlistpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_3ad339a4_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclsectionimagepluginmodel datacenterlight_d_cmsplugin_ptr_id_49af08ea_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionimagepluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_49af08ea_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclnavbarpluginmodel datacenterlight_d_cmsplugin_ptr_id_5a3052f4_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclnavbarpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_5a3052f4_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclsectioniconpluginmodel datacenterlight_d_cmsplugin_ptr_id_5f407869_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectioniconpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_5f407869_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclcontactpluginmodel datacenterlight_d_cmsplugin_ptr_id_6885334c_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclcontactpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_6885334c_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclnavbardropdownpluginmodel datacenterlight_d_cmsplugin_ptr_id_69f3c7e8_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclnavbardropdownpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_69f3c7e8_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclsectionpluginmodel datacenterlight_d_cmsplugin_ptr_id_80fdf227_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_80fdf227_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclfooterpluginmodel datacenterlight_d_cmsplugin_ptr_id_e758f364_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclfooterpluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_e758f364_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclsectionpromopluginmodel datacenterlight_d_cmsplugin_ptr_id_e77eba7c_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionpromopluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_e77eba7c_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclbanneritempluginmodel datacenterlight_d_cmsplugin_ptr_id_fbf2e746_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclbanneritempluginmodel
    ADD CONSTRAINT datacenterlight_d_cmsplugin_ptr_id_fbf2e746_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: datacenterlight_dclsectionimagepluginmodel datacenterlight_dc_image_id_6ba99aff_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.datacenterlight_dclsectionimagepluginmodel
    ADD CONSTRAINT datacenterlight_dc_image_id_6ba99aff_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichproductitem db06e03ea18f49452e9906aa7cea66be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichproductitem
    ADD CONSTRAINT db06e03ea18f49452e9906aa7cea66be FOREIGN KEY (serviceitem_ptr_id) REFERENCES public.ungleich_page_serviceitem(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_bookingorder digitalg_billing_address_id_3efdfe28_fk_utils_billingaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingorder
    ADD CONSTRAINT digitalg_billing_address_id_3efdfe28_fk_utils_billingaddress_id FOREIGN KEY (billing_address_id) REFERENCES public.utils_billingaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_membershiporder digitalg_billing_address_id_75d583dd_fk_utils_billingaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membershiporder
    ADD CONSTRAINT digitalg_billing_address_id_75d583dd_fk_utils_billingaddress_id FOREIGN KEY (billing_address_id) REFERENCES public.utils_billingaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_membershiporder digitalgl_membership_id_56aa94e0_fk_digitalglarus_membership_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membershiporder
    ADD CONSTRAINT digitalgl_membership_id_56aa94e0_fk_digitalglarus_membership_id FOREIGN KEY (membership_id) REFERENCES public.digitalglarus_membership(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_membershiporder digitalgla_customer_id_09b987de_fk_membership_stripecustomer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membershiporder
    ADD CONSTRAINT digitalgla_customer_id_09b987de_fk_membership_stripecustomer_id FOREIGN KEY (customer_id) REFERENCES public.membership_stripecustomer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_bookingorder digitalgla_customer_id_0a93fa22_fk_membership_stripecustomer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingorder
    ADD CONSTRAINT digitalgla_customer_id_0a93fa22_fk_membership_stripecustomer_id FOREIGN KEY (customer_id) REFERENCES public.membership_stripecustomer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_dggalleryplugin digitalglar_dgGallery_id_26aa4f21_fk_digitalglarus_dggallery_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dggalleryplugin
    ADD CONSTRAINT "digitalglar_dgGallery_id_26aa4f21_fk_digitalglarus_dggallery_id" FOREIGN KEY ("dgGallery_id") REFERENCES public.digitalglarus_dggallery(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_membership digitalglar_type_id_04fbb9ad_fk_digitalglarus_membershiptype_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_membership
    ADD CONSTRAINT digitalglar_type_id_04fbb9ad_fk_digitalglarus_membershiptype_id FOREIGN KEY (type_id) REFERENCES public.digitalglarus_membershiptype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_bookingcancellation digitalglaru_order_id_cbb70d6c_fk_digitalglarus_bookingorder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingcancellation
    ADD CONSTRAINT digitalglaru_order_id_cbb70d6c_fk_digitalglarus_bookingorder_id FOREIGN KEY (order_id) REFERENCES public.digitalglarus_bookingorder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_dggallery digitalglarus__parent_id_9ccab2ca_fk_digitalglarus_dggallery_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dggallery
    ADD CONSTRAINT digitalglarus__parent_id_9ccab2ca_fk_digitalglarus_dggallery_id FOREIGN KEY (parent_id) REFERENCES public.digitalglarus_dggallery(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_bookingorder digitalglarus_b_booking_id_2375b83e_fk_digitalglarus_booking_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_bookingorder
    ADD CONSTRAINT digitalglarus_b_booking_id_2375b83e_fk_digitalglarus_booking_id FOREIGN KEY (booking_id) REFERENCES public.digitalglarus_booking(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_dggalleryplugin digitalglarus_dgg_cmsplugin_ptr_id_af496368_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dggalleryplugin
    ADD CONSTRAINT digitalglarus_dgg_cmsplugin_ptr_id_af496368_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_dgpicture digitalglarus_dgpi_image_id_4021ef41_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dgpicture
    ADD CONSTRAINT digitalglarus_dgpi_image_id_4021ef41_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_dgsupportersplugin digitalglarus_dgs_cmsplugin_ptr_id_5029dcd8_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dgsupportersplugin
    ADD CONSTRAINT digitalglarus_dgs_cmsplugin_ptr_id_5029dcd8_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digitalglarus_dgpicture digitalglarus_gallery_id_d661492e_fk_digitalglarus_dggallery_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.digitalglarus_dgpicture
    ADD CONSTRAINT digitalglarus_gallery_id_d661492e_fk_digitalglarus_dggallery_id FOREIGN KEY (gallery_id) REFERENCES public.digitalglarus_dggallery(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post_categories djan_blogcategory_id_3c5d1b9b_fk_djangocms_blog_blogcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_categories
    ADD CONSTRAINT djan_blogcategory_id_3c5d1b9b_fk_djangocms_blog_blogcategory_id FOREIGN KEY (blogcategory_id) REFERENCES public.djangocms_blog_blogcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_latestpostsplugin_categories djan_blogcategory_id_67fc1e4a_fk_djangocms_blog_blogcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin_categories
    ADD CONSTRAINT djan_blogcategory_id_67fc1e4a_fk_djangocms_blog_blogcategory_id FOREIGN KEY (blogcategory_id) REFERENCES public.djangocms_blog_blogcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_authorentriesplugin djangocm_app_config_id_21fb69d9_fk_djangocms_blog_blogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin
    ADD CONSTRAINT djangocm_app_config_id_21fb69d9_fk_djangocms_blog_blogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.djangocms_blog_blogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post djangocm_app_config_id_3f1a4082_fk_djangocms_blog_blogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT djangocm_app_config_id_3f1a4082_fk_djangocms_blog_blogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.djangocms_blog_blogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_genericblogplugin djangocm_app_config_id_738b9c8b_fk_djangocms_blog_blogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_genericblogplugin
    ADD CONSTRAINT djangocm_app_config_id_738b9c8b_fk_djangocms_blog_blogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.djangocms_blog_blogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_latestpostsplugin djangocm_app_config_id_7b061885_fk_djangocms_blog_blogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin
    ADD CONSTRAINT djangocm_app_config_id_7b061885_fk_djangocms_blog_blogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.djangocms_blog_blogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_blogcategory djangocm_app_config_id_979d1f2c_fk_djangocms_blog_blogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory
    ADD CONSTRAINT djangocm_app_config_id_979d1f2c_fk_djangocms_blog_blogconfig_id FOREIGN KEY (app_config_id) REFERENCES public.djangocms_blog_blogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_blogcategory_translation djangocms__master_id_ea2a1c61_fk_djangocms_blog_blogcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory_translation
    ADD CONSTRAINT djangocms__master_id_ea2a1c61_fk_djangocms_blog_blogcategory_id FOREIGN KEY (master_id) REFERENCES public.djangocms_blog_blogcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_blogcategory djangocms__parent_id_91f19b13_fk_djangocms_blog_blogcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogcategory
    ADD CONSTRAINT djangocms__parent_id_91f19b13_fk_djangocms_blog_blogcategory_id FOREIGN KEY (parent_id) REFERENCES public.djangocms_blog_blogcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_authorentriesplugin_authors djangocms_bl_customuser_id_f74cbaf8_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin_authors
    ADD CONSTRAINT djangocms_bl_customuser_id_f74cbaf8_fk_membership_customuser_id FOREIGN KEY (customuser_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_blogconfig_translation djangocms_bl_master_id_151749d4_fk_djangocms_blog_blogconfig_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_blogconfig_translation
    ADD CONSTRAINT djangocms_bl_master_id_151749d4_fk_djangocms_blog_blogconfig_id FOREIGN KEY (master_id) REFERENCES public.djangocms_blog_blogconfig(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post djangocms_blo_main_image_id_885d781b_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT djangocms_blo_main_image_id_885d781b_fk_filer_image_file_ptr_id FOREIGN KEY (main_image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post_related djangocms_blog__from_post_id_6d56d870_fk_djangocms_blog_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_related
    ADD CONSTRAINT djangocms_blog__from_post_id_6d56d870_fk_djangocms_blog_post_id FOREIGN KEY (from_post_id) REFERENCES public.djangocms_blog_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_authorentriesplugin djangocms_blog_au_cmsplugin_ptr_id_828883cb_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin
    ADD CONSTRAINT djangocms_blog_au_cmsplugin_ptr_id_828883cb_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_genericblogplugin djangocms_blog_ge_cmsplugin_ptr_id_de3802b0_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_genericblogplugin
    ADD CONSTRAINT djangocms_blog_ge_cmsplugin_ptr_id_de3802b0_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_latestpostsplugin djangocms_blog_la_cmsplugin_ptr_id_e8ff125b_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin
    ADD CONSTRAINT djangocms_blog_la_cmsplugin_ptr_id_e8ff125b_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post djangocms_blog_p_author_id_6f01c20d_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT djangocms_blog_p_author_id_6f01c20d_fk_membership_customuser_id FOREIGN KEY (author_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post_related djangocms_blog_po_to_post_id_9b378705_fk_djangocms_blog_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_related
    ADD CONSTRAINT djangocms_blog_po_to_post_id_9b378705_fk_djangocms_blog_post_id FOREIGN KEY (to_post_id) REFERENCES public.djangocms_blog_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post_translation djangocms_blog_pos_master_id_4d7607b6_fk_djangocms_blog_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_translation
    ADD CONSTRAINT djangocms_blog_pos_master_id_4d7607b6_fk_djangocms_blog_post_id FOREIGN KEY (master_id) REFERENCES public.djangocms_blog_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post_sites djangocms_blog_post__post_id_4e5295d8_fk_djangocms_blog_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_sites
    ADD CONSTRAINT djangocms_blog_post__post_id_4e5295d8_fk_djangocms_blog_post_id FOREIGN KEY (post_id) REFERENCES public.djangocms_blog_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post_categories djangocms_blog_post__post_id_9a0528c3_fk_djangocms_blog_post_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_categories
    ADD CONSTRAINT djangocms_blog_post__post_id_9a0528c3_fk_djangocms_blog_post_id FOREIGN KEY (post_id) REFERENCES public.djangocms_blog_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post djangocms_blog_post_content_id_8dbf092f_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT djangocms_blog_post_content_id_8dbf092f_fk_cms_placeholder_id FOREIGN KEY (content_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post djangocms_blog_post_liveblog_id_c71ae462_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post
    ADD CONSTRAINT djangocms_blog_post_liveblog_id_c71ae462_fk_cms_placeholder_id FOREIGN KEY (liveblog_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_post_sites djangocms_blog_post_sites_site_id_d2f7f59d_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_post_sites
    ADD CONSTRAINT djangocms_blog_post_sites_site_id_d2f7f59d_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_file_file djangocms_file_fi_cmsplugin_ptr_id_428f5041_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_file
    ADD CONSTRAINT djangocms_file_fi_cmsplugin_ptr_id_428f5041_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_page_meta_pagemeta djangocms_pag_og_author_id_b3c1587d_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta
    ADD CONSTRAINT djangocms_pag_og_author_id_b3c1587d_fk_membership_customuser_id FOREIGN KEY (og_author_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_page_meta_pagemeta djangocms_page_meta__extended_object_id_3e42f99f_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta
    ADD CONSTRAINT djangocms_page_meta__extended_object_id_3e42f99f_fk_cms_page_id FOREIGN KEY (extended_object_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_page_meta_titlemeta djangocms_page_meta_extended_object_id_8d83fca1_fk_cms_title_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_titlemeta
    ADD CONSTRAINT djangocms_page_meta_extended_object_id_8d83fca1_fk_cms_title_id FOREIGN KEY (extended_object_id) REFERENCES public.cms_title(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_page_meta_pagemeta djangocms_page_meta_pagemeta_image_id_ea4717af_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_pagemeta
    ADD CONSTRAINT djangocms_page_meta_pagemeta_image_id_ea4717af_fk_filer_file_id FOREIGN KEY (image_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_page_meta_titlemeta djangocms_page_meta_titlemet_image_id_df083a43_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_page_meta_titlemeta
    ADD CONSTRAINT djangocms_page_meta_titlemet_image_id_df083a43_fk_filer_file_id FOREIGN KEY (image_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_picture_picture djangocms_picture_cmsplugin_ptr_id_0e797309_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_cmsplugin_ptr_id_0e797309_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_picture_picture djangocms_picture_picture_page_link_id_d5c782e0_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_picture_page_link_id_d5c782e0_fk_cms_page_id FOREIGN KEY (page_link_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_text_ckeditor_text djangocms_text_ck_cmsplugin_ptr_id_946882c1_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_text_ckeditor_text
    ADD CONSTRAINT djangocms_text_ck_cmsplugin_ptr_id_946882c1_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_video_video djangocms_video_v_cmsplugin_ptr_id_cc81a95d_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_video
    ADD CONSTRAINT djangocms_video_v_cmsplugin_ptr_id_cc81a95d_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thum_thumbnail_id_c3a0c549_fk_easy_thumbnails_thumbnail_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thum_thumbnail_id_c3a0c549_fk_easy_thumbnails_thumbnail_id FOREIGN KEY (thumbnail_id) REFERENCES public.easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_source_id_5b57bc77_fk_easy_thumbnails_source_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_source_id_5b57bc77_fk_easy_thumbnails_source_id FOREIGN KEY (source_id) REFERENCES public.easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_aboutitem f2c878a7335b40e1e9488686077d3f9c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_aboutitem
    ADD CONSTRAINT f2c878a7335b40e1e9488686077d3f9c FOREIGN KEY (ungelichpicture_ptr_id) REFERENCES public.ungleich_page_ungelichpicture(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_latestpostsplugin_categories f7d3ad4e2796791a5b4819cb79ff8448; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_latestpostsplugin_categories
    ADD CONSTRAINT f7d3ad4e2796791a5b4819cb79ff8448 FOREIGN KEY (latestpostsplugin_id) REFERENCES public.djangocms_blog_latestpostsplugin(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_blog_authorentriesplugin_authors fec8d2498f19bf0d4b6df68727218314; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_blog_authorentriesplugin_authors
    ADD CONSTRAINT fec8d2498f19bf0d4b6df68727218314 FOREIGN KEY (authorentriesplugin_id) REFERENCES public.djangocms_blog_authorentriesplugin(cmsplugin_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboard filer_clipboard_user_id_b52ff0bc_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboard
    ADD CONSTRAINT filer_clipboard_user_id_b52ff0bc_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboarditem filer_clipboarditem_clipboard_id_7a76518b_fk_filer_clipboard_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_clipboard_id_7a76518b_fk_filer_clipboard_id FOREIGN KEY (clipboard_id) REFERENCES public.filer_clipboard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboarditem filer_clipboarditem_file_id_06196f80_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_file_id_06196f80_fk_filer_file_id FOREIGN KEY (file_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file filer_f_polymorphic_ctype_id_f44903c1_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_f_polymorphic_ctype_id_f44903c1_fk_django_content_type_id FOREIGN KEY (polymorphic_ctype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file filer_file_folder_id_af803bbb_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_file_folder_id_af803bbb_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file filer_file_owner_id_b9e32671_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_file_owner_id_b9e32671_fk_membership_customuser_id FOREIGN KEY (owner_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folder filer_folder_owner_id_be530fb4_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_owner_id_be530fb4_fk_membership_customuser_id FOREIGN KEY (owner_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folder filer_folder_parent_id_308aecda_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_parent_id_308aecda_fk_filer_folder_id FOREIGN KEY (parent_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermission filer_folderpermis_user_id_7673d4b6_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermis_user_id_7673d4b6_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermission filer_folderpermission_folder_id_5d02f1da_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_folder_id_5d02f1da_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermission filer_folderpermission_group_id_8901bafa_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_group_id_8901bafa_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_image filer_image_file_ptr_id_3e21d4f0_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_image
    ADD CONSTRAINT filer_image_file_ptr_id_3e21d4f0_fk_filer_file_id FOREIGN KEY (file_ptr_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: guardian_groupobjectpermission guardian_gro_content_type_id_7ade36b8_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_groupobjectpermission
    ADD CONSTRAINT guardian_gro_content_type_id_7ade36b8_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: guardian_groupobjectpermission guardian_groupobje_permission_id_36572738_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_groupobjectpermission
    ADD CONSTRAINT guardian_groupobje_permission_id_36572738_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: guardian_groupobjectpermission guardian_groupobjectpermissi_group_id_4bbbfb62_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_groupobjectpermission
    ADD CONSTRAINT guardian_groupobjectpermissi_group_id_4bbbfb62_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: guardian_userobjectpermission guardian_use_content_type_id_2e892405_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_userobjectpermission
    ADD CONSTRAINT guardian_use_content_type_id_2e892405_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: guardian_userobjectpermission guardian_userobjec_permission_id_71807bfc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_userobjectpermission
    ADD CONSTRAINT guardian_userobjec_permission_id_71807bfc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: guardian_userobjectpermission guardian_userobjec_user_id_d5c1e964_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guardian_userobjectpermission
    ADD CONSTRAINT guardian_userobjec_user_id_d5c1e964_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_usercarddetail hos_stripe_customer_id_cb71b5bb_fk_membership_stripecustomer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_usercarddetail
    ADD CONSTRAINT hos_stripe_customer_id_cb71b5bb_fk_membership_stripecustomer_id FOREIGN KEY (stripe_customer_id) REFERENCES public.membership_stripecustomer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingorder hostin_generic_product_id_71295a40_fk_hosting_genericproduct_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingorder
    ADD CONSTRAINT hostin_generic_product_id_71295a40_fk_hosting_genericproduct_id FOREIGN KEY (generic_product_id) REFERENCES public.hosting_genericproduct(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingbilllineitem hostin_stripe_plan_id_73adcc46_fk_datacenterlight_stripeplan_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbilllineitem
    ADD CONSTRAINT hostin_stripe_plan_id_73adcc46_fk_datacenterlight_stripeplan_id FOREIGN KEY (stripe_plan_id) REFERENCES public.datacenterlight_stripeplan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_orderdetail hostin_vm_template_id_464a15d5_fk_datacenterlight_vmtemplate_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_orderdetail
    ADD CONSTRAINT hostin_vm_template_id_464a15d5_fk_datacenterlight_vmtemplate_id FOREIGN KEY (vm_template_id) REFERENCES public.datacenterlight_vmtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingbill hosting__billing_address_id_1ecd6fc0_fk_utils_billingaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbill
    ADD CONSTRAINT hosting__billing_address_id_1ecd6fc0_fk_utils_billingaddress_id FOREIGN KEY (billing_address_id) REFERENCES public.utils_billingaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingorder hosting__billing_address_id_cd7065fa_fk_utils_billingaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingorder
    ADD CONSTRAINT hosting__billing_address_id_cd7065fa_fk_utils_billingaddress_id FOREIGN KEY (billing_address_id) REFERENCES public.utils_billingaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingorder hosting__vm_pricing_id_a63700d2_fk_datacenterlight_vmpricing_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingorder
    ADD CONSTRAINT hosting__vm_pricing_id_a63700d2_fk_datacenterlight_vmpricing_id FOREIGN KEY (vm_pricing_id) REFERENCES public.datacenterlight_vmpricing(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingorder hosting_ho_customer_id_27204fce_fk_membership_stripecustomer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingorder
    ADD CONSTRAINT hosting_ho_customer_id_27204fce_fk_membership_stripecustomer_id FOREIGN KEY (customer_id) REFERENCES public.membership_stripecustomer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingbill hosting_ho_customer_id_3780cd9d_fk_membership_stripecustomer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingbill
    ADD CONSTRAINT hosting_ho_customer_id_3780cd9d_fk_membership_stripecustomer_id FOREIGN KEY (customer_id) REFERENCES public.membership_stripecustomer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_hostingorder hosting_host_order_detail_id_9e9f7a2b_fk_hosting_orderdetail_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_hostingorder
    ADD CONSTRAINT hosting_host_order_detail_id_9e9f7a2b_fk_hosting_orderdetail_id FOREIGN KEY (order_detail_id) REFERENCES public.hosting_orderdetail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_monthlyhostingbill hosting_mo_customer_id_94905f18_fk_membership_stripecustomer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_monthlyhostingbill
    ADD CONSTRAINT hosting_mo_customer_id_94905f18_fk_membership_stripecustomer_id FOREIGN KEY (customer_id) REFERENCES public.membership_stripecustomer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_monthlyhostingbill hosting_monthlyhos_order_id_ac68fe8d_fk_hosting_hostingorder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_monthlyhostingbill
    ADD CONSTRAINT hosting_monthlyhos_order_id_ac68fe8d_fk_hosting_hostingorder_id FOREIGN KEY (order_id) REFERENCES public.hosting_hostingorder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_userhostingkey hosting_userhostin_user_id_d1b597dc_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_userhostingkey
    ADD CONSTRAINT hosting_userhostin_user_id_d1b597dc_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hosting_vmdetail hosting_vmdetail_user_id_b23659ce_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hosting_vmdetail
    ADD CONSTRAINT hosting_vmdetail_user_id_b23659ce_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_customuser_user_permissions membership_c_customuser_id_0edaf53b_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_user_permissions
    ADD CONSTRAINT membership_c_customuser_id_0edaf53b_fk_membership_customuser_id FOREIGN KEY (customuser_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_customuser_groups membership_c_customuser_id_8995442e_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_groups
    ADD CONSTRAINT membership_c_customuser_id_8995442e_fk_membership_customuser_id FOREIGN KEY (customuser_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_calendar membership_calenda_user_id_2ab6f7c6_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_calendar
    ADD CONSTRAINT membership_calenda_user_id_2ab6f7c6_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_creditcards membership_cred_user_id_id_f55443cf_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_creditcards
    ADD CONSTRAINT membership_cred_user_id_id_f55443cf_fk_membership_customuser_id FOREIGN KEY (user_id_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_customuser_user_permissions membership_customu_permission_id_7dde51cc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_user_permissions
    ADD CONSTRAINT membership_customu_permission_id_7dde51cc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_customuser_groups membership_customuser_groups_group_id_7faabc8c_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser_groups
    ADD CONSTRAINT membership_customuser_groups_group_id_7faabc8c_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_customuser membership_customuser_site_id_d56011de_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_customuser
    ADD CONSTRAINT membership_customuser_site_id_d56011de_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_stripecustomer membership_stripec_user_id_490348c4_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_stripecustomer
    ADD CONSTRAINT membership_stripec_user_id_490348c4_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: multisite_alias multisite_alias_site_id_e73f0f15_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.multisite_alias
    ADD CONSTRAINT multisite_alias_site_id_e73f0f15_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: nosystemd_donation nosystem_billing_address_id_9b2bfabe_fk_utils_billingaddress_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donation
    ADD CONSTRAINT nosystem_billing_address_id_9b2bfabe_fk_utils_billingaddress_id FOREIGN KEY (billing_address_id) REFERENCES public.utils_billingaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: nosystemd_donation nosystemd_d_donator_id_4baf91a3_fk_membership_stripecustomer_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donation
    ADD CONSTRAINT nosystemd_d_donator_id_4baf91a3_fk_membership_stripecustomer_id FOREIGN KEY (donator_id) REFERENCES public.membership_stripecustomer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: nosystemd_donatorstatus nosystemd_donators_user_id_faa76894_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nosystemd_donatorstatus
    ADD CONSTRAINT nosystemd_donators_user_id_faa76894_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reversion_revision reversion_revision_user_id_17095f45_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reversion_revision
    ADD CONSTRAINT reversion_revision_user_id_17095f45_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reversion_version reversion_ve_content_type_id_7d0ff25c_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reversion_version
    ADD CONSTRAINT reversion_ve_content_type_id_7d0ff25c_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reversion_version reversion_version_revision_id_af9f6a9d_fk_reversion_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reversion_version
    ADD CONSTRAINT reversion_version_revision_id_af9f6a9d_fk_reversion_revision_id FOREIGN KEY (revision_id) REFERENCES public.reversion_revision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stored_messages_inbox stored_messag_message_id_29e83d86_fk_stored_messages_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_inbox
    ADD CONSTRAINT stored_messag_message_id_29e83d86_fk_stored_messages_message_id FOREIGN KEY (message_id) REFERENCES public.stored_messages_message(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stored_messages_messagearchive stored_messag_message_id_5c434ae3_fk_stored_messages_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_messagearchive
    ADD CONSTRAINT stored_messag_message_id_5c434ae3_fk_stored_messages_message_id FOREIGN KEY (message_id) REFERENCES public.stored_messages_message(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stored_messages_inbox stored_messages_in_user_id_0fb988d9_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_inbox
    ADD CONSTRAINT stored_messages_in_user_id_0fb988d9_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stored_messages_messagearchive stored_messages_me_user_id_57faf009_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stored_messages_messagearchive
    ADD CONSTRAINT stored_messages_me_user_id_57faf009_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_tagge_content_type_id_9957a03c_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_tagge_content_type_id_9957a03c_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES public.taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichserviceitem ungl_data_replaced_image_id_a1870005_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichserviceitem
    ADD CONSTRAINT ungl_data_replaced_image_id_a1870005_fk_filer_image_file_ptr_id FOREIGN KEY (data_replaced_image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_ungleichpage unglei_public_extension_id_3d10d43b_fk_ungleich_ungleichpage_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_ungleichpage
    ADD CONSTRAINT unglei_public_extension_id_3d10d43b_fk_ungleich_ungleichpage_id FOREIGN KEY (public_extension_id) REFERENCES public.ungleich_ungleichpage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_service ungleich_page_ser_cmsplugin_ptr_id_090aa204_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_service
    ADD CONSTRAINT ungleich_page_ser_cmsplugin_ptr_id_090aa204_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_serviceitem ungleich_page_ser_cmsplugin_ptr_id_a2726567_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_serviceitem
    ADD CONSTRAINT ungleich_page_ser_cmsplugin_ptr_id_a2726567_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_serviceitem ungleich_page_serv_image_id_4df4b82b_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_serviceitem
    ADD CONSTRAINT ungleich_page_serv_image_id_4df4b82b_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichhtmlonly ungleich_page_ung_cmsplugin_ptr_id_3e723d0b_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichhtmlonly
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_3e723d0b_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungelichcontactussection ungleich_page_ung_cmsplugin_ptr_id_3ef9a7fc_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungelichcontactussection
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_3ef9a7fc_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungelichtextsection ungleich_page_ung_cmsplugin_ptr_id_6cd874c1_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungelichtextsection
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_6cd874c1_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichheaderwithbackgroundimageslider ungleich_page_ung_cmsplugin_ptr_id_6e6af477_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichheaderwithbackgroundimageslider
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_6e6af477_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem ungleich_page_ung_cmsplugin_ptr_id_8e304ad5_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_8e304ad5_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichcustomeritem ungleich_page_ung_cmsplugin_ptr_id_b39a6682_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichcustomeritem
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_b39a6682_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungelichpicture ungleich_page_ung_cmsplugin_ptr_id_b788433d_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungelichpicture
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_b788433d_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichfooter ungleich_page_ung_cmsplugin_ptr_id_c8ec4686_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichfooter
    ADD CONSTRAINT ungleich_page_ung_cmsplugin_ptr_id_c8ec4686_fk_cms_cmsplugin_id FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungelichpicture ungleich_page_unge_image_id_fda8f1d9_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungelichpicture
    ADD CONSTRAINT ungleich_page_unge_image_id_fda8f1d9_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichcustomeritem ungleich_page_ungl_image_id_d0e89b1c_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichcustomeritem
    ADD CONSTRAINT ungleich_page_ungl_image_id_d0e89b1c_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem ungleich_page_ungl_image_id_e1692405_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem
    ADD CONSTRAINT ungleich_page_ungl_image_id_e1692405_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_ungleichheaderwithbackgroundvideoslideritem ungleich_page_ungleichheader_video_id_3f16f92b_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_ungleichheaderwithbackgroundvideoslideritem
    ADD CONSTRAINT ungleich_page_ungleichheader_video_id_3f16f92b_fk_filer_file_id FOREIGN KEY (video_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_page_sectionwithimage ungleich_price_tag_image_id_4f5e8102_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_page_sectionwithimage
    ADD CONSTRAINT ungleich_price_tag_image_id_4f5e8102_fk_filer_image_file_ptr_id FOREIGN KEY (price_tag_image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_ungleichpage ungleich_ungleichp_image_id_ead0a708_fk_filer_image_file_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_ungleichpage
    ADD CONSTRAINT ungleich_ungleichp_image_id_ead0a708_fk_filer_image_file_ptr_id FOREIGN KEY (image_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ungleich_ungleichpage ungleich_ungleichpag_extended_object_id_c1ef9374_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ungleich_ungleichpage
    ADD CONSTRAINT ungleich_ungleichpag_extended_object_id_c1ef9374_fk_cms_page_id FOREIGN KEY (extended_object_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: utils_userbillingaddress utils_userbillinga_user_id_78761d17_fk_membership_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utils_userbillingaddress
    ADD CONSTRAINT utils_userbillinga_user_id_78761d17_fk_membership_customuser_id FOREIGN KEY (user_id) REFERENCES public.membership_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

